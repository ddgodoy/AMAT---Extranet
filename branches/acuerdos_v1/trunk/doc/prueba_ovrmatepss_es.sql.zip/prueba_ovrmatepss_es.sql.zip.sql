# phpMyAdmin SQL Dump
# version 2.5.3
# http://www.phpmyadmin.net
#
# Servidor: localhost
# Tiempo de generaci�n: 03-02-2010 a las 19:10:27
# Versi�n del servidor: 5.0.51
# Versi�n de PHP: 5.2.6-1+lenny4
# 
# Base de datos : `prueba_ovrmatepss_es`
# 

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `accion`
#

CREATE TABLE `accion` (
  `id` bigint(20) NOT NULL auto_increment,
  `entidad_creadora` varchar(255) default NULL,
  `entidad_creadora_id` bigint(20) default NULL,
  `entidad` varchar(255) default NULL,
  `entidad_id` bigint(20) default NULL,
  `accion` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

#
# Volcar la base de datos para la tabla `accion`
#


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `acta`
#

CREATE TABLE `acta` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(100) default NULL,
  `detalle` longtext,
  `asamblea_id` bigint(20) default NULL,
  `owner_id` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `asamblea_id_idx` (`asamblea_id`),
  KEY `owner_id_idx` (`owner_id`),
  CONSTRAINT `acta_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `acta_ibfk_2` FOREIGN KEY (`asamblea_id`) REFERENCES `asamblea` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

#
# Volcar la base de datos para la tabla `acta`
#

INSERT INTO `acta` VALUES (9, 'Mikel', '<p>Mikel Acta&nbsp;</p>', 9, 7, '2009-11-21 11:12:11', '2009-11-21 11:21:37', 0);
INSERT INTO `acta` VALUES (10, 'Asamble 1', '<p>eoo yuna aaa</p>', 10, 7, '2009-12-29 10:10:38', '2009-12-29 10:28:32', 0);
INSERT INTO `acta` VALUES (11, NULL, NULL, 11, 7, '2009-12-29 10:11:36', '2009-12-29 10:11:36', 0);
INSERT INTO `acta` VALUES (12, NULL, NULL, 12, 7, '2009-12-29 10:36:06', '2009-12-29 10:36:06', 0);
INSERT INTO `acta` VALUES (13, NULL, NULL, 13, 7, '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `acta` VALUES (14, NULL, NULL, 14, 7, '2009-12-29 17:31:01', '2009-12-29 17:31:01', 0);
INSERT INTO `acta` VALUES (15, NULL, NULL, 15, 7, '2010-01-12 09:06:03', '2010-01-12 09:06:03', 0);
INSERT INTO `acta` VALUES (16, 'Acta de ', '<p>Unaaa</p>', 16, 7, '2010-01-18 12:32:25', '2010-01-18 12:36:13', 0);
INSERT INTO `acta` VALUES (17, NULL, NULL, 17, 7, '2010-01-18 16:22:27', '2010-01-18 16:22:27', 0);
INSERT INTO `acta` VALUES (18, NULL, NULL, 18, 1, '2010-02-02 15:50:20', '2010-02-02 15:50:20', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `actividad`
#

CREATE TABLE `actividad` (
  `id` bigint(20) NOT NULL auto_increment,
  `titulo` varchar(100) default NULL,
  `autor` varchar(100) NOT NULL,
  `contenido` longtext,
  `imagen` varchar(255) default NULL,
  `documento` varchar(255) default NULL,
  `fecha` date NOT NULL,
  `fecha_publicacion` date NOT NULL,
  `ambito` varchar(255) default NULL,
  `estado` varchar(255) default NULL,
  `destacada` tinyint(1) default NULL,
  `mutua_id` bigint(20) default NULL,
  `owner_id` bigint(20) default NULL,
  `user_id_creador` bigint(20) default NULL,
  `user_id_modificado` bigint(20) default NULL,
  `user_id_publicado` bigint(20) default NULL,
  `fecha_publicado` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `mutua_id_idx` (`mutua_id`),
  KEY `owner_id_idx` (`owner_id`),
  CONSTRAINT `actividad_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividad_ibfk_2` FOREIGN KEY (`mutua_id`) REFERENCES `mutua` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

#
# Volcar la base de datos para la tabla `actividad`
#

INSERT INTO `actividad` VALUES (15, 'La gesti�n del Absentismo como una herramienta para la mejora de la competitividad', '', '', '49ec30fe9b8a9.jpg', '49e70da4023f6.pdf', '2009-04-16', '2009-11-20', 'web', 'publicado', 0, 1, 1, 1, NULL, NULL, NULL, '2009-04-16 12:51:16', NULL, 0);
INSERT INTO `actividad` VALUES (17, 'El Consorcio Provincial de Valencia de Bomberos, en colaboraci�n con Umivale, organiza el pr�ximo d�', '', '', '4a27930d350bf.jpg', '49f1bceec05f2.pdf', '2009-04-24', '2009-11-20', 'web', 'publicado', 0, 1, 1, 1, NULL, NULL, NULL, '2009-04-24 15:21:50', NULL, 0);
INSERT INTO `actividad` VALUES (19, 'FREMAP ha concedido en 2008 un total de 1.270 prestaciones especiales en ayudas sociales a los traba', '', '<p>Durante el ejercicio 2008, la Comisi&oacute;n de Prestaciones especiales de FREMAP ha concedido 1.270 prestaciones por un importe de 3.879.035 &euro;.   De esta manera, la Mutua ejerce una importante funci&oacute;n social mediante la concesi&oacute;n de estas ayudas, previstas en el art. 67 del Reglamento de Colaboraci&oacute;n.   Dicha normativa establece que la Comisi&oacute;n de Prestaciones Especiales tendr&aacute; a su cargo la concesi&oacute;n de los beneficios de la asistencia social que hayan de ser satisfechos por la Mutua con cargo a los recursos previstos en el art&iacute;culo 66.2 de dicho Reglamento.   La asistencia social consistir&aacute; en la concesi&oacute;n de los servicios y auxilios econ&oacute;micos que, en atenci&oacute;n a estados y situaciones concretas de necesidad, se consideren precisos.   Las prestaciones de asistencia social, de car&aacute;cter potestativo claramente diferenciado de las prestaciones reglamentarias, pueden concederse a los trabajadores al servicio de los empresarios asociados y a sus derechohabientes que, habiendo sufrido un accidente de trabajo o estando afectados por enfermedades profesionales, se encuentren en dichos estados o situaciones de necesidad.  Esta Comisi&oacute;n est&aacute; compuesta de forma paritaria por representantes de las empresas mutualistas y por representantes de los trabajadores de empresas asociadas.  Con la concesi&oacute;n de estas ayudas sociales FREMAP  da cumplimiento a la previsi&oacute;n legal referida y por a&ntilde;adidura, cumple una funci&oacute;n social relevante.</p>', '4a2792e5d8b79.jpg', '', '2009-06-04', '2009-11-20', 'web', 'publicado', 0, 1, 1, 1, NULL, NULL, NULL, '2009-06-04 11:24:53', NULL, 0);
INSERT INTO `actividad` VALUES (20, 'Asepeyo ha destinado 28,3 millones de euros en ayudas sociales a personas que han sufrido un acciden', 'AMAT', '<p>En sus 25 a&ntilde;os de existencia, la Comisi&oacute;n de Prestaciones Especiales de la Mutua ha atendido 20.462 casos de trabajadores en esta situaci&oacute;n. La Comisi&oacute;n de Prestaciones Especiales de Asepeyo, &oacute;rgano que gestiona el Fondo de Asistencia Social de la Mutua, ha otorgado, en sus 25 a&ntilde;os de existencia, m&aacute;s de 28,3 millones de euros, con un total de 20.462 casos atendidos de trabajadores que han sufrido un accidente de trabajo o enfermedad profesional. Formada por ocho miembros pertenecientes, a partes iguales, a representantes de los empresarios asociados, designados por la Junta Directiva, y por trabajadores de las empresas asociadas, elegidos por las organizaciones sindicales, la Comisi&oacute;n promueve la integraci&oacute;n social de las personas con minusval&iacute;a derivada de un accidente de trabajo o enfermedad profesional, la sensibilizaci&oacute;n y el apoyo profesional a este colectivo mediante ayudas econ&oacute;micas y el programa de readaptaci&oacute;n laboral Asepeyo Integra. Estas ayudas especiales tienen como objetivo mejorar las condiciones de calidad de vida y atender situaciones de especial necesidad que tengan los trabajadores que han sufrido un accidente de trabajo o enfermedad profesional. Se dedica especial atenci&oacute;n a las situaciones de gran invalidez, adaptaci&oacute;n y rehabilitaci&oacute;n de viviendas, eliminaci&oacute;n de barreras arquitect&oacute;nicas, ayudas familiares, adecuaci&oacute;n de veh&iacute;culos propios o cursos ocupacionales. La profesionalidad y la responsabilidad de Asepeyo en la gesti&oacute;n de los recursos p&uacute;blicos han permitido incrementar hist&oacute;ricamente la cuant&iacute;a econ&oacute;mica del Fondo de Asistencia Social. As&iacute;, en el 2008, la Comisi&oacute;n ha podido destinar 2.938.916,27 euros a este fin, un 58,5 % m&aacute;s que en el ejercicio anterior, y ha atendido 1.055 casos, cifra que supone un aumento de un 36,8%. Estas ayudas, que son extraordinarias en los casos de accidente de trabajo y enfermedad profesional, y complementarias a las prestaciones reglamentarias, se conceden conforme a la normativa legal de Mutuas de Accidentes de Trabajo y Enfermedades Profesionales.</p>', '4a3a13a45d574.jpg', '4a3a13a4613ea.pdf', '2009-06-18', '2009-11-20', 'web', 'pendiente', 0, 1, 1, 1, 7, NULL, NULL, '2009-06-18 12:15:00', '2009-12-28 09:50:51', 0);
INSERT INTO `actividad` VALUES (21, 'Mutua Universal publica su gu�a medioambiental', '', '<p>Mutua Universal ha lanzado este mes de Junio, con ocasi&oacute;n del D&iacute;a Mundial del Medio Ambiente, la Gu&iacute;a de Buenas Pr&aacute;cticas Ambientales, un compendio de acciones responsables que permiten contribuir a reducir el impacto ambiental provocado por la actividad de cada uno de los empleados de Mutua Universal.  Se trata de consejos de sencilla aplicaci&oacute;n, tanto en el lugar de trabajo como en el hogar, encaminados a la prevenci&oacute;n y reducci&oacute;n de residuos.  Seg&uacute;n Eduard Garriga, Director Gerente de Mutua Universal: Esta iniciativa se enmarca dentro de nuestro programa de RSC y nos sentimos muy orgullosos de contribuir, con su edici&oacute;n, a concienciar a nuestros empleados sobre los buenos h&aacute;bitos de respeto al medio ambiente.</p>', '4a4c5d0079a56.jpg', '4a49d7c9f2309.pdf', '2009-06-30', '2009-11-20', 'web', 'publicado', 0, 1, 1, 1, NULL, NULL, NULL, '2009-06-30 11:15:53', NULL, 0);
INSERT INTO `actividad` VALUES (22, 'Mutua Universal en �vila solidaria con los m�s desprotegidos', '', '<p>Los profesioanles de Mutua Universal en &Aacute;vila han participado,  como viene siendo habitual desde hace 12 a&ntilde;os, en la Gran Marcha por la Discapacidad que organiza anualmente en la capital abulense la empresa Pronisa, asociaci&oacute;n dedicada al servicio de las personas con discapacidad y a la defensa de sus derechos.  M&aacute;s de 1.300 personas participaron en este recorrido de 21 Km. cuyo fin principal, adem&aacute;s de sensibilizar a la poblaci&oacute;n entorno al mundo de la discapacidad, es recaudar fondos para la organizaci&oacute;n. La cantidad recaudada este a&ntilde;o servir&aacute; para mejorar el Centro de Educaci&oacute;n y Discapacidad de Pronisa y para varias asociaciones de discapacitados de &Aacute;vila.  Adem&aacute;s de dos ambulancias de la Cruz Roja y una de Protecci&oacute;n Civil, una unidad m&oacute;vil de Mutua Universal acompa&ntilde;&oacute; a los participantes durante todo el recorrido.  El personal sanitario de Mutua acompa&ntilde;&oacute; la marcha ben&eacute;fica y vel&oacute; por la integridad f&iacute;sica de los participantes. La marcha se desarroll&oacute; sin grandes incidentes.  Actos como la Gran Marcha por la Discapacidad de &Aacute;vila representan una excelente forma de estar presente en la sociedad para la que trabajamos y adem&aacute;s nos permite que continuemos siendo una Entidad de referencia.</p>', '4a51f63753e8c.jpg', '', '2009-07-06', '2009-11-20', 'web', 'publicado', 0, 1, 1, 1, NULL, NULL, NULL, '2009-07-06 15:02:38', NULL, 0);
INSERT INTO `actividad` VALUES (23, 'Egarsat apoya la reinserci�n de discapacitados por accidentes laborales', '', '<p>La patronal Cecot y Mutua Egarsat firmaron hoy un convenio para fomar trabajadores que sufran alg&uacute;n tipo de discapacidad a consecuencia de un accidente laboral y facilitar as&iacute; su reinserci&oacute;n en el mercado laboral</p>', '4a5ef4131705e.jpg', '4a5ef4131aec5.pdf', '2009-08-25', '2009-11-20', 'web', 'publicado', 0, 1, 1, 1, NULL, NULL, NULL, '2009-07-16 11:34:11', NULL, 0);
INSERT INTO `actividad` VALUES (24, 'Premios Imserso Infanta Cristina', '', '<p>Un a&ntilde;o m&aacute;s, el Instituto de Mayores y Servicios Sociales, ha convocado los Premios IMSERSO \\"Infanta Cristina\\" correspondientes a la convocatoria del 2009.  Estos Premios tienen como fin impulsar los servicios sociales y sensibilizar a los diferentes sectores de la sociedad respecto a las necesidades y demandas de las personas mayores y de las personas en situaci&oacute;n de dependencia y sus familias cuidadoras.  Las modalidades convocadas son las siguientes: -Premios al M&eacute;rito Social -Premio de Calidad y Buenas Pr&aacute;cticas -Premios a la investigaci&oacute;n, al desarrollo y a la innovaci&oacute;n -Premios de fotograf&iacute;a -Premios de Comunicaci&oacute;n: prensa, radio, televisi&oacute;n, p&aacute;gina web y publiciadad.  El plazo de admisi&oacute;n de trabajos finaliza el 15 de septiembre de 2009.  Las bases se pueden consultar, en la p&aacute;gina web del IMSERSO www.inserso.es</p>', '', '', '2009-07-21', '2009-11-20', 'web', 'publicado', 0, 1, 1, 1, NULL, NULL, NULL, '2009-07-21 09:23:57', NULL, 0);
INSERT INTO `actividad` VALUES (25, 'Campa�a Europea sobre Evaluaci�n de Riesgos. Trabajos Saludables', '', '<p>Con la Campa&ntilde;a sobre evaluaci&oacute;n de riesgos (2008-2009), la Agencia Europea inici&oacute; un ciclo de Campa&ntilde;a de dos a&ntilde;os cuyos prop&oacute;sitos es hacer que las campa&ntilde;as logren de una manera m&aacute;s eficaz los objetivos de la Estrategia Comunitaria de Salud y Seguridad en el Trabajo 2007-2012.   Durante la Seman Europea 2009, coincidiendo con el segundo a&ntilde;o de la Campa&ntilde;a, se da continuidad a la difusi&oacute;n de los principios de una prevenci&oacute;n basada en la evaluaci&oacute;n de riesgos, con especial atenci&oacute;n dirigida a las pymes y microempresas, as&iacute; como a todas aquellas personas implicadas en la aplicaci&oacute;n de medidas de seguridad y salud en el trabajo, con objeto de promover la adopci&oacute;n de un enfoque integral de la gesti&oacute;n que tenga en cuenta los diferentes pasos del proceso de valuaci&oacute;n de riesgos.</p>', '4accc042048c8.gif', '4accbecabdee5.pdf', '2009-10-07', '2009-11-20', 'web', 'publicado', 0, 1, 1, 1, NULL, NULL, NULL, '2009-10-07 18:16:10', NULL, 0);
INSERT INTO `actividad` VALUES (26, 'El Premio de Buenas Pr�cticas de la AISS para Europa', '', '<p>La identificaci&oacute;n e intercambio de buenas pr&aacute;cticas ayuda a las organizaciones e instituciones de la seguridad social a mejorar su eficacia operativa y administrativa. La AISS ha iniciado un programa de Premios de Buenas Pr&aacute;cticas para reconocer buenas pr&aacute;cticas en la administraci&oacute;n de la seguridad social.    Los Premios de Buenas Pr&aacute;cticas de la AISS ser&aacute;n concedidos de manera regional durante un ciclo trianual en los cuatro Foros Regionales de Seguridad Social de la AISS. En cada Foro se conceder&aacute; un Premio, as&iacute; como certificados de m&eacute;rito, en virtud de la decisi&oacute;n del Jurado. Las cuatro Buenas Pr&aacute;cticas premiadas ser&aacute;n presentadas en el Foro Mundial de la Seguridad Social de Cape Town, Sud&aacute;frica, en 2010.  El cuarto de los cuatro Premios de Buenas Pr&aacute;cticas del trienio ser&aacute; entregado en el Foro Regional de la Seguridad Social para Europa, que se celebrar&aacute; del 3 al 5 de marzo de 2010 en Varsovia, Polonia.  M&aacute;s informaci&oacute;n:  El formulario electr&oacute;nico de presentaci&oacute;n y las directrices para cumplimentarlo pueden ser obtenidos en www-issanet.issa.int.</p>', '4ad4a2f8184ae.jpg', '4ad4a3a34986e.pdf', '2009-10-13', '2009-11-20', 'web', 'publicado', 0, 1, 1, 1, NULL, NULL, NULL, '2009-10-13 17:38:04', NULL, 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `aplicacion`
#

CREATE TABLE `aplicacion` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `nombre_entidad` varchar(150) default NULL,
  `nombre_modulo` varchar(150) default NULL,
  `tipo` varchar(255) default NULL,
  `titulo` varchar(100) default NULL,
  `descripcion` longtext,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1 AUTO_INCREMENT=60 ;

#
# Volcar la base de datos para la tabla `aplicacion`
#

INSERT INTO `aplicacion` VALUES (1, 'Noticias', 'Noticia', 'noticias', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (2, 'Eventos', 'Evento', 'eventos', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (3, 'Agenda', 'Agenda', 'agenda', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (4, 'Asambleas Directores', 'AsambleaDirectores', 'asamblea_director', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (5, 'Usuarios', 'Usuario', 'usuarios', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (6, 'Aplicaciones por Rol', 'AplicacionRol', 'aplicaciones_rol', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (7, 'Home', NULL, 'inicio', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (8, 'Contacto', NULL, 'contacto', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (9, 'Emails de Contacto', 'CategoriaAsunto', 'categoria_asunto', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (10, 'Circulares - Categorias de Tema', 'CircularCatTema', 'circular_cat_tema', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (11, 'Circulares - Subcategorias de Tema', 'CircularSubTema', 'circular_sub_tema', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (12, 'Circulares', 'Circular', 'circulares', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (13, 'Normativas', 'Normativa', 'normativas', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (14, 'Iniciativas Formativas', 'Iniciativa', 'iniciativas', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (15, 'Mutuas', 'Mutua', 'mutuas', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (16, 'Actas Grupo', 'Acta Grupo', 'acta_grupo', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (17, 'Notificaciones', 'Notificacion', 'notificaciones', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (18, 'Cifras y Datos', 'CifraDato', 'cifras_datos', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (19, 'Actividades', 'Actividad', 'actividades', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (20, 'Publicaciones', 'Publicacion', 'publicaciones', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (21, 'Grupos de Trabajo', 'GrupoTrabajo', 'grupos_de_trabajo', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (22, 'Consejos Territoriales', 'ConsejoTerritorial', 'consejos_territoriales', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (23, 'Aplicaciones Externas', 'AplicacionExterna', 'aplicaciones_externas', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (24, 'Documentacion Grupos de Trabajo', 'DocumentacionGrupo', 'documentacion_grupos', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (25, 'Categorias de Documentacion Grupos de Trabajo', 'CategoriaDG', 'categorias_d_g', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (26, 'Archivos de Grupos de Trabajo', 'ArchivoDG', 'archivos_d_g', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (27, 'Categorias de Consejos Territoriales', 'CategoriaCT', 'categorias_c_t', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (28, 'Documentacion de Consejos Territoriales', 'DocumentacionConsejo', 'documentacion_consejos', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (29, 'Archivos de Consejos Territoriales', 'ArchivoCT', 'archivos_c_t', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (30, 'Categorias de Organismos', 'CategoriaOrganismo', 'categoria_organismos', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (31, 'Subcategorias de Organismos', 'SubCategoriaOrganismo', 'subcategoria_organismos', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (32, 'Gesti�n de Organismos', 'Organismo', 'organismos', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (33, 'Documentaci�n de Organismos', 'DocumentacionOrganismo', 'documentacion_organismos', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (34, 'Archivos de Organismos', 'ArchivoDO', 'archivos_d_o', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (35, 'Listas de envios de Comunicados', 'ListaComunicado', 'listas_comunicados', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (36, 'Tipos de Comunicados', 'TipoComunicado', 'tipos_comunicado', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (37, 'Comunicados', 'Comunicado', 'comunicados', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (38, 'Envio de Comunicados', 'EnvioComunicado', 'envio_comunicados', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (39, 'Menu de navegacion', 'Menu', 'menu', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (40, 'Aplicaciones Externas de Usuario', 'UsuarioAplicacionExterna', 'aplicaciones_externas_usuario', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (41, 'Miembros Grupo', NULL, 'miembros_grupo', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (42, 'Convocatoria Grupo de Trabajo', 'Asamblea gRUPO', 'asamblea_grupo', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (43, 'Convocatoria Consejo Territorial', 'Asamblea Consejo', 'asamblea_consejos', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (44, 'Asamblea', 'asamblea', 'asambleas', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (45, 'Acta Consejo', 'Acta Consejo', 'acta_consejo', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (46, 'Acta', 'Acta', 'acta', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion` VALUES (47, 'Miembros Consejos', NULL, 'miembros_consejo', 'front', NULL, NULL, '2009-11-18 16:05:49', '2009-11-18 16:05:49', 0);
INSERT INTO `aplicacion` VALUES (48, 'Convocatoria Organismo', NULL, 'asamblea_organismo', 'front', NULL, NULL, NULL, NULL, 0);
INSERT INTO `aplicacion` VALUES (49, 'Actas Organismos', NULL, 'acta_organismos', 'front', NULL, NULL, NULL, NULL, 0);
INSERT INTO `aplicacion` VALUES (50, 'Miembros de Organismos', NULL, 'miembros_organismo', 'front', NULL, NULL, NULL, NULL, 0);
INSERT INTO `aplicacion` VALUES (51, 'Gestion de Aplicaciones', NULL, 'aplicaciones', 'front', NULL, NULL, '2009-11-24 14:30:14', '2009-11-24 14:30:14', 0);
INSERT INTO `aplicacion` VALUES (52, 'Prueba de icox', 'aplicacion', 'aplicaciones', 'front', 'pruba iocx', '<div class="noticias nuevodetalle" style="padding-top: 20px"><img alt="" align="left" nottit="" style="width: 124px; margin-right: 10px; height: 138px" src="/uploads/image/noimage.jpg" />Titulo<br /><p class="notentrada" style="font-weight: bold">Entradilla</p><p style="margin: 10px 0px; color: rgb(204,204,204); border-bottom: 1px dotted">&nbsp;</p><p>Desccripcion</p><div class="clear">&nbsp;</div></div>', '2009-11-24 19:06:38', '2009-11-24 19:06:38', 0);
INSERT INTO `aplicacion` VALUES (53, 'Una', 'aplicacion', 'aplicaciones', 'front', 'Otra', '<div class="noticias nuevodetalle" style="padding-top: 20px;"><img align="left" alt="" style="margin-right: 10px; width: 124px; height: 138px;" nottit="" src="/uploads/image/noimage.jpg" />Mikel</div>', '2009-11-30 21:28:54', '2009-11-30 21:28:54', 0);
INSERT INTO `aplicacion` VALUES (54, 'Normas de funcionamientos', 'NormasDeFuncionamientos', 'normas_de_funcionamientos', NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `aplicacion` VALUES (55, 'Junta Directiva', NULL, 'asamblea_junta', 'front', NULL, NULL, NULL, NULL, 0);
INSERT INTO `aplicacion` VALUES (56, 'Convocatorias - Otros', NULL, 'asamblea_otros', 'front', NULL, NULL, NULL, NULL, 0);
INSERT INTO `aplicacion` VALUES (57, 'Web Amat', 'aplicacion', 'aplicaciones', 'front', 'Web Amat', '<div class="noticias nuevodetalle" style="padding-top: 20px"><img alt="" align="left" nottit="" style="width: 124px; margin-right: 10px; height: 138px" src="/uploads/image/noimage.jpg" />Titulo<br /><p class="notentrada" style="font-weight: bold">Entradilla</p><p style="margin: 10px 0px; color: rgb(204,204,204); border-bottom: 1px dotted">&nbsp;</p><p>Desccripcion</p><div class="clear">&nbsp;</div></div>', '2009-12-29 16:59:55', '2009-12-29 16:59:55', 0);
INSERT INTO `aplicacion` VALUES (58, 'Organismos', 'aplicacion', 'aplicaciones', 'front', 'Organismos', '<div class="noticias nuevodetalle" style="padding-top: 20px"><img alt="" align="left" nottit="" style="width: 124px; margin-right: 10px; height: 138px" src="/uploads/image/noimage.jpg" />Titulo<br /><p class="notentrada" style="font-weight: bold">Entradilla</p><p style="margin: 10px 0px; color: rgb(204,204,204); border-bottom: 1px dotted">&nbsp;</p><p>Desccripcion</p><div class="clear">&nbsp;</div></div>', '2009-12-29 17:00:28', '2009-12-29 17:00:28', 0);
INSERT INTO `aplicacion` VALUES (59, 'Perfiles', 'Rol', 'perfiles', 'front', NULL, NULL, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `aplicacion_accion`
#

CREATE TABLE `aplicacion_accion` (
  `id` bigint(20) NOT NULL auto_increment,
  `accion` varchar(255) default NULL,
  `accion_del_modulo` varchar(128) default NULL,
  `aplicacion_id` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `aplicacion_id_idx` (`aplicacion_id`),
  CONSTRAINT `aplicacion_accion_ibfk_1` FOREIGN KEY (`aplicacion_id`) REFERENCES `aplicacion` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=341 DEFAULT CHARSET=latin1 AUTO_INCREMENT=341 ;

#
# Volcar la base de datos para la tabla `aplicacion_accion`
#

INSERT INTO `aplicacion_accion` VALUES (1, 'listar', 'index', 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (2, 'alta', 'nueva', 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (3, 'alta', 'create', 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (4, 'modificar', 'editar', 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (5, 'modificar', 'update', 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (6, 'baja', 'delete', 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (7, 'publicar', 'publicar', 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (8, 'listar', 'index', 2, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (9, 'alta', 'nuevo', 2, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (10, 'alta', 'create', 2, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (11, 'modificar', 'editar', 2, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (12, 'modificar', 'update', 2, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (13, 'baja', 'delete', 2, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (14, 'publicar', 'publicar', 2, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (15, 'listar', 'index', 3, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (16, 'listar', 'index', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (17, 'listar', 'lista', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (18, 'listar', 'acta', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (19, 'publicar', 'convocar', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (20, 'listar', 'aceptar', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (21, 'listar', 'rechazar', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (22, 'listar', 'ver', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (23, 'alta', 'nueva', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (24, 'alta', 'create', 4, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (25, 'modificar', 'editar', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (26, 'modificar', 'update', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (27, 'baja', 'delete', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (28, 'baja', 'anular', 44, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (29, 'listar', 'index', 5, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (30, 'alta', 'nuevo', 5, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (31, 'alta', 'create', 5, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (32, 'modificar', 'editar', 5, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (33, 'modificar', 'update', 5, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (34, 'baja', 'delete', 5, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (35, 'listar', 'index', 6, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (36, 'alta', 'nuevo', 6, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (37, 'alta', 'create', 6, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (38, 'modificar', 'editar', 6, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (39, 'modificar', 'update', 6, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (40, 'baja', 'delete', 6, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (41, 'listar', 'index', 7, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (42, 'listar', 'index', 8, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (43, 'alta', 'process', 8, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (44, 'listar', 'index', 9, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (45, 'alta', 'nueva', 9, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (46, 'alta', 'create', 9, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (47, 'baja', 'delete', 9, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (48, 'modificar', 'editar', 9, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (49, 'modificar', 'update', 9, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (50, 'listar', 'index', 10, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (51, 'alta', 'nueva', 10, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (52, 'alta', 'create', 10, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (53, 'baja', 'delete', 10, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (54, 'modificar', 'editar', 10, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (55, 'modificar', 'update', 10, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (56, 'listar', 'index', 11, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (57, 'alta', 'nueva', 11, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (58, 'alta', 'create', 11, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (59, 'baja', 'delete', 11, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (60, 'modificar', 'editar', 11, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (61, 'modificar', 'update', 11, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (62, 'listar', 'index', 12, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (63, 'alta', 'nueva', 12, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (64, 'alta', 'create', 12, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (65, 'baja', 'delete', 12, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (66, 'modificar', 'editar', 12, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (67, 'modificar', 'update', 12, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (68, 'listar', 'index', 13, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (69, 'alta', 'nueva', 13, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (70, 'alta', 'create', 13, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (71, 'baja', 'delete', 13, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (72, 'modificar', 'editar', 13, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (73, 'modificar', 'update', 13, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (74, 'listar', 'index', 14, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (75, 'alta', 'nueva', 14, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (76, 'alta', 'create', 14, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (77, 'baja', 'delete', 14, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (78, 'modificar', 'editar', 14, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (79, 'modificar', 'update', 14, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (80, 'listar', 'index', 15, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (81, 'alta', 'nueva', 15, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (82, 'alta', 'create', 15, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (83, 'baja', 'delete', 15, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (84, 'modificar', 'editar', 15, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (85, 'modificar', 'update', 15, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (86, 'listar', 'index', 46, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (87, 'alta', 'nueva', 46, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (88, 'alta', 'create', 46, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (89, 'baja', 'delete', 46, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (90, 'modificar', 'editar', 46, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (91, 'modificar', 'update', 46, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (92, 'listar', 'index', 17, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (93, 'alta', 'nueva', 17, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (94, 'alta', 'create', 17, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (95, 'baja', 'delete', 17, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (96, 'modificar', 'editar', 17, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (97, 'modificar', 'update', 17, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (98, 'publicar', 'show', 15, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (99, 'alta', 'nueva', 18, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (100, 'baja', 'delete', 18, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (101, 'modificar', 'editar', 18, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (102, 'listar', 'index', 18, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (103, 'modificar', 'update', 18, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (104, 'alta', 'nueva', 19, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (105, 'baja', 'delete', 19, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (106, 'modificar', 'editar', 19, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (107, 'listar', 'index', 19, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (108, 'modificar', 'update', 19, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (109, 'alta', 'nueva', 20, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (110, 'baja', 'delete', 20, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (111, 'modificar', 'editar', 20, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (112, 'listar', 'index', 20, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (113, 'modificar', 'update', 20, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (114, 'modificar', 'perfil', 5, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (115, 'alta', 'create', 18, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (116, 'alta', 'create', 19, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (117, 'alta', 'create', 20, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (118, 'listar', 'index', 21, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (119, 'alta', 'nueva', 21, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (120, 'alta', 'create', 21, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (121, 'modificar', 'editar', 21, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (122, 'modificar', 'update', 21, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (123, 'baja', 'delete', 21, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (124, 'publicar', 'publicar', 21, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (125, 'listar', 'index', 22, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (126, 'alta', 'nueva', 22, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (127, 'alta', 'create', 22, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (128, 'modificar', 'editar', 22, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (129, 'modificar', 'update', 22, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (130, 'baja', 'delete', 22, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (131, 'publicar', 'publicar', 22, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (132, 'listar', 'ver', 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (133, 'listar', 'index', 23, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (134, 'alta', 'nueva', 23, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (135, 'alta', 'create', 23, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (136, 'modificar', 'editar', 23, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (137, 'modificar', 'update', 23, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (138, 'baja', 'delete', 23, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (139, 'listar', 'show', 18, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (140, 'listar', 'show', 19, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (141, 'listar', 'show', 20, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (142, 'listar', 'show', 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (143, 'listar', 'show', 2, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (144, 'listar', 'show', 13, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (145, 'listar', 'show', 14, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (146, 'listar', 'show', 12, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (147, 'listar', 'index', 24, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (148, 'alta', 'nueva', 24, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (149, 'alta', 'create', 24, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (150, 'modificar', 'editar', 24, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (151, 'modificar', 'update', 24, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (152, 'baja', 'delete', 24, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (153, 'publicar', 'publicar', 24, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (154, 'listar', 'show', 24, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (155, 'listar', 'index', 25, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (156, 'alta', 'nueva', 25, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (157, 'alta', 'create', 25, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (158, 'modificar', 'editar', 25, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (159, 'modificar', 'update', 25, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (160, 'baja', 'delete', 25, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (161, 'listar', 'show', 25, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (162, 'listar', 'index', 26, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (163, 'alta', 'nueva', 26, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (164, 'alta', 'create', 26, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (165, 'modificar', 'editar', 26, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (166, 'modificar', 'update', 26, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (167, 'baja', 'delete', 26, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (168, 'listar', 'show', 26, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (169, 'listar', 'index', 27, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (170, 'alta', 'nueva', 27, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (171, 'alta', 'create', 27, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (172, 'modificar', 'editar', 27, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (173, 'modificar', 'update', 27, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (174, 'baja', 'delete', 27, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (175, 'listar', 'show', 27, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (176, 'listar', 'index', 28, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (177, 'alta', 'nueva', 28, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (178, 'alta', 'create', 28, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (179, 'modificar', 'editar', 28, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (180, 'modificar', 'update', 28, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (181, 'baja', 'delete', 28, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (182, 'publicar', 'publicar', 28, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (183, 'listar', 'show', 28, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (184, 'listar', 'index', 29, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (185, 'alta', 'nueva', 29, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (186, 'alta', 'create', 29, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (187, 'modificar', 'editar', 29, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (188, 'modificar', 'update', 29, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (189, 'baja', 'delete', 29, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (190, 'publicar', 'publicar', 29, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (191, 'listar', 'show', 29, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (192, 'listar', 'index', 30, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (193, 'alta', 'nueva', 30, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (194, 'alta', 'create', 30, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (195, 'modificar', 'editar', 30, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (196, 'modificar', 'update', 30, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (197, 'baja', 'delete', 30, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (198, 'publicar', 'publicar', 30, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (199, 'listar', 'show', 30, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (200, 'listar', 'index', 31, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (201, 'alta', 'nueva', 31, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (202, 'alta', 'create', 31, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (203, 'modificar', 'editar', 31, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (204, 'modificar', 'update', 31, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (205, 'baja', 'delete', 31, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (206, 'publicar', 'publicar', 31, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (207, 'listar', 'show', 31, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (208, 'listar', 'index', 32, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (209, 'alta', 'nueva', 32, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (210, 'alta', 'create', 32, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (211, 'modificar', 'editar', 32, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (212, 'modificar', 'update', 32, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (213, 'baja', 'delete', 32, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (214, 'publicar', 'publicar', 32, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (215, 'listar', 'show', 32, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (216, 'listar', 'index', 33, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (217, 'alta', 'nueva', 33, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (218, 'alta', 'create', 33, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (219, 'modificar', 'editar', 33, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (220, 'modificar', 'update', 33, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (221, 'baja', 'delete', 33, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (222, 'publicar', 'publicar', 33, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (223, 'listar', 'show', 33, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (224, 'listar', 'index', 34, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (225, 'alta', 'nueva', 34, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (226, 'alta', 'create', 34, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (227, 'modificar', 'editar', 34, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (228, 'modificar', 'update', 34, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (229, 'baja', 'delete', 34, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (230, 'publicar', 'publicar', 34, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (231, 'listar', 'show', 34, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (232, 'listar', 'index', 35, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (233, 'alta', 'nueva', 35, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (234, 'alta', 'create', 35, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (235, 'modificar', 'editar', 35, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (236, 'modificar', 'update', 35, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (237, 'baja', 'delete', 35, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (238, 'publicar', 'publicar', 35, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (239, 'listar', 'show', 35, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (240, 'listar', 'index', 36, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (241, 'alta', 'nueva', 36, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (242, 'alta', 'create', 36, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (243, 'modificar', 'editar', 36, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (244, 'modificar', 'update', 36, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (245, 'baja', 'delete', 36, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (246, 'publicar', 'publicar', 36, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (247, 'listar', 'show', 36, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (248, 'listar', 'index', 37, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (249, 'alta', 'nueva', 37, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (250, 'alta', 'create', 37, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (251, 'modificar', 'editar', 37, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (252, 'modificar', 'update', 37, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (253, 'baja', 'delete', 37, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (254, 'publicar', 'publicar', 37, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (255, 'listar', 'show', 37, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (256, 'listar', 'index', 38, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (257, 'alta', 'nueva', 38, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (258, 'alta', 'create', 38, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (259, 'modificar', 'editar', 38, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (260, 'modificar', 'update', 38, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (261, 'baja', 'delete', 38, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (262, 'publicar', 'publicar', 38, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (263, 'listar', 'show', 38, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (264, 'listar', 'index', 39, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (265, 'alta', 'nueva', 39, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (266, 'alta', 'create', 39, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (267, 'modificar', 'editar', 39, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (268, 'modificar', 'update', 39, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (269, 'baja', 'delete', 39, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (270, 'publicar', 'publicar', 39, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (271, 'listar', 'show', 39, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (272, 'listar', 'index', 40, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (273, 'alta', 'nueva', 40, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (274, 'alta', 'create', 40, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (275, 'modificar', 'editar', 40, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (276, 'modificar', 'update', 40, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (277, 'baja', 'delete', 40, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (278, 'publicar', 'publicar', 40, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (279, 'listar', 'show', 40, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (280, 'publicar', 'convocados', 44, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (281, 'publicar', 'ver', 46, '2009-11-16 14:53:26', '2009-11-16 14:53:26', 0);
INSERT INTO `aplicacion_accion` VALUES (283, 'listar', 'index', 51, '2009-11-24 14:30:16', '2009-11-24 14:30:16', 0);
INSERT INTO `aplicacion_accion` VALUES (284, 'alta', 'nueva', 51, '2009-11-24 14:30:16', '2009-11-24 14:30:16', 0);
INSERT INTO `aplicacion_accion` VALUES (285, 'alta', 'create', 51, '2009-11-24 14:30:16', '2009-11-24 14:30:16', 0);
INSERT INTO `aplicacion_accion` VALUES (286, 'publicar', 'show', 51, '2009-11-24 14:30:16', '2009-11-24 14:30:16', 0);
INSERT INTO `aplicacion_accion` VALUES (287, 'modificar', 'editar', 51, '2009-11-24 14:30:16', '2009-11-24 14:30:16', 0);
INSERT INTO `aplicacion_accion` VALUES (288, 'modificar', 'update', 51, '2009-11-24 14:30:16', '2009-11-24 14:30:16', 0);
INSERT INTO `aplicacion_accion` VALUES (289, 'baja', 'delete', 51, '2009-11-24 14:30:16', '2009-11-24 14:30:16', 0);
INSERT INTO `aplicacion_accion` VALUES (290, 'listar', 'index', 54, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (291, 'alta', 'nueva', 54, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (292, 'alta', 'create', 54, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (293, 'modificar', 'editar', 54, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (294, 'modificar', 'update', 54, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (295, 'baja', 'delete', 54, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (296, 'publicar', 'publicar', 54, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (297, 'listar', 'show', 54, NULL, NULL, 0);
INSERT INTO `aplicacion_accion` VALUES (298, 'listar', 'index', 50, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (299, 'alta', 'nueva', 50, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (300, 'alta', 'create', 50, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (301, 'modificar', 'editar', 50, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (302, 'modificar', 'update', 50, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (303, 'baja', 'delete', 50, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (304, 'publicar', 'publicar', 50, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (305, 'listar', 'show', 50, NULL, NULL, 0);
INSERT INTO `aplicacion_accion` VALUES (306, 'listar', 'index', 55, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (307, 'alta', 'nueva', 55, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (308, 'alta', 'create', 55, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (309, 'modificar', 'editar', 55, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (310, 'modificar', 'update', 55, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (311, 'baja', 'delete', 55, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (312, 'publicar', 'publicar', 55, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (313, 'listar', 'show', 55, NULL, NULL, 0);
INSERT INTO `aplicacion_accion` VALUES (314, 'listar', 'index', 56, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (315, 'alta', 'nueva', 56, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (316, 'alta', 'create', 56, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (317, 'modificar', 'editar', 56, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (318, 'modificar', 'update', 56, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (319, 'baja', 'delete', 56, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (320, 'publicar', 'publicar', 56, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (321, 'listar', 'show', 56, NULL, NULL, 0);
INSERT INTO `aplicacion_accion` VALUES (322, 'listar', 'index', 41, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (323, 'listar', 'index', 47, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (324, 'listar', 'index', 50, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `aplicacion_accion` VALUES (325, 'alta', 'create', 44, '2010-01-15 19:46:59', '2010-01-15 19:46:59', 0);
INSERT INTO `aplicacion_accion` VALUES (334, 'listar', 'index', 59, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (335, 'alta', 'nueva', 59, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (336, 'alta', 'create', 59, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (337, 'modificar', 'editar', 59, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (338, 'modificar', 'update', 59, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (339, 'baja', 'delete', 59, '2009-12-03 13:15:34', '2009-12-03 13:15:34', 0);
INSERT INTO `aplicacion_accion` VALUES (340, 'listar', 'listausuario', 6, '2010-01-22 11:38:06', '2010-01-22 11:38:10', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `aplicacion_externa`
#

CREATE TABLE `aplicacion_externa` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(100) default NULL,
  `detalle` longtext,
  `imagen` varchar(100) default NULL,
  `url` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

#
# Volcar la base de datos para la tabla `aplicacion_externa`
#

INSERT INTO `aplicacion_externa` VALUES (1, 'Web AMAT', '', 'f401d04aa536ed798e88e104e2340f17d4f96e17.jpg', 'http://www.amat.es', '2009-10-20 17:49:34', '2009-11-07 09:54:10', 0);
INSERT INTO `aplicacion_externa` VALUES (2, ' RESINA', '', 'f3f58a2539e8f2c0813789abbd28461f02867025.jpg', 'http://resina.amat.es', '2009-10-20 17:49:34', '2009-12-29 18:07:50', 0);
INSERT INTO `aplicacion_externa` VALUES (3, 'Estadisticas Qualitel', '', '01d3455fdd7b9b8b64eb37cc234e8116e5a06dff.jpg', '', '2009-10-20 17:49:34', '2009-11-07 09:54:17', 1);
INSERT INTO `aplicacion_externa` VALUES (4, 'ertertert', '', NULL, 'ertertertertert', '2009-10-22 22:00:48', '2009-10-22 22:00:55', 1);
INSERT INTO `aplicacion_externa` VALUES (5, 'mauro', '', '712428dc5ca746523726fa2351671c01e6585f8e.jpg', 'http://www.iua.edu.ar', '2009-11-05 20:18:33', '2009-11-05 20:37:11', 1);
INSERT INTO `aplicacion_externa` VALUES (6, 'OVR - Reclamaciones - Litigios', '', '166edc53180388c179b55161f08ace98c257ea01.jpg', 'https://www.ovrmatepss.es/AdmIn', '2009-11-07 09:59:52', '2009-12-29 18:08:29', 0);
INSERT INTO `aplicacion_externa` VALUES (7, 'Recursos Sanitarios', '', '87c2bbbffee93473a584136420848c789fd60483.jpg', 'http://indigo.amat.es', '2009-11-07 10:01:26', '2009-12-29 18:08:52', 0);
INSERT INTO `aplicacion_externa` VALUES (8, 'ITCC', '', '118964199b6b4607591631260cfc596f83d4996f.jpg', 'http://itcc.amat.es', '2009-11-20 19:52:21', '2009-12-29 18:08:11', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `aplicacion_rol`
#

CREATE TABLE `aplicacion_rol` (
  `id` bigint(20) NOT NULL auto_increment,
  `accion_alta` tinyint(1) default NULL,
  `accion_baja` tinyint(1) default NULL,
  `accion_modificar` tinyint(1) default NULL,
  `accion_listar` tinyint(1) default NULL,
  `accion_publicar` tinyint(1) default NULL,
  `aplicacion_id` bigint(20) default NULL,
  `rol_id` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `aplicacion_id_idx` (`aplicacion_id`),
  KEY `rol_id_idx` (`rol_id`),
  CONSTRAINT `aplicacion_rol_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`) ON DELETE CASCADE,
  CONSTRAINT `aplicacion_rol_ibfk_2` FOREIGN KEY (`aplicacion_id`) REFERENCES `aplicacion` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=latin1 AUTO_INCREMENT=184 ;

#
# Volcar la base de datos para la tabla `aplicacion_rol`
#

INSERT INTO `aplicacion_rol` VALUES (1, 1, 1, 1, 1, 1, 1, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (2, 1, 1, 1, 1, 1, 2, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (3, 1, 1, 1, 1, 1, 3, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (5, 1, 1, 1, 1, 1, 5, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (6, 1, 0, 0, 0, 0, 1, 2, '2009-11-16 14:53:24', '2009-12-22 10:00:19', 1);
INSERT INTO `aplicacion_rol` VALUES (7, 1, 0, 0, 0, 0, 2, 2, '2009-11-16 14:53:24', '2009-12-22 10:00:28', 1);
INSERT INTO `aplicacion_rol` VALUES (8, 1, 0, 0, 0, 0, 3, 2, '2009-11-16 14:53:24', '2009-12-22 10:00:34', 1);
INSERT INTO `aplicacion_rol` VALUES (10, 1, 0, 0, 0, 0, 5, 2, '2009-11-16 14:53:24', '2009-12-22 10:00:40', 1);
INSERT INTO `aplicacion_rol` VALUES (11, 1, 1, 1, 1, 1, 6, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (12, 1, 1, 1, 1, 1, 6, 2, '2009-11-16 14:53:24', '2009-12-22 10:00:46', 1);
INSERT INTO `aplicacion_rol` VALUES (13, 1, 1, 1, 1, 1, 7, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (14, 1, 1, 1, 1, 1, 7, 2, '2009-11-16 14:53:24', '2009-12-22 09:59:56', 1);
INSERT INTO `aplicacion_rol` VALUES (15, 1, 1, 1, 1, 1, 8, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (16, 1, 1, 1, 1, 1, 8, 2, '2009-11-16 14:53:24', '2009-12-22 10:00:14', 1);
INSERT INTO `aplicacion_rol` VALUES (17, 1, 1, 1, 1, 1, 9, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (18, 1, 1, 1, 1, 1, 10, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (19, 1, 1, 1, 1, 1, 11, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (20, 1, 1, 1, 1, 1, 12, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (22, 1, 1, 1, 1, 1, 14, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (23, 1, 1, 1, 1, 1, 15, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (25, 1, 1, 1, 1, 1, 17, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (26, 1, 1, 1, 1, 1, 18, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (27, 1, 1, 1, 1, 1, 19, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (28, 1, 1, 1, 1, 1, 20, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (29, 1, 1, 1, 1, 1, 21, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (30, 1, 1, 1, 1, 1, 22, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (31, 1, 1, 1, 1, 1, 23, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (32, 1, 1, 1, 1, 1, 24, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (33, 1, 1, 1, 1, 1, 25, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (34, 1, 1, 1, 1, 1, 26, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (35, 1, 1, 1, 1, 1, 27, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (36, 1, 1, 1, 1, 1, 28, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (37, 1, 1, 1, 1, 1, 29, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (38, 1, 1, 1, 1, 1, 30, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (39, 1, 1, 1, 1, 1, 31, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (40, 1, 1, 1, 1, 1, 32, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (41, 1, 1, 1, 1, 1, 33, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (42, 1, 1, 1, 1, 1, 34, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (43, 1, 1, 1, 1, 1, 2, 4, '2009-11-16 14:53:24', '2009-11-16 19:09:05', 1);
INSERT INTO `aplicacion_rol` VALUES (44, 1, 1, 1, 1, 1, 1, 7, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (45, 0, 0, 0, 1, 0, 2, 4, '2009-11-16 14:53:24', '2009-12-18 12:02:40', 0);
INSERT INTO `aplicacion_rol` VALUES (46, 0, 0, 0, 1, 0, 3, 4, '2009-11-16 14:53:24', '2009-12-18 12:02:48', 0);
INSERT INTO `aplicacion_rol` VALUES (47, 1, 1, 1, 1, 1, 3, 7, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (48, 1, 1, 1, 1, 1, 3, 7, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (49, 1, 1, 1, 1, 1, 2, 6, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (50, 1, 1, 1, 1, 1, 3, 6, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (51, 1, 1, 1, 1, 1, 35, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (52, 1, 1, 1, 1, 1, 36, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (53, 1, 1, 1, 1, 1, 37, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (54, 1, 1, 1, 1, 1, 38, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (58, 1, 1, 1, 1, 1, 39, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (59, 1, 1, 1, 1, 1, 40, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `aplicacion_rol` VALUES (100, 1, 1, 1, 1, 1, 4, 2, '2009-11-16 19:08:53', '2009-12-22 10:00:51', 1);
INSERT INTO `aplicacion_rol` VALUES (101, 1, 1, 1, 1, 1, 44, 2, '2009-11-16 19:08:53', '2009-12-22 10:00:51', 1);
INSERT INTO `aplicacion_rol` VALUES (102, 0, 0, 0, 1, 0, 42, 4, '2009-11-16 19:09:38', '2009-12-18 12:05:01', 0);
INSERT INTO `aplicacion_rol` VALUES (103, 0, 0, 0, 1, 0, 44, 4, '2009-11-16 19:09:38', '2009-12-18 12:04:50', 0);
INSERT INTO `aplicacion_rol` VALUES (104, 1, 0, 1, 1, 1, 42, 6, '2009-11-16 19:10:08', '2009-11-16 19:10:08', 0);
INSERT INTO `aplicacion_rol` VALUES (105, 1, 0, 1, 1, 1, 44, 6, '2009-11-16 19:10:08', '2009-11-16 19:10:08', 0);
INSERT INTO `aplicacion_rol` VALUES (106, 0, 0, 0, 1, 0, 43, 5, '2009-11-16 19:10:33', '2009-12-29 09:20:41', 0);
INSERT INTO `aplicacion_rol` VALUES (107, 0, 0, 0, 1, 0, 44, 5, '2009-11-16 19:10:33', '2009-12-29 09:20:41', 0);
INSERT INTO `aplicacion_rol` VALUES (108, 1, 0, 1, 1, 1, 43, 7, '2009-11-16 19:11:03', '2009-11-16 19:11:03', 0);
INSERT INTO `aplicacion_rol` VALUES (109, 1, 0, 1, 1, 1, 44, 7, '2009-11-16 19:11:03', '2009-11-16 19:11:03', 0);
INSERT INTO `aplicacion_rol` VALUES (110, 0, 0, 0, 1, 0, 16, 4, '2009-11-16 19:12:34', '2009-12-18 12:04:41', 0);
INSERT INTO `aplicacion_rol` VALUES (111, 0, 0, 0, 1, 0, 46, 4, '2009-11-16 19:12:34', '2009-12-18 12:04:37', 0);
INSERT INTO `aplicacion_rol` VALUES (112, 0, 0, 0, 1, 0, 45, 5, '2009-11-16 19:12:55', '2009-12-29 09:20:50', 0);
INSERT INTO `aplicacion_rol` VALUES (113, 0, 0, 0, 1, 0, 46, 5, '2009-11-16 19:12:55', '2009-12-29 09:20:50', 0);
INSERT INTO `aplicacion_rol` VALUES (114, 1, 0, 1, 1, 1, 16, 6, '2009-11-16 19:13:15', '2009-11-16 19:13:15', 0);
INSERT INTO `aplicacion_rol` VALUES (115, 1, 0, 1, 1, 1, 46, 6, '2009-11-16 19:13:15', '2009-11-16 19:13:15', 0);
INSERT INTO `aplicacion_rol` VALUES (116, 1, 0, 1, 1, 1, 45, 7, '2009-11-16 19:13:31', '2009-11-16 19:13:31', 0);
INSERT INTO `aplicacion_rol` VALUES (117, 1, 0, 1, 1, 1, 46, 7, '2009-11-16 19:13:31', '2009-11-16 19:13:31', 0);
INSERT INTO `aplicacion_rol` VALUES (118, 1, 1, 1, 1, 1, 4, 1, '2009-11-16 19:14:49', '2009-11-16 19:14:49', 0);
INSERT INTO `aplicacion_rol` VALUES (119, 1, 1, 1, 1, 1, 44, 1, '2009-11-16 19:14:49', '2009-11-16 19:14:49', 0);
INSERT INTO `aplicacion_rol` VALUES (120, 1, 1, 1, 1, 1, 42, 1, '2009-11-16 19:15:44', '2009-11-16 19:15:44', 0);
INSERT INTO `aplicacion_rol` VALUES (121, 1, 1, 1, 1, 1, 44, 1, '2009-11-16 19:15:44', '2009-11-16 19:15:44', 0);
INSERT INTO `aplicacion_rol` VALUES (122, 1, 1, 1, 1, 1, 43, 1, '2009-11-16 19:16:03', '2009-11-16 19:16:03', 0);
INSERT INTO `aplicacion_rol` VALUES (123, 1, 1, 1, 1, 1, 44, 1, '2009-11-16 19:16:03', '2009-11-16 19:16:03', 0);
INSERT INTO `aplicacion_rol` VALUES (124, 1, 1, 1, 1, 1, 16, 1, '2009-11-16 19:16:24', '2009-11-16 19:16:24', 0);
INSERT INTO `aplicacion_rol` VALUES (125, 1, 1, 1, 1, 1, 46, 1, '2009-11-16 19:16:24', '2009-11-16 19:16:24', 0);
INSERT INTO `aplicacion_rol` VALUES (126, 1, 1, 1, 1, 1, 45, 1, '2009-11-16 19:16:40', '2009-11-16 19:16:40', 0);
INSERT INTO `aplicacion_rol` VALUES (127, 1, 1, 1, 1, 1, 46, 1, '2009-11-16 19:16:40', '2009-11-16 19:16:40', 0);
INSERT INTO `aplicacion_rol` VALUES (128, 1, 1, 1, 1, 1, 24, 8, '2009-11-18 18:36:14', '2009-11-18 18:36:14', 0);
INSERT INTO `aplicacion_rol` VALUES (129, 0, 0, 0, 1, 1, 17, 8, '2009-11-18 18:46:11', '2009-11-18 18:46:11', 0);
INSERT INTO `aplicacion_rol` VALUES (130, 0, 0, 0, 1, 0, 47, 5, '2009-11-18 20:41:33', '2009-12-29 09:20:59', 0);
INSERT INTO `aplicacion_rol` VALUES (131, 0, 0, 0, 1, 1, 47, 7, '2009-11-18 20:41:55', '2009-11-18 20:41:55', 0);
INSERT INTO `aplicacion_rol` VALUES (132, 1, 1, 1, 1, 1, 48, 6, '2009-11-19 20:14:45', '2009-11-19 20:14:45', 0);
INSERT INTO `aplicacion_rol` VALUES (133, 1, 1, 1, 1, 1, 44, 6, '2009-11-19 20:14:45', '2009-11-19 20:14:45', 0);
INSERT INTO `aplicacion_rol` VALUES (134, 1, 1, 1, 1, 1, 48, 2, '2009-11-19 20:15:05', '2009-12-22 10:00:57', 1);
INSERT INTO `aplicacion_rol` VALUES (135, 1, 1, 1, 1, 1, 44, 2, '2009-11-19 20:15:05', '2009-12-22 10:00:57', 1);
INSERT INTO `aplicacion_rol` VALUES (136, 1, 1, 1, 1, 1, 48, 1, '2009-11-19 20:15:21', '2009-11-19 20:15:21', 0);
INSERT INTO `aplicacion_rol` VALUES (137, 1, 1, 1, 1, 1, 44, 1, '2009-11-19 20:15:21', '2009-11-19 20:15:21', 0);
INSERT INTO `aplicacion_rol` VALUES (138, 1, 0, 1, 1, 1, 49, 6, '2009-11-19 20:57:35', '2009-11-19 20:57:35', 0);
INSERT INTO `aplicacion_rol` VALUES (139, 1, 0, 1, 1, 1, 46, 6, '2009-11-19 20:57:35', '2009-11-19 20:57:35', 0);
INSERT INTO `aplicacion_rol` VALUES (140, 0, 0, 0, 1, 0, 49, 4, '2009-11-19 20:57:51', '2009-12-29 09:18:30', 1);
INSERT INTO `aplicacion_rol` VALUES (141, 0, 0, 0, 1, 0, 46, 4, '2009-11-19 20:57:51', '2009-12-29 09:18:30', 1);
INSERT INTO `aplicacion_rol` VALUES (142, 0, 0, 0, 1, 0, 50, 4, '2009-11-20 14:51:54', '2009-12-18 12:04:14', 0);
INSERT INTO `aplicacion_rol` VALUES (143, 0, 0, 0, 1, 1, 50, 6, '2009-11-20 14:52:10', '2009-11-20 14:52:10', 0);
INSERT INTO `aplicacion_rol` VALUES (144, 1, 1, 1, 1, 1, 51, 1, '2009-11-24 18:54:26', '2009-11-24 18:54:26', 0);
INSERT INTO `aplicacion_rol` VALUES (145, 1, 1, 1, 1, 1, 47, 2, '2009-11-24 18:54:48', '2009-12-22 10:01:03', 1);
INSERT INTO `aplicacion_rol` VALUES (146, 0, 0, 0, 0, 1, 51, 3, '2009-11-24 18:55:04', '2009-12-29 09:50:25', 1);
INSERT INTO `aplicacion_rol` VALUES (147, 0, 0, 0, 1, 0, 51, 4, '2009-11-24 18:55:20', '2009-12-29 09:18:42', 1);
INSERT INTO `aplicacion_rol` VALUES (148, 0, 0, 0, 0, 1, 51, 5, '2009-11-24 18:55:34', '2009-12-29 09:20:32', 1);
INSERT INTO `aplicacion_rol` VALUES (149, 0, 0, 0, 0, 1, 51, 6, '2009-11-24 18:55:49', '2009-11-24 18:55:49', 0);
INSERT INTO `aplicacion_rol` VALUES (150, 0, 0, 0, 0, 1, 51, 7, '2009-11-24 18:56:04', '2009-11-24 18:56:04', 0);
INSERT INTO `aplicacion_rol` VALUES (151, 0, 0, 0, 0, 1, 51, 8, '2009-11-24 18:56:19', '2009-11-24 18:56:19', 0);
INSERT INTO `aplicacion_rol` VALUES (152, 1, 1, 1, 1, 1, 51, 2, '2009-11-30 21:26:17', '2009-12-22 10:00:05', 1);
INSERT INTO `aplicacion_rol` VALUES (153, 0, 0, 0, 1, 0, 21, 4, '2009-12-02 21:01:32', '2009-12-02 21:01:32', 0);
INSERT INTO `aplicacion_rol` VALUES (154, 0, 0, 0, 1, 0, 54, 4, '2009-12-03 18:31:54', '2009-12-29 09:25:26', 1);
INSERT INTO `aplicacion_rol` VALUES (155, 0, 0, 0, 1, 0, 1, 4, '2009-12-18 12:07:42', '2009-12-18 12:07:49', 0);
INSERT INTO `aplicacion_rol` VALUES (156, 1, 1, 1, 1, 1, 50, 2, '2009-12-21 16:38:21', '2009-12-22 09:59:42', 1);
INSERT INTO `aplicacion_rol` VALUES (157, 0, 0, 0, 1, 0, 1, 9, '2009-12-21 19:09:07', '2009-12-21 19:09:07', 0);
INSERT INTO `aplicacion_rol` VALUES (158, 0, 0, 0, 1, 0, 7, 9, '2009-12-21 19:09:31', '2009-12-21 19:09:31', 0);
INSERT INTO `aplicacion_rol` VALUES (159, 1, 1, 1, 1, 1, 12, 2, '2009-12-22 09:58:43', '2009-12-22 09:58:43', 0);
INSERT INTO `aplicacion_rol` VALUES (160, 1, 1, 1, 1, 1, 10, 2, '2009-12-22 09:58:58', '2009-12-22 09:58:58', 0);
INSERT INTO `aplicacion_rol` VALUES (161, 1, 1, 1, 1, 1, 11, 2, '2009-12-22 09:59:17', '2009-12-22 09:59:17', 0);
INSERT INTO `aplicacion_rol` VALUES (162, 0, 0, 0, 1, 0, 55, 3, '2009-12-22 14:47:28', '2009-12-29 09:50:39', 0);
INSERT INTO `aplicacion_rol` VALUES (163, 0, 0, 0, 1, 0, 44, 3, '2009-12-22 14:47:28', '2009-12-29 09:50:39', 0);
INSERT INTO `aplicacion_rol` VALUES (164, 0, 0, 0, 1, 0, 56, 3, '2009-12-22 15:19:28', '2009-12-29 09:50:53', 0);
INSERT INTO `aplicacion_rol` VALUES (165, 0, 0, 0, 1, 0, 44, 3, '2009-12-22 15:19:28', '2009-12-29 09:50:53', 0);
INSERT INTO `aplicacion_rol` VALUES (166, 0, 0, 0, 1, 0, 4, 3, '2009-12-22 15:20:30', '2009-12-29 09:51:09', 0);
INSERT INTO `aplicacion_rol` VALUES (167, 0, 0, 0, 1, 0, 44, 3, '2009-12-22 15:20:30', '2009-12-29 09:51:09', 0);
INSERT INTO `aplicacion_rol` VALUES (168, 0, 0, 0, 1, 0, 26, 4, '2009-12-29 09:19:25', '2009-12-29 09:19:25', 0);
INSERT INTO `aplicacion_rol` VALUES (169, 0, 0, 0, 1, 0, 24, 4, '2009-12-29 09:19:48', '2009-12-29 09:19:48', 0);
INSERT INTO `aplicacion_rol` VALUES (170, 0, 0, 0, 1, 0, 2, 5, '2009-12-29 09:20:13', '2009-12-29 09:20:13', 0);
INSERT INTO `aplicacion_rol` VALUES (171, 0, 0, 0, 1, 0, 3, 5, '2009-12-29 09:21:24', '2009-12-29 09:21:24', 0);
INSERT INTO `aplicacion_rol` VALUES (172, 0, 0, 0, 1, 0, 45, 5, '2009-12-29 09:21:59', '2009-12-29 09:22:54', 1);
INSERT INTO `aplicacion_rol` VALUES (173, 0, 0, 0, 1, 0, 46, 5, '2009-12-29 09:21:59', '2009-12-29 09:22:54', 1);
INSERT INTO `aplicacion_rol` VALUES (174, 0, 0, 0, 1, 0, 29, 5, '2009-12-29 09:22:16', '2009-12-29 09:22:16', 0);
INSERT INTO `aplicacion_rol` VALUES (175, 0, 0, 0, 1, 0, 28, 5, '2009-12-29 09:22:36', '2009-12-29 09:22:36', 0);
INSERT INTO `aplicacion_rol` VALUES (176, 0, 0, 0, 1, 0, 1, 5, '2009-12-29 09:23:51', '2009-12-29 09:23:51', 0);
INSERT INTO `aplicacion_rol` VALUES (177, 1, 1, 1, 1, 1, 41, 6, '2009-12-29 17:11:23', '2009-12-29 17:11:23', 0);
INSERT INTO `aplicacion_rol` VALUES (178, 1, 1, 1, 1, 1, 41, 1, '2009-12-29 19:39:38', '2009-12-29 19:39:38', 0);
INSERT INTO `aplicacion_rol` VALUES (180, 1, 1, 1, 1, 1, 13, 1, '2009-12-29 19:42:04', '2009-12-29 19:42:04', 0);
INSERT INTO `aplicacion_rol` VALUES (181, 1, 1, 1, 1, 1, 54, 1, '2009-12-29 19:43:01', '2009-12-29 19:43:01', 0);
INSERT INTO `aplicacion_rol` VALUES (182, 0, 0, 0, 1, 0, 2, 9, '2010-01-18 09:44:38', '2010-01-18 09:44:38', 0);
INSERT INTO `aplicacion_rol` VALUES (183, 1, 1, 1, 1, 1, 59, 2, '2010-01-18 18:23:49', '2010-01-18 18:23:49', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `archivo_c_t`
#

CREATE TABLE `archivo_c_t` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `fecha` date NOT NULL,
  `fecha_caducidad` date default NULL,
  `contenido` longtext,
  `archivo` varchar(255) default NULL,
  `disponibilidad` varchar(255) default NULL,
  `consejo_territorial_id` bigint(20) default NULL,
  `documentacion_consejo_id` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `consejo_territorial_id_idx` (`consejo_territorial_id`),
  KEY `documentacion_consejo_id_idx` (`documentacion_consejo_id`),
  CONSTRAINT `archivo_c_t_ibfk_1` FOREIGN KEY (`documentacion_consejo_id`) REFERENCES `documentacion_consejo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `archivo_c_t_ibfk_2` FOREIGN KEY (`consejo_territorial_id`) REFERENCES `consejo_territorial` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

#
# Volcar la base de datos para la tabla `archivo_c_t`
#

INSERT INTO `archivo_c_t` VALUES (1, 'prueba de icox ', '2009-11-19', '2009-11-19', '<p>prueba de icox para los archivods</p>', '2dc95981bce92eedcbb389025c257e388740575b.doc', 'Solo Grupo', 1, 1, '2009-11-19 16:04:38', '2010-02-01 11:42:39', 1);
INSERT INTO `archivo_c_t` VALUES (2, 'Acta n�: 1/2009', '2009-04-03', '2015-01-01', '<p>&nbsp;</p><p><span lang="ES-TRAD" style="font-family: Arial"><font size="5"><strong><o:p></o:p></strong></font></span></p><p><span lang="ES-TRAD" style="font-family: Arial"><font size="5"><strong>Hora: 11:30<o:p></o:p></strong></font></span></p><p>&nbsp;</p><p class="MsoTitle" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-family: Arial"><strong><font size="5">Lugar: Oficinas de AMAT<o:p></o:p></font></strong></span></p><p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-family: Arial"><o:p><font size="2">&nbsp;</font></o:p></span></p><p><table class="MsoNormalTable" cellspacing="0" cellpadding="0" border="1" style="border-right: medium none; border-top: medium none; margin: auto auto auto 5.4pt; border-left: medium none; border-bottom: medium none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .75pt; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt; mso-border-insideh: .75pt solid windowtext; mso-border-insidev: .75pt solid windowtext">    <tbody>        <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">            <td valign="top" width="612" colspan="2" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: windowtext 1pt solid; padding-left: 5.4pt; background: #cccccc; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 459pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; mso-border-alt: solid windowtext .75pt; mso-shading: windowtext; mso-pattern: gray-20 auto">            <p class="FormHeader2" style="margin: 4pt 0cm 3pt"><span style="font-size: 12pt; mso-ansi-language: ES; mso-bidi-font-family: Arial"><strong><font face="Arial">Asistentes:<o:p></o:p></font></strong></span></p>            </td>        </tr>        <tr style="height: 20.85pt; mso-yfti-irow: 1; page-break-inside: avoid">            <td valign="top" width="331" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 248.1pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 20.85pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt">            <p class="FormText" align="center" style="margin: 4pt 0cm; text-align: center"><span style="font-size: 12pt; font-family: Arial; mso-ansi-language: ES"><strong>Nombre<o:p></o:p></strong></span></p>            </td>            <td valign="top" width="281" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: #f0f0f0; width: 210.9pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 20.85pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .75pt">            <p class="FormText" style="margin: 4pt 0cm"><b><span style="font-size: 12pt; font-family: Arial; mso-ansi-language: ES">Mutua<o:p></o:p></span></b></p>            </td>        </tr>        <tr style="height: 13.9pt; mso-yfti-irow: 2; page-break-inside: avoid">            <td valign="bottom" width="331" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 248.1pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.9pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><st1:personname productid="ISABEL GARC?A" w:st="on"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">ISABEL GARC&Iacute;A</span></st1:personname><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"> GISMERA<o:p></o:p></span></p>            </td>            <td valign="bottom" width="281" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: #f0f0f0; width: 210.9pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.9pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .75pt">            <h2 align="left" style="margin: 0cm 0cm 0pt; text-align: left; tab-stops: 153.0pt"><span lang="ES-TRAD" style="font-weight: normal; font-size: 12pt; mso-bidi-font-family: Arial"><font face="Arial">ASEPEYO<o:p></o:p></font></span></h2>            </td>        </tr>        <tr style="height: 13.15pt; mso-yfti-irow: 3; page-break-inside: avoid">            <td valign="bottom" width="331" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 248.1pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.15pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">FRANCISCO BARROSO JADRAQUE<o:p></o:p></span></p>            </td>            <td valign="bottom" width="281" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: #f0f0f0; width: 210.9pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.15pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .75pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">FRATERNIDAD MUPRESPA<o:p></o:p></span></p>            </td>        </tr>        <tr style="height: 13.15pt; mso-yfti-irow: 4; page-break-inside: avoid">            <td valign="bottom" width="331" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 248.1pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.15pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">JUAN <st1:personname productid="MANUEL LOPEZ" w:st="on">MANUEL LOPEZ</st1:personname> MARTIN<o:p></o:p></span></p>            </td>            <td valign="bottom" width="281" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: #f0f0f0; width: 210.9pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.15pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .75pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">FREMAP<o:p></o:p></span></p>            </td>        </tr>        <tr style="height: 13.15pt; mso-yfti-irow: 5; page-break-inside: avoid">            <td valign="bottom" width="331" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 248.1pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.15pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><st1:personname productid="FERNANDO GARC?A" w:st="on"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">FERNANDO GARC&Iacute;A</span></st1:personname><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"> ASENJO<o:p></o:p></span></p>            </td>            <td valign="bottom" width="281" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: #f0f0f0; width: 210.9pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.15pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .75pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">INTERCOMARCAL<o:p></o:p></span></p>            </td>        </tr>        <tr style="height: 13.6pt; mso-yfti-irow: 6; page-break-inside: avoid">            <td valign="bottom" width="331" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 248.1pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.6pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span style="font-size: 12pt; font-family: Arial; mso-ansi-language: ES">ANTONIO J. CALDEIRO FERN&Aacute;NDEZ<o:p></o:p></span></p>            </td>            <td valign="bottom" width="281" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: #f0f0f0; width: 210.9pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.6pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .75pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span style="font-size: 12pt; font-family: Arial; mso-ansi-language: ES">UNI&Oacute;N DE MUTUAS<o:p></o:p></span></p>            </td>        </tr>        <tr style="height: 13.15pt; mso-yfti-irow: 7; page-break-inside: avoid">            <td valign="bottom" width="331" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 248.1pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.15pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><st1:personname productid="JOS? MAR?A" w:st="on"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">JOS&Eacute; MAR&Iacute;A</span></st1:personname><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"> ALCOCER P&Eacute;REZ-ESPA&Ntilde;A<o:p></o:p></span></p>            </td>            <td valign="bottom" width="281" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: #f0f0f0; width: 210.9pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 13.15pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .75pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">UNIVERSAL<o:p></o:p></span></p>            </td>        </tr>        <tr style="height: 14pt; mso-yfti-irow: 8; page-break-inside: avoid; mso-yfti-lastrow: yes">            <td valign="bottom" width="331" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 248.1pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 14pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><st1:personname productid="ANGEL MATEO" w:st="on"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">ANGEL MATEO</span></st1:personname><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"> ATIENZA<o:p></o:p></span></p>            </td>            <td valign="bottom" width="281" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: #f0f0f0; width: 210.9pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 14pt; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt; mso-border-right-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .75pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">AMAT <o:p></o:p></span></p>            </td>        </tr>    </tbody></table></p><p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></p><p><table class="MsoNormalTable" cellspacing="0" cellpadding="0" border="1" style="border-right: medium none; border-top: medium none; margin: auto auto auto 5.4pt; border-left: medium none; border-bottom: medium none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .75pt; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt; mso-border-insideh: .75pt solid windowtext; mso-border-insidev: .75pt solid windowtext">    <tbody>        <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">            <td valign="top" width="612" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: windowtext 1pt solid; padding-left: 5.4pt; background: #cccccc; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 459pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; mso-border-alt: solid windowtext .75pt; mso-shading: windowtext; mso-pattern: gray-20 auto">            <p class="FormHeader2" style="margin: 4pt 0cm 3pt"><span style="font-size: 12pt; mso-ansi-language: ES; mso-bidi-font-family: Arial"><strong><font face="Arial">Orden del d&iacute;a:<o:p></o:p></font></strong></span></p>            </td>        </tr>        <tr style="mso-yfti-irow: 1; mso-yfti-lastrow: yes">            <td valign="top" width="612" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 459pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt">            <p class="MsoNormal" style="margin: 0cm 0cm 0pt 18pt; text-indent: -18pt; tab-stops: list 18.0pt 71.25pt; mso-list: l1 level1 lfo1"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-fareast-font-family: Arial"><span style="mso-list: Ignore">1.<span style="font: 7pt \'Times New Roman\'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Lectura y aprobaci&oacute;n del Acta de la reuni&oacute;n anterior, celebrada el 18/7/2008.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt 18pt; text-indent: -18pt; tab-stops: list 18.0pt 71.25pt; mso-list: l1 level1 lfo1"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-fareast-font-family: Arial"><span style="mso-list: Ignore">2.<span style="font: 7pt \'Times New Roman\'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Informe del Delegado Territorial sobre gestiones realizadas.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt 18pt; text-indent: -18pt; tab-stops: list 18.0pt 71.25pt; mso-list: l1 level1 lfo1"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-fareast-font-family: Arial"><span style="mso-list: Ignore">3.<span style="font: 7pt \'Times New Roman\'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Informaci&oacute;n sobre prueba piloto del &Aacute;rea 4, Consejer&iacute;a de Sanidad de Madrid.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt 18pt; text-indent: -18pt; tab-stops: list 18.0pt 71.25pt; mso-list: l1 level1 lfo1"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-fareast-font-family: Arial"><span style="mso-list: Ignore">4.<span style="font: 7pt \'Times New Roman\'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Estado de situaci&oacute;n de la modificaci&oacute;n del Art. 128 de <st1:personname productid="la Ley General" w:st="on">la Ley General</st1:personname> de <st1:personname productid="la Seguridad Social. Control" w:st="on">la Seguridad Social. Control</st1:personname> por parte del INSS a partir de los 12 meses.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt 18pt; text-indent: -18pt; tab-stops: list 18.0pt 71.25pt; mso-list: l1 level1 lfo1"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-fareast-font-family: Arial"><span style="mso-list: Ignore">5.<span style="font: 7pt \'Times New Roman\'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Presentaci&oacute;n realizada a <st1:personname productid="la nueva Directora Regional" w:st="on">la nueva Directora Regional</st1:personname> de Salud e Higiene en el Trabajo de la actividad de prevenci&oacute;n de las Mutuas.</span></b><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt"> <br />            </span></b><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Estado de situaci&oacute;n de la modificaci&oacute;n del Art. 128 de <st1:personname productid="la Ley General" w:st="on">la Ley General</st1:personname> de <st1:personname productid="la Seguridad Social. Control" w:st="on">la Seguridad Social. Control</st1:personname> por parte del INSS a partir de los 12 meses.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt 18pt; text-indent: -18pt; tab-stops: list 18.0pt 71.25pt; mso-list: l1 level1 lfo1"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-fareast-font-family: Arial"><span style="mso-list: Ignore">6.<span style="font: 7pt \'Times New Roman\'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Presencia de nuestras Entidades en <st1:personname productid="la Unidad Docente" w:st="on">la Unidad Docente</st1:personname> de Medicina del Trabajo, Agencia La&iacute;n Entralgo.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt 18pt; text-indent: -18pt; tab-stops: list 18.0pt 71.25pt; mso-list: l1 level1 lfo1"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-fareast-font-family: Arial"><span style="mso-list: Ignore">7.<span style="font: 7pt \'Times New Roman\'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Pr&oacute;ximas gestiones a realizar.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt 18pt; text-indent: -18pt; tab-stops: list 18.0pt 71.25pt; mso-list: l1 level1 lfo1"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-fareast-font-family: Arial"><span style="mso-list: Ignore">8.<span style="font: 7pt \'Times New Roman\'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Ruegos y Preguntas.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></p>            </td>        </tr>    </tbody></table></p><p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></p><p><table class="MsoNormalTable" cellspacing="0" cellpadding="0" border="1" style="border-right: medium none; border-top: medium none; margin: auto auto auto 5.4pt; border-left: medium none; border-bottom: medium none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .75pt; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt; mso-border-insideh: .75pt solid windowtext; mso-border-insidev: .75pt solid windowtext">    <tbody>        <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">            <td valign="top" width="612" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: windowtext 1pt solid; padding-left: 5.4pt; background: #cccccc; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 459pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; mso-border-alt: solid windowtext .75pt; mso-shading: windowtext; mso-pattern: gray-20 auto">            <p class="FormHeader2" style="margin: 4pt 0cm 3pt; text-align: justify"><span style="font-size: 12pt; mso-ansi-language: ES; mso-bidi-font-family: Arial"><strong><font face="Arial">Desarrollo:<o:p></o:p></font></strong></span></p>            </td>        </tr>        <tr style="mso-yfti-irow: 1; mso-yfti-lastrow: yes">            <td valign="top" width="612" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 459pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-top-alt: solid windowtext .75pt">            <ol type="1" style="margin-top: 0cm">                <li class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 36.0pt 71.25pt; mso-list: l0 level1 lfo2"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><strong>Lectura y aprobaci&oacute;n del Acta de la reuni&oacute;n anterior, celebrada el 18/7/2008.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></strong></span></li>            </ol>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se procede a la lectura del acta de la reuni&oacute;n celebrada el 18 de julio de 2008, que es aprobada por los asistentes.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></b></p>            <ol type="1" start="2" style="margin-top: 0cm">                <li class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 36.0pt 71.25pt; mso-list: l0 level1 lfo2"><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Informe del Delegado Territorial sobre gestiones realizadas.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></li>            </ol>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Comienza su informe dando cuenta de las diversas reuniones mantenidas con distintos Organismos y personalidades, cumpliendo los acuerdos adoptados en la anterior reuni&oacute;n del Consejo:<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Con D. Manuel Molina Mu&ntilde;oz, Director General de Ordenaci&oacute;n e Inspecci&oacute;n, en la que se present&oacute; un BORRADOR DE ACUERDO DE COOPERACI&Oacute;N Y COORDINACI&Oacute;N PARA <st1:personname productid="LA MEJORA EN LA" w:st="on">LA MEJORA EN LA</st1:personname> GESTI&Oacute;N DE <st1:personname productid="LA INCAPACIDAD TEMPORAL ENTRE" w:st="on">LA INCAPACIDAD TEMPORAL ENTRE</st1:personname> EL SERVICIO P&Uacute;BLICO DE SALUD DE <st1:personname productid="LA COMUNIDAD DE MADRID" w:st="on">LA COMUNIDAD DE MADRID</st1:personname> Y <st1:personname productid="LA ASOCIACI?N DE MUTUAS" w:st="on">LA ASOCIACI&Oacute;N DE MUTUAS</st1:personname> DE ACCIDENTES DE TRABAJO Y ENFERMEDADES PROFESIONALES DE <st1:personname productid="LA SEGURIDAD SOCIAL" w:st="on">LA SEGURIDAD SOCIAL</st1:personname>, comentando ampliamente su contenido explicando las causas y motivos que hacen necesaria la firma de este acuerdo, <o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se informa que el Acuerdo fue aceptado por <st1:personname productid="la Direcci?n General" w:st="on">la Direcci&oacute;n General</st1:personname>, con algunos matices y se present&oacute; a <st1:personname productid="la Direcci?n General" w:st="on">la Direcci&oacute;n General</st1:personname> de Ordenaci&oacute;n, estando en estos momentos a la espera de su Visto Bueno para proceder a la firma.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">En esta reuni&oacute;n, el Director General inform&oacute; sobre el Convenio Piloto que se firmar&iacute;a pr&oacute;ximamente con el INSS y coment&oacute; la pr&oacute;xima celebraci&oacute;n de una Jornada de presentaci&oacute;n, en el mes de noviembre, en la que se explicar&iacute;a a los Gerentes de las &Aacute;reas de Atenci&oacute;n Primaria de Madrid, su contenido, y en la que podr&iacute;an participar, adem&aacute;s del INSS y los Gerentes de Atenci&oacute;n Primaria, las Mutuas, incluso desarrollando una Ponencia.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Esta jornada se celebr&oacute; el d&iacute;a 18 de noviembre &uacute;ltimo, en el Hospital Cl&iacute;nico Universitario San Carlos de Madrid, participando en sesi&oacute;n conjunta la Consejer&iacute;a de Sanidad, el INSS y las Mutuas, en la que intervino como Ponente en representaci&oacute;n de las Mutuas el doctor D. Fernando Mena. <b style="mso-bidi-font-weight: normal"><o:p></o:p></b></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></b></p>            <ol type="1" start="3" style="margin-top: 0cm">                <li class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 36.0pt 71.25pt; mso-list: l0 level1 lfo2"><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Informaci&oacute;n sobre prueba piloto del &Aacute;rea 4, Consejer&iacute;a de Sanidad de Madrid.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></li>            </ol>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se comentan los excelentes resultados obtenidos en la prueba piloto, realizada en el AREA 4 de Madrid , en la que se actuaron sobre 11 patolog&iacute;as, sobre la que se entrega a los asistentes al Consejo informaci&oacute;n sobre los resultados, que han sido valorados muy positivamente por todas las organizaciones participantes, ya que se ha alcanzado un importante nivel de colaboraci&oacute;n entre los profesionales sanitarios, y se ha logrado una espectacular reducci&oacute;n tanto en n&uacute;mero de d&iacute;as de baja como en duraciones medias de los procesos, por lo que se considera que deber&iacute;a ampliarse esta experiencia a toda la Comunidad de Madrid.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se comenta que no solo se lograron mejoras en el control de las patolog&iacute;as analizadas sino en otras, debido al efecto de comunicaci&oacute;n de los controles efectuados.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify"><st1:personname productid="ISABEL GARC?A" w:st="on"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Isabel Garc&iacute;a</span></st1:personname><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"> Gismera, representante de Asepeyo y que participo, como M&eacute;dico, de manera importante en esta experiencia, informa que ya se ten&iacute;a prevista en <st1:personname productid="la Inspecci?n Sanitaria" w:st="on">la Inspecci&oacute;n Sanitaria</st1:personname> de Madrid, ampliar esta experiencia a otras </span><span lang="ES-TRAD" style="font-size: 12pt; font-family: \'Arial (W1)\'; mso-bidi-font-family: Arial">&Aacute;reas Sanitarias y localidades de la Comunidad de Madrid</span><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">, comentando que en principio estaban previstas las de Torrej&oacute;n, Alcorc&oacute;n, Fuenlabrada y el &Aacute;rea 1. Comenta igualmente que desde esta Inspecci&oacute;n Sanitaria se mantuvieron contactos con algunas Mutuas para poner en marcha esta iniciativa pero de momento no se han concretado.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se acuerda solicitar entrevista con D. Manuel Molina Mu&ntilde;oz, para comentarle este tema y ver su opini&oacute;n sobre la ampliaci&oacute;n de esta experiencia bien a las &Aacute;reas comentadas o a toda la Comunidad de Madrid, as&iacute; como a m&aacute;s patolog&iacute;as.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Por parte del Delegado Territorial se comenta que ser&iacute;a interesante mantener reuniones con CEIM, para informarles de esta iniciativa para solicitar su apoyo. Por parte del Consejo se acuerda delegar en D. <st1:personname productid="JOS? MAR?A" w:st="on">Jos&eacute; Mar&iacute;a</st1:personname> Alcocer para esta gesti&oacute;n.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-bidi-font-weight: bold">Finalmente, en este punto, se comenta que por el Servicio P&uacute;blico se est&aacute; pensando en hacer un &Aacute;rea </span><span lang="ES-TRAD" style="font-size: 12pt; font-family: \'Arial (W1)\'; mso-bidi-font-family: Arial; mso-bidi-font-weight: bold">o servicio espec&iacute;fico </span><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-bidi-font-weight: bold">para enfermedades profesionales as&iacute; como que se est&aacute; dando un curso &ldquo;on line&rdquo; sobre enfermedad profesional a m&eacute;dicos de atenci&oacute;n primaria</span><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">. <o:p></o:p></span></b></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></b></p>            <ol type="1" start="4" style="margin-top: 0cm">                <li class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 36.0pt 71.25pt; mso-list: l0 level1 lfo2"><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Estado de situaci&oacute;n de la modificaci&oacute;n del Art. 128 de <st1:personname productid="la Ley General" w:st="on">la Ley General</st1:personname> de <st1:personname productid="la Seguridad Social. Control" w:st="on">la Seguridad Social. Control</st1:personname> por parte del INSS a partir de los 12 meses.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></li>            </ol>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Una vez transcurrido mas de un<span style="mso-spacerun: yes">&nbsp; </span>a&ntilde;o desde la modificaci&oacute;n del Art&iacute;culo 128 de la L.G.S.S., se comenta la situaci&oacute;n en que se encuentra la resoluci&oacute;n de los procesos, comunicados al INSS, que han alcanzado los 12 meses de duraci&oacute;n.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se entrega a los Asistentes informaci&oacute;n sobre los dato, de enero a septiembre de 2008, que son los &uacute;ltimos recopilados, en los que se ve que la demora media en la resoluci&oacute;n de procesos por el INSS es de 66,38 d&iacute;as, si bien en dos datos de octubre de 2008, se observa una disminuci&oacute;n hasta 58,62 d&iacute;as.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Por los asistentes se encuentran estas cifras muy elevadas y se comenta que hace tiempo que no se re&uacute;ne la Comisi&oacute;n con <st1:personname productid="la Direcci?n Provincial" w:st="on">la Direcci&oacute;n Provincial</st1:personname> del INSS de Madrid, en la que se comentaban y resolv&iacute;an muchos de los temas que surg&iacute;an.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se acuerda que desde AMAT se inste a <st1:personname productid="la Direcci?n Provincial" w:st="on">la Direcci&oacute;n Provincial</st1:personname> del INSS de Madrid para mantener una reuni&oacute;n, a ser posible en el mes de mayo pr&oacute;ximo, y tratar de mantener peri&oacute;dicamente las reuniones que se ven&iacute;an manteniendo.<b style="mso-bidi-font-weight: normal"><o:p></o:p></b></span></p>            <p class="MsoBodyText" style="margin: 0cm 0cm 0pt; vertical-align: baseline; tab-stops: list 71.25pt; mso-layout-grid-align: none; punctuation-wrap: simple"><span lang="ES-TRAD" style="mso-ansi-language: ES-TRAD"><font face="Arial">Por parte del representante de Fraternidad se comenta la iniciativa de montar una operativa para comunicar al INSS telem&aacute;ticamente las iniciativas de alta. Por todos los reunidos se considera muy interesante la iniciativa y se estar&aacute; a la expectativa de su desarrollo. <o:p></o:p></font></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-bidi-font-weight: bold"><o:p>&nbsp;</o:p></span></p>            <ol type="1" start="5" style="margin-top: 0cm">                <li class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 36.0pt 71.25pt; mso-list: l0 level1 lfo2"><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Presentaci&oacute;n realizada a <st1:personname productid="la nueva Directora Regional" w:st="on">la nueva Directora Regional</st1:personname> de Salud e Higiene en el Trabajo de la actividad de prevenci&oacute;n de las Mutuas.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></li>            </ol>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se informa sobre las reuniones mantenidas con el Viceconsejero de Empleo y Mujer, D. Jos&eacute; <st1:personname productid="Ignacio Fern?ndez" w:st="on">Ignacio Fern&aacute;ndez</st1:personname> Rubio, el pasado d&iacute;a 23 de enero, en la que se le comentaron las actividades preventivas de las Mutuas, as&iacute; como las varias mantenidas con el Director General de Trabajo de Madrid, D. Javier Vallejo, con objeto de tratar sobre las actividades de las Mutuas en cuanto su inclusi&oacute;n dentro del III Plan Director de Prevenci&oacute;n de Riesgos Laborales de la Comunidad de Madrid.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se informa igualmente de la reuni&oacute;n mantenida, el pasado d&iacute;a 31 de marzo, con la Gerente del Instituto Regional de Seguridad y Salud en el Trabajo de Madrid, D&ordf;. M&ordf;. del Mar Alarc&oacute;n Castellanos, a la que asisti&oacute; el Director General de Trabajo y en la que se comentaron las actividades preventivas de las Mutuas con cargo a cuotas, y en la que se puso de manifiesto la dificultad que pod&iacute;amos encontrar en firmar un acuerdo por AMAT sobre la realizaci&oacute;n de determinadas actividades preventivas de las Mutuas, ya que, cada Mutua programa y realiza estas actividades independientemente </span><span lang="ES-TRAD" style="font-size: 12pt; font-family: \'Arial (W1)\'; mso-bidi-font-family: Arial">y con un presupuesto concreto para cada una de ellas y de dif&iacute;cil traslaci&oacute;n a actividades conjuntas.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Por parte de la Gerente del IRSST, se comenta que ser&iacute;a importante tener informaci&oacute;n de las actividades de las Mutuas, ya que de este modo podr&iacute;an coordinar sus actividades de forma m&aacute;s operativa.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Comento igualmente que est&aacute;n haciendo ya estad&iacute;sticas propias sobre siniestralidad, de las que nos enviar&aacute; informaci&oacute;n.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: \'Arial (W1)\'; mso-bidi-font-family: Arial">Nos enviar&aacute;n alg&uacute;n documento propuesta para trabajar y comunicarnos por ambas partes las actividades programadas y realizadas, para conocimiento mutuo y para se&ntilde;alar objetivos nuevos en la acci&oacute;n de cada Mutua.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></p>            <ol type="1" start="6" style="margin-top: 0cm">                <li class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 36.0pt 71.25pt; mso-list: l0 level1 lfo2"><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Presencia de nuestras Entidades en <st1:personname productid="la Unidad Docente" w:st="on">la Unidad Docente</st1:personname> de Medicina del Trabajo, Agencia La&iacute;n Entralgo.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></li>            </ol>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se comentan las reuniones mantenidas por las Comisiones de Seguimiento de <st1:personname productid="la Unidad Docente" w:st="on">la Unidad Docente</st1:personname> de Medicina del Trabajo de <st1:personname productid="la Agencia La?n Entralgo" w:st="on">la Agencia La&iacute;n Entralgo</st1:personname>, tanto de <st1:personname productid="la Universidad Complutense" w:st="on">la Universidad Complutense</st1:personname> de Madrid, celebrada el d&iacute;a 5 de marzo, a la que asistio en representaci&oacute;n de AMAT, D. <st1:personname productid="Francisco Miranda" w:st="on">Francisco Miranda</st1:personname>, como de <st1:personname productid="la del Instituto" w:st="on">la del Instituto</st1:personname> de Salud Carlos III, celebrada el 10 de marzo, y a la que asisti&oacute; <st1:personname productid="JOS? MAR?A" w:st="on">Jos&eacute; Mar&iacute;a</st1:personname> Alcocer.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Informa <st1:personname productid="JOS? MAR?A" w:st="on">Jos&eacute; Mar&iacute;a</st1:personname> Alcocer que en la reuni&oacute;n pusieron de manifiesto una disminuci&oacute;n en el n&uacute;mero de plazas ofrecidas por las Mutuas </span><span lang="ES-TRAD" style="font-size: 12pt; font-family: \'Arial (W1)\'; mso-bidi-font-family: Arial">y algunos problemas concretos con alguna Entidad que est&aacute;n resolviendo directamente</span><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">. Igualmente le comentaron la necesidad de personal que pudiera desarrollar trabajos administrativos, y le solicitaron que desde AMAT se facilitase este personal, a lo que se contest&oacute; que no era posible, dada la limitaci&oacute;n que se tiene.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se comenta la modificaci&oacute;n del Convenio de colaboraci&oacute;n y se acord&oacute; enviarlo a las Mutuas participantes.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Finalmente comenta que se manifiesto la necesidad de que se iniciase el expediente de acreditaci&oacute;n de AMAT, por la desaparici&oacute;n de Formutua. Por el Gerente Territorial se informa que ya se han comunicado formalmente estos extremos a <st1:personname productid="la Agencia La?n Entralgo." w:st="on">la Agencia La&iacute;n Entralgo.</st1:personname><o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial; mso-bidi-font-weight: bold"><o:p>&nbsp;</o:p></span></p>            <ol type="1" start="7" style="margin-top: 0cm">                <li class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 36.0pt 71.25pt; mso-list: l0 level1 lfo2"><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Pr&oacute;ximas gestiones a realizar.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></li>            </ol>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se repasan los temas que se han<span style="mso-spacerun: yes">&nbsp; </span>comentado en esta reuni&oacute;n y las acciones que deber&aacute;n ser desarrolladas pr&oacute;ximamente, tanto con el INSS como con el Director General de Ordenaci&oacute;n e Inspecci&oacute;n de Madrid.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Se continuar&aacute; con la consecuci&oacute;n del Acuerdo de Mejora de la Gesti&oacute;n en materia de IT, as&iacute; como los contactos con <st1:personname productid="la Direcci?n General" w:st="on">la Direcci&oacute;n General</st1:personname> de Trabajo.<b style="mso-bidi-font-weight: normal"><o:p></o:p></b></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><b><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></b></p>            <ol type="1" start="8" style="margin-top: 0cm">                <li class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 36.0pt 71.25pt; mso-list: l0 level1 lfo2"><b style="mso-bidi-font-weight: normal"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">Ruegos y Preguntas.<span style="mso-bidi-font-weight: bold"><o:p></o:p></span></span></b></li>            </ol>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">No se formula ninguna y se comenta la actitud de <st1:personname productid="la Tesorer?a General" w:st="on">la Tesorer&iacute;a General</st1:personname> de <st1:personname productid="LA SEGURIDAD SOCIAL" w:st="on">la Seguridad Social</st1:personname>, as&iacute; como de sus direcciones Provinciales, sobre el Oficio de <st1:personname productid="la Direcci?n General" w:st="on">la Direcci&oacute;n General</st1:personname> de Ordenaci&oacute;n de 22 de diciembre de 2008, sobre cambio de clave de Mutua en el Fichero General de Afiliaci&oacute;n.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">En este sentido se informa de la reuni&oacute;n mantenida por la Comisi&oacute;n de Recursos-Tesorer&iacute;as, de AMAT, sobre este tema, de cuyo contenido se envi&oacute; Circular informativa a las Mutuas sobre la forma de proceder para cumplir las instrucciones contenidas en el mencionado oficio, con la que se acompa&ntilde;aba informe que sobre el mismo dirigi&oacute; <st1:personname productid="la Tesorer?a General" w:st="on">la Tesorer&iacute;a General</st1:personname> a sus Direcciones Provinciales.<o:p></o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></p>            <p class="MsoNormal" style="margin: 0cm 0cm 0pt; text-align: justify; tab-stops: list 71.25pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial">No habiendo mas temas que tratar termina la reuni&oacute;n a las 14: 20 minutos.</span><span lang="ES-TRAD" style="font-size: 12pt"><o:p></o:p></span></p>            </td>        </tr>    </tbody></table></p><p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></p><p><table class="MsoNormalTable" cellspacing="0" cellpadding="0" border="1" style="border-right: medium none; border-top: medium none; margin: auto auto auto 5.4pt; border-left: medium none; border-bottom: medium none; border-collapse: collapse; mso-table-layout-alt: fixed; mso-border-alt: solid windowtext .75pt; mso-padding-alt: 0cm 5.4pt 0cm 5.4pt; mso-border-insideh: .75pt solid windowtext; mso-border-insidev: .75pt solid windowtext">    <tbody>        <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">            <td valign="top" width="331" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: windowtext 1pt solid; padding-left: 5.4pt; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 248.1pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; background-color: transparent; mso-border-alt: solid windowtext .75pt">            <p class="FormText" style="margin: 4pt 0cm"><span style="font-size: 12pt; font-family: Arial; mso-ansi-language: ES"><o:p>&nbsp;</o:p></span></p>            <p class="FormText" style="margin: 4pt 0cm"><span style="font-size: 12pt; font-family: Arial; mso-ansi-language: ES"><o:p>&nbsp;</o:p></span></p>            <p class="FormText" style="margin: 4pt 0cm"><span style="font-size: 12pt; font-family: Arial; mso-ansi-language: ES"><o:p>&nbsp;</o:p></span></p>            </td>            <td valign="top" width="274" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: windowtext 1pt solid; padding-left: 5.4pt; padding-bottom: 0cm; border-left: #f0f0f0; width: 205.5pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; background-color: transparent; mso-border-alt: solid windowtext .75pt; mso-border-left-alt: solid windowtext .75pt">            <p class="FormText" style="margin: 4pt 0cm"><span style="font-size: 12pt; font-family: Arial; mso-ansi-language: ES"><o:p>&nbsp;</o:p></span></p>            </td>        </tr>        <tr style="height: 33.1pt; mso-yfti-irow: 1; mso-yfti-lastrow: yes">            <td valign="top" width="331" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; background: #cccccc; padding-bottom: 0cm; border-left: windowtext 1pt solid; width: 248.1pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 33.1pt; mso-border-alt: solid windowtext .75pt; mso-shading: windowtext; mso-pattern: gray-20 auto; mso-border-top-alt: solid windowtext .75pt">            <p class="FormHeader2" align="center" style="margin: 4pt 0cm 3pt; text-align: center"><strong><font face="Arial"><st1:personname productid="JOS? MAR?A" w:st="on"><span style="font-size: 12pt; mso-ansi-language: ES; mso-bidi-font-family: Arial">Jos&eacute; Mar&iacute;a</span></st1:personname><span style="font-size: 12pt; mso-ansi-language: ES; mso-bidi-font-family: Arial"> Alcocer P&eacute;rez Espa&ntilde;a<o:p></o:p></span></font></strong></p>            <p class="FormHeader2" align="center" style="margin: 4pt 0cm 3pt; text-align: center"><span style="font-size: 12pt; mso-ansi-language: ES; mso-bidi-font-family: Arial"><strong><font face="Arial">Delegado Territorial<o:p></o:p></font></strong></span></p>            <p class="FormHeader2" align="center" style="margin: 0cm 0cm 0pt; text-align: center"><span style="font-size: 12pt; mso-ansi-language: ES; mso-bidi-font-family: Arial"><strong><font face="Arial">AMAT &ndash; Madrid<o:p></o:p></font></strong></span></p>            </td>            <td valign="top" width="274" style="border-right: windowtext 1pt solid; padding-right: 5.4pt; border-top: #f0f0f0; padding-left: 5.4pt; background: #cccccc; padding-bottom: 0cm; border-left: #f0f0f0; width: 205.5pt; padding-top: 0cm; border-bottom: windowtext 1pt solid; height: 33.1pt; mso-border-alt: solid windowtext .75pt; mso-shading: windowtext; mso-pattern: gray-20 auto; mso-border-top-alt: solid windowtext .75pt; mso-border-left-alt: solid windowtext .75pt">            <p class="FormHeader2" align="center" style="margin: 4pt 0cm 3pt; text-align: center"><span style="font-size: 12pt; mso-ansi-language: ES; mso-bidi-font-family: Arial"><strong><font face="Arial">&Aacute;ngel Mateo Atienza<o:p></o:p></font></strong></span></p>            <p class="FormHeader2" align="center" style="margin: 0cm 0cm 0pt; text-align: center"><span style="font-size: 12pt; mso-ansi-language: ES; mso-bidi-font-family: Arial"><strong><font face="Arial">Gerente Territorial<o:p></o:p></font></strong></span></p>            <p class="FormHeader2" align="center" style="margin: 0cm 0cm 0pt; text-align: center"><span style="font-size: 12pt; mso-ansi-language: ES; mso-bidi-font-family: Arial"><strong><font face="Arial">AMAT<o:p></o:p></font></strong></span></p>            </td>        </tr>    </tbody></table></p><p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="ES-TRAD" style="font-size: 12pt; font-family: Arial"><o:p>&nbsp;</o:p></span></p><p class="MsoNormal" style="margin: 0cm 0cm 0pt">&nbsp;</p><p class="MsoNormal" style="margin: 0cm 0cm 0pt">&nbsp;</p><p>Escarza</p>', '731e050058cba99bc3580abe971f3498dc3f6194.doc', 'Solo Grupo', 14, 2, '2010-01-12 11:06:59', '2010-01-18 09:39:19', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `archivo_d_g`
#

CREATE TABLE `archivo_d_g` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `fecha` date NOT NULL,
  `fecha_caducidad` date default NULL,
  `contenido` longtext,
  `archivo` varchar(255) default NULL,
  `disponibilidad` varchar(255) default NULL,
  `grupo_trabajo_id` bigint(20) default NULL,
  `documentacion_grupo_id` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `grupo_trabajo_id_idx` (`grupo_trabajo_id`),
  KEY `documentacion_grupo_id_idx` (`documentacion_grupo_id`),
  CONSTRAINT `archivo_d_g_ibfk_1` FOREIGN KEY (`grupo_trabajo_id`) REFERENCES `grupo_trabajo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `archivo_d_g_ibfk_2` FOREIGN KEY (`documentacion_grupo_id`) REFERENCES `documentacion_grupo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

#
# Volcar la base de datos para la tabla `archivo_d_g`
#

INSERT INTO `archivo_d_g` VALUES (2, 'test', '2010-01-04', '2010-01-04', '<p>descripcion test</p>', 'c274573a9e210ba88b2b57e0ffff4d5c26e0f894.zip', 'Solo Grupo', 2, NULL, '2010-01-22 11:30:20', '2010-01-22 15:10:03', 1);
INSERT INTO `archivo_d_g` VALUES (3, 'test1', '2010-01-04', NULL, '<p>adasdasd</p>', '94def5fb46f64920c2866609fe1d2c6c2d1d78eb.zip', 'Solo Grupo', 11, NULL, '2010-01-22 15:11:48', '2010-01-22 15:11:48', 0);
INSERT INTO `archivo_d_g` VALUES (4, 'test2', '2010-01-11', NULL, '<p>asdasdas</p>', '536f349603cc284f31cc53c86c93c0e299320259.zip', 'Solo Grupo', 7, 7, '2010-01-22 15:13:26', '2010-01-22 15:14:52', 0);
INSERT INTO `archivo_d_g` VALUES (5, 'test3', '2010-01-23', NULL, '<p>test3</p>', 'b0a1edf8ba9157d796630fd625138e73f8faf2a2.zip', 'Solo Grupo', 3, NULL, '2010-01-22 15:16:10', '2010-01-22 15:19:18', 0);
INSERT INTO `archivo_d_g` VALUES (6, 'test4', '2010-01-14', NULL, '<p>asdsad</p>', 'c2aa80bc384ceaffc45ee0b0f0c65deb1fa0fb17.zip', 'Todos', NULL, NULL, '2010-01-22 15:21:16', '2010-01-22 15:21:16', 0);
INSERT INTO `archivo_d_g` VALUES (7, 'test5', '2010-01-23', NULL, '<p>adads</p>', '7838acc7b9f35b489bc493d100fb0fda661fbddc.zip', 'Todos', NULL, NULL, '2010-01-22 15:22:10', '2010-01-22 15:22:10', 0);
INSERT INTO `archivo_d_g` VALUES (8, 'test6', '2010-01-23', NULL, '', '40c390dae5de4c3d961718dab54e2b0291657a47.zip', 'Todos', NULL, NULL, '2010-01-22 15:34:35', '2010-01-22 15:34:35', 0);
INSERT INTO `archivo_d_g` VALUES (9, 'test7', '2010-01-23', NULL, '<p>asd</p>', '5e0d852256b3e41052615bf6180a0a89f8f60682.zip', 'Solo Grupo', 9, 5, '2010-01-22 15:35:31', '2010-01-22 15:35:31', 0);
INSERT INTO `archivo_d_g` VALUES (10, 'test8', '2010-01-23', '2010-01-23', '<p>asd</p>', '2bc71a1811e57fb173d5089bcebb4060d57d2d27.zip', 'Todos', NULL, NULL, '2010-01-22 15:36:43', '2010-01-22 15:36:43', 0);
INSERT INTO `archivo_d_g` VALUES (11, 'test9', '2010-01-23', NULL, '<p>asdasd</p>', '9d577e9b07040b895a53c1816b463dd583b39806.zip', 'Todos', NULL, NULL, '2010-01-22 15:37:50', '2010-01-22 15:37:50', 0);
INSERT INTO `archivo_d_g` VALUES (12, 'test10', '2010-02-02', '2010-02-06', '<p>asd</p>', '7a4fef5d4741ba03ae5d660c683f4444919f069f.zip', 'Todos', NULL, NULL, '2010-01-22 15:38:48', '2010-01-22 15:38:48', 0);
INSERT INTO `archivo_d_g` VALUES (13, 'test11', '2010-02-22', '2010-03-18', '<p>asdasd</p>', '4a6041b50e7747f592ad1d7c4671ef8b6e9b5a7d.zip', 'Todos', NULL, NULL, '2010-01-22 15:39:50', '2010-01-22 15:39:50', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `archivo_d_o`
#

CREATE TABLE `archivo_d_o` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `fecha` date NOT NULL,
  `fecha_caducidad` date default NULL,
  `contenido` longtext,
  `archivo` varchar(255) default NULL,
  `disponibilidad` varchar(255) default NULL,
  `categoria_organismo_id` bigint(20) default NULL,
  `subcategoria_organismo_id` bigint(20) default NULL,
  `organismo_id` bigint(20) default NULL,
  `documentacion_organismo_id` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `categoria_organismo_id_idx` (`categoria_organismo_id`),
  KEY `subcategoria_organismo_id_idx` (`subcategoria_organismo_id`),
  KEY `organismo_id_idx` (`organismo_id`),
  KEY `documentacion_organismo_id_idx` (`documentacion_organismo_id`),
  CONSTRAINT `archivo_d_o_ibfk_1` FOREIGN KEY (`subcategoria_organismo_id`) REFERENCES `sub_categoria_organismo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `archivo_d_o_ibfk_2` FOREIGN KEY (`organismo_id`) REFERENCES `organismo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `archivo_d_o_ibfk_3` FOREIGN KEY (`documentacion_organismo_id`) REFERENCES `documentacion_organismo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `archivo_d_o_ibfk_4` FOREIGN KEY (`categoria_organismo_id`) REFERENCES `categoria_organismo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

#
# Volcar la base de datos para la tabla `archivo_d_o`
#


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `asamblea`
#

CREATE TABLE `asamblea` (
  `id` bigint(20) NOT NULL auto_increment,
  `titulo` varchar(255) default NULL,
  `direccion` varchar(255) default NULL,
  `fecha` date default NULL,
  `fecha_caducidad` date default NULL,
  `horario` varchar(255) default NULL,
  `contenido` longtext,
  `estado` varchar(255) default NULL,
  `entidad` varchar(128) default NULL,
  `owner_id` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `owner_id_idx` (`owner_id`),
  CONSTRAINT `asamblea_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

#
# Volcar la base de datos para la tabla `asamblea`
#

INSERT INTO `asamblea` VALUES (7, 'tertertertertt', 'terterterterte', '2009-11-12', '2009-11-13', '18:00:00', '<p>erterterterterterterterert</p>', 'anulada', 'GrupoTrabajo_1', 3, '2009-11-12 19:15:21', '2009-11-12 20:12:05', 1);
INSERT INTO `asamblea` VALUES (8, 'prueba de icox para actas', 'icox ', '2009-11-13', '2009-11-14', '14:06:00', '<p>prueba de icox para las actas</p>', 'pendiente', 'GrupoTrabajo_1', 3, '2009-11-13 14:18:08', '2009-11-13 14:18:08', 0);
INSERT INTO `asamblea` VALUES (9, 'Una', 'Una', '2009-11-25', '2009-12-23', '01:30:00', '<p>&nbsp;aaa</p>', 'activa', 'GrupoTrabajo_2', 7, '2009-11-21 11:12:11', '2009-11-21 11:12:34', 0);
INSERT INTO `asamblea` VALUES (10, 'aaa', 'aaa', '2010-01-10', '2010-01-10', '03:26:00', '<p>aaa</p>', 'activa', 'DirectoresGerentes_0', 7, '2009-12-29 10:10:38', '2009-12-29 10:10:38', 0);
INSERT INTO `asamblea` VALUES (11, 'Asamblea 1', 'Matey', '2009-12-10', '2009-12-10', '11:07:00', '<p>Es una prueba.</p><p>&nbsp;</p><p>Ya no se como solicitar audiencia para un caf&eacute;,...</p>', 'activa', 'DirectoresGerentes_0', 7, '2009-12-29 10:11:36', '2009-12-29 10:13:02', 0);
INSERT INTO `asamblea` VALUES (12, 'Prueba 3 - J-Dir', 'AMAT', '2010-01-10', '2010-01-10', '06:26:00', '<p>&nbsp;</p><p>Prueba 3 del 29 de Diciembre - 2009</p>', 'activa', 'Junta_directiva_5', 7, '2009-12-29 10:36:06', '2009-12-29 10:36:39', 0);
INSERT INTO `asamblea` VALUES (13, 'Prueba 4', 'Amat', '2010-01-12', '2010-01-12', '11:26:00', '<p>&nbsp;</p><p>Prueba 4</p>', 'activa', 'DirectoresGerentes_0', 7, '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `asamblea` VALUES (14, 'prueba de icox', 'icox', '2009-12-29', '2009-12-29', '11:30:00', '', 'activa', 'DirectoresGerentes_0', 7, '2009-12-29 17:31:01', '2009-12-29 18:11:12', 0);
INSERT INTO `asamblea` VALUES (15, 'Prueba Enero', 'una', '2010-02-01', '2010-02-14', 'Por la tarde', '<p>aaa</p>', 'activa', 'DirectoresGerentes_0', 7, '2010-01-12 09:06:03', '2010-01-12 09:06:59', 0);
INSERT INTO `asamblea` VALUES (16, 'Mikel Prueba', 'Oficinas AMAT', '2010-01-27', '2015-05-28', '10 de la Ma�ana a 3 de la tarde', '<p>Convocator&iacute;a</p>', 'activa', 'GrupoTrabajo_7', 7, '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `asamblea` VALUES (17, 'prueba de icox ', '', '2010-01-18', '2010-01-18', '12:30', '<p>prueba de icox &nbsp;</p>', 'activa', 'DirectoresGerentes_0', 7, '2010-01-18 16:22:27', '2010-01-18 16:27:52', 0);
INSERT INTO `asamblea` VALUES (18, 'zxcvzxcvz', 'cvzcvz', '2010-02-03', '2010-02-03', 'zxcvzcvz', '<p>adfasdfafd</p>', 'pendiente', NULL, 1, '2010-02-02 15:50:20', '2010-02-02 15:50:20', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `categoria_asunto`
#

CREATE TABLE `categoria_asunto` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(100) default NULL,
  `email_1` varchar(255) default NULL,
  `activo_1` bigint(20) default NULL,
  `email_2` varchar(225) default NULL,
  `activo_2` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

#
# Volcar la base de datos para la tabla `categoria_asunto`
#

INSERT INTO `categoria_asunto` VALUES (1, 'A�adir un nuevo enlace ', 'felix.munoz@amat.es', NULL, NULL, NULL, '2009-10-20 17:49:37', '2009-12-18 11:33:33', 1);
INSERT INTO `categoria_asunto` VALUES (2, 'Comentarios', 'felix.munoz@amat.es', 1, '', NULL, '2009-10-20 17:49:37', '2009-12-29 09:03:08', 0);
INSERT INTO `categoria_asunto` VALUES (3, 'Mensajes', 'felix.munoz@amat.es', 1, '', NULL, '2009-10-20 17:49:37', '2009-12-22 19:05:34', 0);
INSERT INTO `categoria_asunto` VALUES (4, 'Documentos nuevos', NULL, NULL, NULL, NULL, '2009-10-20 17:49:37', '2009-12-18 11:33:58', 1);
INSERT INTO `categoria_asunto` VALUES (5, 'Error en alg�n enlace', NULL, NULL, NULL, NULL, '2009-10-20 17:49:37', '2009-12-18 11:35:02', 1);
INSERT INTO `categoria_asunto` VALUES (6, 'Problemas de calidad', NULL, NULL, NULL, NULL, '2009-10-20 17:49:37', '2009-12-18 11:34:07', 1);
INSERT INTO `categoria_asunto` VALUES (7, 'Problemas de presentaci�n', NULL, NULL, NULL, NULL, '2009-10-20 17:49:37', '2009-12-18 11:34:10', 1);
INSERT INTO `categoria_asunto` VALUES (8, 'Otros temas', 'felix.munoz@amat.es', 1, '', NULL, '2009-10-20 17:49:37', '2009-12-22 19:05:49', 0);
INSERT INTO `categoria_asunto` VALUES (9, 'Incidencias', 'mikel.escarza@amat.es', 1, 'mescarza@terra.es', NULL, '2009-12-18 11:34:49', '2009-12-28 09:43:05', 0);
INSERT INTO `categoria_asunto` VALUES (10, 'aa', 'aa@a.es', NULL, NULL, NULL, '2009-12-18 11:41:18', '2009-12-18 11:41:23', 1);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `categoria_c_t`
#

CREATE TABLE `categoria_c_t` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

#
# Volcar la base de datos para la tabla `categoria_c_t`
#

INSERT INTO `categoria_c_t` VALUES (1, 'Documentaci�n General', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `categoria_c_t` VALUES (2, 'Acuerdos Territoriales', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `categoria_c_t` VALUES (3, 'Convenios de IT', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `categoria_c_t` VALUES (4, 'Informe Reuni�n Comisi�n Central IT', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `categoria_c_t` VALUES (5, 'Informe Reuni�n Subcomisi�n Provincial IT', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `categoria_c_t` VALUES (6, 'Otros', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `categoria_c_t` VALUES (7, 'Actas (sin convocatoria)', '2010-01-12 10:50:58', '2010-01-12 10:50:58', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `categoria_d_g`
#

CREATE TABLE `categoria_d_g` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

#
# Volcar la base de datos para la tabla `categoria_d_g`
#

INSERT INTO `categoria_d_g` VALUES (10, 'Documentaci�n General', NULL, NULL, 0);
INSERT INTO `categoria_d_g` VALUES (11, 'test2', NULL, '2010-01-25 11:09:17', 1);
INSERT INTO `categoria_d_g` VALUES (12, 'test2', '2010-01-25 11:06:46', '2010-01-25 11:06:58', 1);
INSERT INTO `categoria_d_g` VALUES (13, 'test', '2010-01-26 10:58:54', '2010-01-26 11:00:45', 1);
INSERT INTO `categoria_d_g` VALUES (14, 'test2', NULL, NULL, 0);
INSERT INTO `categoria_d_g` VALUES (15, 'test', '2010-01-26 11:00:26', '2010-01-26 11:00:26', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `categoria_organismo`
#

CREATE TABLE `categoria_organismo` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

#
# Volcar la base de datos para la tabla `categoria_organismo`
#

INSERT INTO `categoria_organismo` VALUES (1, 'prueba de icox', '2009-11-19 16:24:17', '2009-11-19 16:24:17', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `cifra_dato`
#

CREATE TABLE `cifra_dato` (
  `id` bigint(20) NOT NULL auto_increment,
  `titulo` varchar(100) NOT NULL,
  `autor` varchar(100) NOT NULL,
  `contenido` longtext,
  `imagen` varchar(255) default NULL,
  `documento` varchar(255) default NULL,
  `link` varchar(255) default NULL,
  `fecha` date NOT NULL,
  `fecha_publicacion` date NOT NULL,
  `ambito` varchar(255) default NULL,
  `estado` varchar(255) default NULL,
  `destacada` tinyint(1) default NULL,
  `mutua_id` bigint(20) default NULL,
  `owner_id` bigint(20) default NULL,
  `seccion_id` bigint(20) default NULL,
  `user_id_creador` bigint(20) default NULL,
  `user_id_modificado` bigint(20) default NULL,
  `user_id_publicado` bigint(20) default NULL,
  `fecha_publicado` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `mutua_id_idx` (`mutua_id`),
  KEY `owner_id_idx` (`owner_id`),
  KEY `seccion_id_idx` (`seccion_id`),
  CONSTRAINT `cifra_dato_ibfk_1` FOREIGN KEY (`seccion_id`) REFERENCES `cifra_dato_seccion` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cifra_dato_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cifra_dato_ibfk_3` FOREIGN KEY (`mutua_id`) REFERENCES `mutua` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

#
# Volcar la base de datos para la tabla `cifra_dato`
#

INSERT INTO `cifra_dato` VALUES (5, 'Estudio de Prestaciones por Riesgos en el Embarazo edici�n', 'AMAT', '<p>Este informe comprende la evoluci&oacute;n de esta prestaci&oacute;n del a&ntilde;o 2001 a diciembre de 2008 y una simulaci&oacute;n de costes con base en 2009.Este informe se ha realizado analizando las siguientes variables: &bull; N&uacute;mero de expedientes de Riesgo durante el Embarazo generados en el periodo de estudio. &bull; Coste agregado de la Prestaci&oacute;n de Riesgo durante el Embarazo y Riesgo en la Lactancia por Provincia.&bull; N&uacute;mero de mujeres por intervalo de edades considerando las que se encontraban en alta laboral en el R&eacute;gimen General, R&eacute;gimen del Carb&oacute;n y R&eacute;gimen Especial de Trabajadores Aut&oacute;nomos a 31 de Diciembre del cada a&ntilde;o. El intervalo de edad entre 25 y 49 a&ntilde;os se estim&oacute; a partir de la serie de 24 a 54 a&ntilde;os ajustada al porcentaje de mujeres activas entre 25 y 49 a&ntilde;os, de la Encuesta de Poblaci&oacute;n Activa para el &uacute;ltimo trimestre de cada a&ntilde;o en cuesti&oacute;n.&bull; Tasa de Fecundidad, global y por intervalo de edad. Se refiere al n&uacute;mero de nacimientos por mil mujeres en edad f&eacute;rtil (de 16 a 49 a&ntilde;os de edad) seg&uacute;n el INE.A partir del an&aacute;lisis de las variables anteriores se estiman los siguientes datos:&bull; Estimaci&oacute;n del Total de mujeres en edad f&eacute;rtil en alta en la Seguridad Social para los Reg&iacute;menes especificados, a 31 de diciembre de cada ejercicio en el periodo de estudio.&bull; Estimaci&oacute;n del N&uacute;mero de mujeres ocupadas embarazadas por cada periodo. Obtenido en funci&oacute;n del total anual de mujeres ocupadas y la tasa global de fecundidad. En esta estimaci&oacute;n se ha supuesto uniforme la fecundidad de las mujeres trabajadoras.&bull; Tasa de Incremento en el n&uacute;mero de expedientes de la Prestaci&oacute;n de Riesgo durante el Embarazo.&bull; Porcentaje de expedientes de Riesgo durante el Embarazo con respecto a las mujeres embarazadas en el periodo.Las Mutuas de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social, a partir del 24 de Marzo de 2007, incorporaron en sus prestaciones los Riesgos durante el Embarazo y, hasta el 31 de diciembre de 2007, cubrieron 14.946 casos con un coste de 58.243.942 euros.En 2008, las MATEPSS atendieron 37.254 casos, con un coste de la Prestaci&oacute;n econ&oacute;mica de 167.802.193 euros.</p>', '4aba29c80e058.jpg', '4aba29c820920.pdf', '', '2009-03-13', '2009-12-18', 'web', 'publicado', 0, 1, 1, 3, 1, 7, 1, '2009-03-13 00:00:00', '2009-03-17 09:16:27', '2009-12-18 11:46:55', 0);
INSERT INTO `cifra_dato` VALUES (6, 'Incapacidad Temporal por Edici�n Contingencias Comunes, estudio 2009', 'AMAT', '', '4af160510864f.jpg', '4af15fc14f2a4.pdf', '', '2009-04-20', '2009-12-18', 'web', 'publicado', 0, 1, 1, 5, 1, 7, 1, NULL, '2009-04-20 09:37:45', '2009-12-18 11:54:03', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `cifra_dato_seccion`
#

CREATE TABLE `cifra_dato_seccion` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(100) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

#
# Volcar la base de datos para la tabla `cifra_dato_seccion`
#

INSERT INTO `cifra_dato_seccion` VALUES (1, 'AFILIACION', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `cifra_dato_seccion` VALUES (2, 'ACCIDENTES DE TRABAJO', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `cifra_dato_seccion` VALUES (3, 'EMBARAZO Y LACTANCIA', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `cifra_dato_seccion` VALUES (4, 'ENFERMEDADES PROFESIONALES', '2009-11-20 20:44:02', '2009-11-20 20:44:02', 0);
INSERT INTO `cifra_dato_seccion` VALUES (5, 'ENFERMEDAD COMUN', '2009-11-20 20:44:02', '2009-11-20 20:44:02', 0);
INSERT INTO `cifra_dato_seccion` VALUES (6, 'APORTACION DE LAS MUTUAS ', '2009-11-20 20:44:02', '2009-11-20 20:44:02', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `circular`
#

CREATE TABLE `circular` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` longtext,
  `contenido` longtext,
  `fecha` date NOT NULL,
  `fecha_caducidad` date default NULL,
  `numero` varchar(100) default NULL,
  `documento` varchar(255) default NULL,
  `circular_sub_tema_id` bigint(20) default NULL,
  `subcategoria_organismo_id` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `circular_sub_tema_id_idx` (`circular_sub_tema_id`),
  KEY `subcategoria_organismo_id_idx` (`subcategoria_organismo_id`),
  CONSTRAINT `circular_ibfk_1` FOREIGN KEY (`subcategoria_organismo_id`) REFERENCES `sub_categoria_organismo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `circular_ibfk_2` FOREIGN KEY (`circular_sub_tema_id`) REFERENCES `circular_sub_tema` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=873 DEFAULT CHARSET=latin1 AUTO_INCREMENT=873 ;

#
# Volcar la base de datos para la tabla `circular`
#

INSERT INTO `circular` VALUES (386, 'Novedades del texto publicado en el BOE de la Orden por la que se regula la contraprestaci�n a satisfacer por las Mutuas de Accidentes de Trabajo por los servicios de administraci�n complementaria de la directa respecto del Borrador de esa norma.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_01.08.pdf">circular</a></p>', '2008-01-02', '0000-00-00', '01', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (387, 'Documento titulado "La Empresa y la Responsabilidad Social".', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_02.08.pdf">circular</a></p>', '2008-01-03', NULL, '02', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:56:34', 0);
INSERT INTO `circular` VALUES (388, 'Instrucciones del Instituto Nacional de la Seguridad Social en relaci�n a la aplicaci�n de las nuevas competencias recogidas en el art�culo 128 de la Ley General de Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_03.08.pdf">circular</a></p>', '2008-01-08', '0000-00-00', '03', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (389, 'Modificaci�n de los l�mites de los distintos tipos de contratos a efectos de la contrataci�n administrativa a partir del 1 de enero de 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_04.08.pdf">circular</a></p>', '2008-01-09', '0000-00-00', '04', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (390, 'Propuesta de Directiva del Parlamento Europeo y del Consejo enmendando la Directiva 2004/40/EC.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_05.08.pdf">circular</a></p>', '2008-01-10', '0000-00-00', '05', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (391, 'Proyecto de Orden por la que se desarrolla la disposici�n adicional duod�cima de la Ley 29/2006, de 26 de julio, de garant�as y uso racional de los medicamentos y productos sanitarios.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_06.08.pdf">circular</a></p>', '2008-01-10', '0000-00-00', '06', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (392, 'Recomendaciones del Comit� Cient�fico para los L�mites de Exposici�n Ocupacional de la Comisi�n Europea para las sustancias Hidruro de litio y Cloruro Metileno.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_07.08.pdf">circular</a></p>', '2008-01-10', '0000-00-00', '07', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (393, 'Gu�a sobre buenas pr�cticas para prevenir o minimizar los riesgos del amianto en el trabajo: para el Empresario, los Trabajadores y el Inspector de Trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_08.08.pdf">circular</a></p>', '2008-01-11', '0000-00-00', '08', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (394, 'Suscripci�n del Convenio Marco de Cooperaci�n para la emisi�n de informes y pr�ctica de pruebas m�dicas.', '<p><a href="/uploads/file/Circulares/2008/enero/circular_09.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/enero/circular_09.08.3.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/enero/circular_09.08.2.doc">Enlace con documentaci&oacute;n adjunta (Archivo DOC)</a></p>\r\n<p>&nbsp;</p>', '2008-01-14', NULL, '09', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 14:05:03', 0);
INSERT INTO `circular` VALUES (395, 'Anexos a las Instrucciones del Instituto Nacional de la Seguridad Social en relaci�n a la aplicaci�n de las nuevas competencias recogidas en el art�culo 128 de la Ley General de Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_10.08.pdf">circular</a></p>', '2008-01-14', '0000-00-00', '10', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (396, 'Errata en la Nueva Tarifa de tipos de cotizaci�n por AT y EP.', '<p><a href="/uploads/file/Circulares/2008/enero/circular_11.08.pdf">circular</a></p>', '2008-01-14', NULL, '11', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 14:01:43', 0);
INSERT INTO `circular` VALUES (397, 'Publicaci�n en el BOE de la Resoluci�n de la Secretaria de Estado de la Seguridad Social sobre la aplicaci�n del art�culo 128 de la Ley General de Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_12.08.pdf">circular</a></p>', '2008-01-17', '0000-00-00', '12', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (398, 'Aspectos m�s novedosos para las Mutuas del nuevo Reglamento de desarrollo de la Ley Org�nica de Protecci�n de Datos de Car�cter //Personal. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_13.08.pdf">circular</a></p>', '2008-01-21', '0000-00-00', '13', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (399, 'Convenio Colectivo 2004-2007.- Aplicaci�n de la cl�usula de revisi�n salarial.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_14.08.pdf">circular</a></p>', '2008-01-21', '0000-00-00', '14', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (400, 'Contraste Externo de la Cualificaci�n Profesional ?Montaje de Protecciones Colectivas en Construcci�n? del Cat�logo Nacional de Cualificaciones Profesionales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_15.08.pdf">circular</a></p>', '2008-01-24', '0000-00-00', '15', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (401, 'Anexos a las Instrucciones del Instituto Nacional de la Seguridad Social en relaci�n a la aplicaci�n de las nuevas competencias recogidas en el art�culo 128 de la Ley General de Seguridad Social. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_16.08.pdf">circular</a></p>', '2008-01-28', '0000-00-00', '16', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (402, 'Gu�a para el seguimiento y control de la actividad sanitaria de los servicios de prevenci�n. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_17.08.pdf">circular</a></p>', '2008-01-30', '0000-00-00', '17', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (403, 'Incidencia en el proceso de traspasos de cobros en la recaudaci�n de octubre 2007.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/enero/circular_18.08.pdf">circular</a></p>', '2008-01-31', '0000-00-00', '18', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (404, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes (Enero-Diciembre de 2007).', '<p><a href="/uploads/file/Circulares/2008/enero/circular_19.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/enero/circular_19.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2008-01-31', NULL, '19', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 14:08:21', 0);
INSERT INTO `circular` VALUES (405, 'Aspectos de inter�s para las Mutuas en relaci�n con el desarrollo de la Ley del Estatuto del Trabajo Aut�nomo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/febrero/circular_20.08.pdf">circular</a></p>', '2008-02-06', '0000-00-00', '20', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (406, 'Consideraciones de la Agencia Espa�ola de Protecci�n de Datos en relaci�n con las Mutuas de Accidentes de Trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/febrero/circular_21.08.pdf">circular</a></p>', '2008-02-06', '0000-00-00', '21', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (407, 'Subsanaci�n total de la incidencia surgida en el proceso de recaudaci�n abril 2007, en importes de cobros y compensaciones a Mutuas, por IT de contingencias comunes.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/febrero/circular_22.08.pdf">circular</a></p>', '2008-02-08', '0000-00-00', '22', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (408, 'Gu�a T�cnica para la evaluaci�n y prevenci�n de los riegos relacionados con las atm�sferas explosivas en los lugares de trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/febrero/circular_23.08.pdf">circular</a></p>', '2008-02-13', '0000-00-00', '23', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (409, 'Aspectos de inter�s de la Jornada "Mutuas de Accidentes de Trabajo y Seguridad Social: puntos cr�ticos".', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/febrero/circular_24.08.pdf">circular</a></p>', '2008-02-13', NULL, '24', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 14:09:50', 0);
INSERT INTO `circular` VALUES (410, 'Nueva versi�n del protocolo de comunicaci�n de procesos de incapacidad temporal que van a cumplir doce meses desde las Mutuas al INSS. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/febrero/circular_25.08.pdf">circular</a></p>', '2008-02-15', '0000-00-00', '25', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (411, 'Anteproyecto de Decreto de habilitaci�n de los t�cnicos de prevenci�n de riesgos laborales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/febrero/circular_26.08.pdf">circular</a></p>', '2008-02-15', '0000-00-00', '26', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (412, 'Pago de Cuotas correspondientes al Presupuesto Ordinario de Gastos de AMAT para el Ejercicio 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/febrero/circular_27.08.pdf">circular</a></p>', '2008-02-15', '0000-00-00', '27', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (413, 'Propuesta de Sistema Bonus/Malus para la reducci�n de la siniestralidad laboral.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/febrero/circular_28.08.pdf">circular</a></p>', '2008-02-25', '0000-00-00', '28', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (414, 'Evoluci�n de la Recaudaci�n y Deducciones por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Diciembre de 2007).', '<p><a href="/uploads/file/Circulares/2008/febrero/circular_29.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/febrero/circular_29.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2008-02-29', NULL, '29', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 14:11:39', 0);
INSERT INTO `circular` VALUES (415, 'Avance Estad�stico de Accidentes de Trabajo. (Enero-Diciembre de 2007).', '<p><a href="/uploads/file/Circulares/2008/febrero/circular_30.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/febrero/circular_30.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2008-02-29', NULL, '30', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 14:12:40', 0);
INSERT INTO `circular` VALUES (416, 'Negociaci�n Colectiva 2008. Nota Informativa n� 1.- Constituci�n de la Comisi�n Negociadora.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_31.08.pdf">circular</a></p>', '2008-03-03', '0000-00-00', '31', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (417, 'Borrador Gu�a T�cnica de Se�alizaci�n de Seguridad y Salud en el Trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_32.08.pdf">circular</a></p>', '2008-03-06', '0000-00-00', '32', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (418, 'Fusi�n de Rediss-Matt, Mupa y Fimac.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_33.08.pdf">circular</a></p>', '2008-03-06', '0000-00-00', '33', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (419, 'Procedimiento para el registro de contratos concertados por los trabajadores aut�nomos dependientes.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_34.08.pdf">circular</a></p>', '2008-03-06', '0000-00-00', '34', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (420, 'Respuesta de Businesseurope a la ?Segunda fase de consulta de los Interlocutores Sociales Europeos sobre la protecci�n de la salud de los trabajadores europeos ante infecciones sangu�neas por pinchazo de agujas?.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_35.08.pdf">circular</a></p>', '2008-03-12', '0000-00-00', '35', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (421, 'Nuevo dise�o de formato del registro de afiliaci�n con motivo de la identificaci�n de los Trabajadores Aut�nomos Dependientes.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_36.08.pdf">circular</a></p>', '2008-03-17', '0000-00-00', '36', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (422, 'Negociaci�n Colectiva 2008. Nota Informativa n� 2.- Presentaci�n de Plataformas para la negociaci�n.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_37.08.pdf">circular</a></p>', '2008-03-17', '0000-00-00', '37', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (423, 'Informe sobre la prestaci�n de Riesgo Durante el Embarazo y Riesgo en la Lactancia.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_38.08.pdf">circular</a></p>', '2008-03-19', '0000-00-00', '38', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (424, 'Fecha de inicio del nuevo formato del registro de afiliaci�n con motivo de la identificaci�n de los Trabajadores Aut�nomos Dependientes (TRADE).', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_39.08.pdf">circular</a></p>', '2008-03-25', '0000-00-00', '39', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (425, 'Negociaci�n Colectiva 2008. Nota Informativa n� 3.- Presentaci�n de planteamiento empresarial.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_40.08.pdf">circular</a></p>', '2008-03-27', '0000-00-00', '40', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (426, 'Proyecto de Real Decreto por el que, en desarrollo de las Leyes 18/2007, de 4 de julio, por la que se procede a la integraci�n de los trabajadores por cuenta propia del R�gimen Especial Agrario de la Seguridad Social en el R�gimen Especial de la Seguridad Social de los trabajadores por Cuenta Propia o Aut�nomos, y 20/2007, de 11 de julio, del Estatuto del trabajador aut�nomo, se modifican los Reglamentos Generales sobre inscripci�n de empresas y afiliaci�n, altas, bajas y variaciones de otros derechos de la Seguridad Social; de recaudaci�n de la Seguridad Social y sobre colaboraci�n de las Mutuas de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/marzo/circular_41.08.pdf">circular</a></p>', '2008-03-31', '0000-00-00', '41', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (427, 'Proyecto de Decreto por el que se establecen los requisitos y las condiciones sanitarias de los servicios de farmacia y dep�sitos de medicamentos en los centros de cirug�a ambulatoria, Mutuas de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social y centros de interrupci�n voluntaria del embarazo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/abril/circular_42.08.pdf">circular</a></p>', '2008-04-03', '0000-00-00', '42', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (428, 'Proyecto de Resoluci�n de la Secretar�a de Estado de la Seguridad Social, por la que se determinan las actividades preventivas a realizar por las mutuas de accidentes de trabajo durante el a�o 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/abril/circular_43.08.pdf">circular</a></p>', '2008-04-11', '0000-00-00', '43', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (429, 'Modificaci�n del Dise�o de registro del Fichero de Datos TC2.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/abril/circular_44.08.pdf">circular</a></p>', '2008-04-11', '0000-00-00', '44', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (430, 'Modificaci�n del Protocolo de intercambio del proceso de recaudaci�n entre la Tesorer�a General de la Seguridad Social y las Mutuas de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/abril/circular_45.08.pdf">circular</a></p>', '2008-04-22', '0000-00-00', '45', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (431, 'Resumen del Memorandum de la CEAT presentado ante la Comisi�n de Expertos constituida en el Ministerio de Trabajo sobre la posible prestaci�n por cese de actividad para los trabajadores aut�nomos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/abril/circular_46.08.pdf">circular</a></p>', '2008-04-23', '0000-00-00', '46', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (432, 'Modificaci�n de valores del R�gimen de Asistencia Sanitaria del Fichero General de Afiliaci�n.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/abril/circular_47.08.pdf">circular</a></p>', '2008-04-30', '0000-00-00', '47', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (433, 'Comunicaci�n al Instituto Nacional de la Seguridad Social de los procesos de incapacidad temporal que van a cumplir doce meses.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_48.08.pdf">circular</a></p>', '2008-05-05', NULL, '48', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 17:42:54', 0);
INSERT INTO `circular` VALUES (434, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes del periodo Enero-Marzo de 2008.', '<p><a href="/uploads/file/Circulares/2008/mayo/circular_49.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/mayo/circular_49.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2008-05-07', NULL, '49', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 14:31:48', 0);
INSERT INTO `circular` VALUES (435, 'Temas tratados en la reuni�n mantenida por AMAT con la Subdirecci�n General de Inscripci�n Afiliaci�n y Recaudaci�n de la Tesorer�a General de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_50.08.pdf">circular</a></p>', '2008-05-08', '0000-00-00', '50', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (436, 'Primer Borrador de la Estrategia Iberoamericana de Seguridad y Salud en el Trabajo y su Plan de Acci�n y Seguimiento.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_51.08.pdf">circular</a></p>', '2008-05-09', '0000-00-00', '51', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (437, 'Negociaci�n Colectiva 2008. Nota Informativa n� 4.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_52.08.pdf">circular</a></p>', '2008-05-12', '0000-00-00', '52', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (438, 'Solicitud de datos de trabajadores aut�nomos, distribuidos por provincias, adheridos a esa Mutua a 31 de marzo de 2008.', '<p><a href="/uploads/file/Circulares/2008/mayo/circular_53.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/mayo/circular_53.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2008-05-12', NULL, '53', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 16:13:08', 0);
INSERT INTO `circular` VALUES (439, 'Nueva versi�n del protocolo de comunicaci�n al Instituto Nacional de la Seguridad Social de los procesos de incapacidad temporal que van a cumplir doce meses.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_54.08.pdf">circular</a></p>', '2008-05-12', '0000-00-00', '54', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (440, 'Proyecto de Orden Ministerial por la que se dictan las normas para la elaboraci�n de los Presupuestos de la Seguridad Social para el ejercicio 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_55.08.pdf">circular</a></p>', '2008-05-13', '0000-00-00', '55', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (441, 'Incidencia en el proceso de recaudaci�n (TC1), correspondiente a febrero de 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_56.08.pdf">circular</a></p>', '2008-05-20', '0000-00-00', '56', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (442, 'Normas UNE: UNE-CEN/TR 15172-1 IN, UNE-EN ISO 12127-2, UNE- ISO 2631-1, UNE-EN 1486, UNE-CEN/TR 15350 IN.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_57.08.pdf">circular</a></p>', '2008-05-20', '0000-00-00', '57', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (443, 'Nueva estructura del segmento AUT del Fichero de Datos TC2.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_58.08.pdf">circular</a></p>', '2008-05-21', '0000-00-00', '58', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (444, 'Proyecto de Resoluci�n de la Secretar�a de Estado de la S.S. por la que se dictan instrucciones complementarias para la elaboraci�n del Anteproyecto de Presupuesto para el ejercicio 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_59.08.pdf">circular</a></p>', '2008-05-21', '0000-00-00', '59', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (445, 'Nuevo borrador de modelo est�ndar de las Normas de funcionamiento de los fondos de pensiones de empleo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/mayo/circular_60.08.pdf">circular</a></p>', '2008-05-27', '0000-00-00', '60', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (446, 'Avance Estad�stico de Accidentes de Trabajo y Enfermedades Profesionales. (Enero a Marzo de 2008).', '<p><a href="/uploads/file/Circulares/2008/junio/circular_61.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/junio/circular_61.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2008-06-02', NULL, '61', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 16:22:10', 0);
INSERT INTO `circular` VALUES (447, 'Desarrollo reglamentario de la Ley 40/2007, de 4 de diciembre, de medidas en materia de Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/junio/circular_62.08.pdf">circular</a></p>', '2008-06-04', '0000-00-00', '62', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (448, 'Negociaci�n Colectiva 2008. Nota Informativa n� 5.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/junio/circular_63.08.pdf">circular</a></p>', '2008-06-12', '0000-00-00', '63', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (449, 'Proyecto Real Decreto Estatuto de Trabajo Aut�nomo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/junio/circular_65.08.pdf">circular</a></p>', '2008-06-16', '0000-00-00', '65', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (450, 'Evoluci�n de la Recaudaci�n y Deducciones por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Marzo de 2008).', '<p><a href="/uploads/file/Circulares/2008/junio/circular_66.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/junio/circular_66.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2008-06-20', NULL, '66', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 16:28:24', 0);
INSERT INTO `circular` VALUES (451, 'Modificaci�n del literal del concepto ?Cotizaci�n Adicional? en el fichero de recaudaci�n.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/junio/circular_67.08.pdf">circular</a></p>', '2008-06-24', '0000-00-00', '67', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (452, 'Ingreso 80% del Exceso de Excedentes por Contingencias Profesionales y del Exceso de Excedentes derivado de la gesti�n de la prestaci�n econ�mica de ITCC.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/junio/circular_68.08.pdf">circular</a></p>', '2008-06-24', '0000-00-00', '68', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (453, 'Informaci�n sobre la Repetici�n del fichero de datos TC-2 correspondiente a la recaudaci�n de marzo de 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/junio/circular_69.08.pdf">circular</a></p>', '2008-06-27', '0000-00-00', '69', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (454, 'Ingreso del 80% del Exceso de Excedentes derivado de la gesti�n de las Contingencias Profesionales. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_70.08.pdf">circular</a></p>', '2008-07-02', '0000-00-00', '70', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (455, 'Observaciones de CEOE y CEPYME al Proyecto de Real Decreto por el que se desarrolla el Estatuto del Trabajador Aut�nomo en materia de contrato del trabajador aut�nomo econ�micamente dependiente y su registro y se crea el registro estatal de asociaciones profesionales de trabajadores aut�nomos. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_71.08.pdf">circular</a></p>', '2008-07-10', '0000-00-00', '71', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (456, 'Proyecto de "Resoluci�n de la Direcci�n General de Ordenaci�n de la Seguridad Social, por la que se establecen criterios de actuaci�n a seguir por las Entidades Gestoras y Mutuas de Accidentes de Trabajo y Enfermedades Profesionales con respecto al control m�dico de los trabajadores en situaci�n de incapacidad temporal por contingencias comunes".', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_72.08.pdf">circular</a></p>', '2008-07-15', NULL, '72', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 16:30:57', 0);
INSERT INTO `circular` VALUES (457, 'L�mites de exposici�n profesional para agentes qu�micos en Espa�a 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_73.08.pdf">circular</a></p>', '2008-07-21', '0000-00-00', '73', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (458, 'Desarrollo reglamentario de las prestaciones de riesgo durante el embarazo y durante la lactancia natural.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_74.08.pdf">circular</a></p>', '2008-07-23', '0000-00-00', '74', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (459, 'Cobertura de IT en RETA.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_75.08.pdf">circular</a></p>', '2008-07-23', '0000-00-00', '75', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (460, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes (Enero-Junio de 2008).', '<p><a href="/uploads/file/Circulares/2008/julio/circular_76.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/julio/circular_76.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a><span style="text-decoration: underline;"><br />\r\n</span></p>', '2008-07-24', NULL, '76', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 16:54:02', 0);
INSERT INTO `circular` VALUES (461, 'Borrador de la VI Encuesta de Condiciones de Trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_77.08.pdf">circular</a></p>', '2008-07-29', '0000-00-00', '77', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (462, 'Entrada en funcionamiento del protocolo de comunicaci�n al Instituto Nacional de la Seguridad Social de los procesos de incapacidad temporal que van a cumplir doce meses.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_78.08.pdf">circular</a></p>', '2008-07-30', '0000-00-00', '78', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (463, 'Criterio de la Direcci�n General de la Inspecci�n de Trabajo sobre los denominados "descansos preventivos".', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_79.08.pdf">circular</a></p>', '2008-07-30', NULL, '79', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 16:58:57', 0);
INSERT INTO `circular` VALUES (464, 'Negociaci�n Colectiva 2008. Nota Informativa n� 6.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_80.08.pdf">circular</a></p>', '2008-07-30', '0000-00-00', '80', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (465, '"Informe presentado por AMAT a la Secretar�a de Estado de la Seguridad Social, en relaci�n con el proyecto de Resoluci�n por la que se establecen criterios de actuaci�n a seguir por las Entidades Gestoras y Mutuas de Accidentes de Trabajo y Enfermedades Profesionales con respecto al control m�dico de los trabajadores en situaci�n de incapacidad temporal por contingencias comunes".', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_81.08.pdf">circular</a></p>', '2008-07-30', NULL, '81', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 16:58:29', 0);
INSERT INTO `circular` VALUES (466, 'Declaraci�n para el impulso de la Econom�a, el Empleo, la Competitividad y el Progreso Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_82.08.pdf">circular</a></p>', '2008-07-30', '0000-00-00', '82', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (467, 'Evoluci�n de la prestaci�n de Riesgo durante el Embarazo y Riesgo en la Lactancia (Enero-Junio de 2008).', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/julio/circular_83.08.pdf">circular</a></p>', '2008-07-31', '0000-00-00', '83', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (468, 'Herramienta de Coordinaci�n de Actividades Empresariales en PRL promovida por CEOE.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/septiembre/circular_84.08.pdf">circular</a></p>', '2008-09-11', '0000-00-00', '84', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (469, 'Revisi�n de la Clasificaci�n Nacional de Ocupaciones.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/septiembre/circular_85.08.pdf">circular</a></p>', '2008-09-12', '0000-00-00', '85', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (470, 'Borrador de Proyecto de Real Decreto de desarrollo parcial de la Ley de Contratos del Sector P�blico. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/septiembre/circular_86.08.pdf">circular</a></p>', '2008-09-15', '0000-00-00', '86', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (471, 'Proyecto de Real Decreto por el que se desarrolla el Estatuto del Trabajador Aut�nomo en materia de contrato del trabajador aut�nomo econ�micamente dependiente y su registro y se crea el Registro Estatal de asociaciones profesionales de trabajadores aut�nomos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/septiembre/circular_87.08.pdf">circular</a></p>', '2008-09-16', NULL, '87', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:02:11', 0);
INSERT INTO `circular` VALUES (472, 'Decreto 93/2008, de la Consejer�a de Salud y Consumo de la Comunidad Aut�noma de Islas Baleares, de 5 de septiembre, por el que se establecen los requisitos y las condiciones sanitarias de los servicios de farmacia y dep�sitos de medicamentos en los centros de cirug�a ambulatoria, Mutuas de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social y centros de interrupci�n voluntaria del embarazo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/septiembre/circular_88.08.pdf">circular</a></p>', '2008-09-18', '0000-00-00', '88', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (473, 'Nueva versi�n del protocolo de comunicaci�n al Instituto Nacional de la Seguridad Social de los procesos de incapacidad temporal que van a cumplir doce meses.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/septiembre/circular_89.08.pdf">circular</a></p>', '2008-09-22', '0000-00-00', '89', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (474, 'Oficio de Tesorer�a General de la Seguridad Social a sus Direcciones Provinciales sobre el Real Decreto 1382/2008, de 1 de agosto , por el que, en desarrollo de la Ley 18/2007, de 4 de julio, por la que se procede a la integraci�n de los trabajadores por cuenta propia del R�gimen Especial Agrario de la Seguridad Social en el R�gimen Especial de la Seguridad Social de los Trabajadores por Cuenta Propia o Aut�nomos, y la Ley 20/2007, de 11 de julio, del Estatuto del trabajo aut�nomo, se modifican diversos reglamentos generales en el �mbito de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/septiembre/circular_90.08.pdf">circular</a></p>', '2008-09-22', '0000-00-00', '90', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (475, 'Gu�a no vinculante sobre buenas pr�cticas para la aplicaci�n de la Directiva 2001/45/CE (trabajo en altura).', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/septiembre/circular_91.08.pdf">circular</a></p>', '2008-09-24', '0000-00-00', '91', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (476, 'Evoluci�n de la Recaudaci�n y Deducciones por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Junio de 2008).', '<p><a href="/uploads/file/Circulares/2008/septiembre/circular_92.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/septiembre/circular_92.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a><span style="text-decoration: underline;"><br />\r\n</span></p>', '2008-09-24', NULL, '92', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:04:43', 0);
INSERT INTO `circular` VALUES (477, 'Nuevo Convenio Colectivo Sectorial para los a�os 2008-2011.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_93.08.pdf">circular</a></p>', '2008-10-01', '0000-00-00', '93', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (478, 'Informaci�n a la Tesorer�a General de la cuant�a de las percepciones mediante Pago Directo de los trabajadores en el r�gimen 0721 incluidos en el SETA.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_94.08.pdf">circular</a></p>', '2008-10-02', '0000-00-00', '94', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (479, 'Observatorio Estatal de Condiciones de Trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_95.08.pdf">circular</a></p>', '2008-10-02', '0000-00-00', '95', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (480, 'Proyecto y Memoria justificativa del Proyecto de RD sobre riesgos a vibraciones mec�nicas', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_96.08.pdf">circular</a></p>', '2008-10-02', '0000-00-00', '96', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (481, 'Proyecto de Ley de Presupuestos Generales del Estado para el a�o 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_97.08.pdf">circular</a></p>', '2008-10-02', '0000-00-00', '97', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (482, '"Desarrollo reglamentario de las prestaciones de riesgo durante el embarazo y durante la lactancia natural".', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_98.08.pdf">circular</a></p>', '2008-10-07', NULL, '98', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:07:54', 0);
INSERT INTO `circular` VALUES (483, 'Temas tratados por la Ponencia de Recursos de AMAT, en su reuni�n del 22 de septiembre de 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_99.08.pdf">circular</a></p>', '2008-10-08', '0000-00-00', '99', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (484, 'Fecha de cierre de la transacci�n ATK43.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_100.08.pdf">circular</a></p>', '2008-10-08', '0000-00-00', '100', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (485, 'Balance del Primer Plan de Acci�n y Borrador del Segundo Plan de Acci�n para el impulso y la ejecuci�n de la Estrategia Espa�ola de Seguridad y Salud en el Trabajo 2007-2012.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_101.08.pdf">circular</a></p>', '2008-10-09', '0000-00-00', '101', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (486, 'Avance Estad�stico de Accidentes de Trabajo. (Primer semestre de 2008).', '<p><a href="/uploads/file/Circulares/2008/octubre/circular_102.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/octubre/circular_102.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a><span style="text-decoration: underline;"><br />\r\n</span></p>\r\n<p>&nbsp;</p>', '2008-10-13', NULL, '102', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:10:29', 0);
INSERT INTO `circular` VALUES (487, 'Documentos de Trabajo de SCOEL (Comit� Cient�fico para los L�mites de Exposici�n Ocupacional): SUM 123-Mayo 2008, SUM 139 - Febrero 2008, SUM 142 - Febrero 2008, SUM 133 - Febrero 2008 y SUM 134 - Febrero 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_103.08.pdf">circular</a></p>', '2008-10-15', NULL, '103', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:11:23', 0);
INSERT INTO `circular` VALUES (488, 'Proyecto de Real Decreto por el que se modifica el Reglamento General sobre colaboraci�n en la gesti�n de las Mutuas de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_104.08.pdf">circular</a></p>', '2008-10-16', '0000-00-00', '104', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (489, 'Anuncio de modificaciones en fichero de afiliaci�n, y en las Transacciones ATG62 y ATK43.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_105.08.pdf">circular</a></p>', '2008-10-17', '0000-00-00', '105', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (490, 'Dise�o de registro para informar a la Tesorer�a General de la cuant�a de las percepciones mediante Pago Directo de los trabajadores en el r�gimen 0721 incluidos en el SETA.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_106.08.pdf">circular</a></p>', '2008-10-17', '0000-00-00', '106', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (491, 'Dise�o de registro y listado de autorizados para IFI-WEB en la transacci�n ATK43.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_107.08.pdf">circular</a></p>', '2008-10-23', '0000-00-00', '107', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (492, 'Cumplimentaci�n del registro para informar a la Tesorer�a General de la cuant�a de las percepciones mediante Pago Directo de los trabajadores en el r�gimen 0721 incluidos en el SETA.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_108.08.pdf">circular</a></p>', '2008-10-23', '0000-00-00', '108', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (493, 'Proyecto de Orden por la que se regulan las operaciones de cierre del ejercicio 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_109.08.pdf">circular</a></p>', '2008-10-27', '0000-00-00', '109', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (494, 'Incidencia en la recaudaci�n de julio 2008.- Asignaci�n de importes de cobros y compensaciones a Mutuas por IT de contingencias comunes.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_110.08.pdf">circular</a></p>', '2008-10-28', '0000-00-00', '110', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (495, 'Proyecto de Real Decreto sobre revalorizaci�n de las pensiones del Sistema de la Seguridad Social y de otras prestaciones sociales p�blicas para el ejercicio 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/octubre/circular_111.08.pdf">circular</a></p>', '2008-10-29', '0000-00-00', '111', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (496, 'Jornada celebrada en CEOE sobre el �Impacto de la nueva normativa de competencia sobre las Asociaciones Empresariales�.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/noviembre/circular_112.08.pdf">circular</a></p>', '2008-11-10', NULL, '112', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:17:01', 0);
INSERT INTO `circular` VALUES (497, 'Curso pr�ctico sobre la gesti�n de la incapacidad temporal para m�dicos de familia.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/noviembre/circular_113.08.pdf">circular</a></p>', '2008-11-11', '0000-00-00', '113', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (498, 'Nueva versi�n del protocolo de env�o de partes m�dicos desde los Servicios P�blicos de Salud.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/noviembre/circular_114.08.pdf">circular</a></p>', '2008-11-12', '0000-00-00', '114', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (499, 'Resoluci�n favorable del procedimiento seguido a instancias de ASPA contra las Mutuas por su actuaci�n en el mercado de prevenci�n ante Defensa de la Competencia.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/noviembre/circular_115.08.pdf">circular</a></p>', '2008-11-12', '0000-00-00', '115', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (500, 'Temas tratados por la Ponencia de Recursos de AMAT, en su reuni�n del 12 de noviembre de 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/noviembre/circular_116.08.pdf">circular</a></p>', '2008-11-14', '0000-00-00', '116', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (501, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes (Enero-Septiembre de 2008).', '<p><a href="/uploads/file/Circulares/2008/noviembre/circular_117.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/noviembre/circular_117.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2008-11-17', NULL, '117', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:25:31', 0);
INSERT INTO `circular` VALUES (502, 'Plazos para remisi�n a Tesorer�a del fichero de rechazados por no tener solicitado el cese con la Mutua actual (ATK43).', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/noviembre/circular_118.08.pdf">circular</a></p>', '2008-11-18', '0000-00-00', '118', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (503, 'Respuesta de la Junta Consultiva de Contrataci�n Administrativa en relaci�n con la aplicaci�n de la Ley de Contratos del Sector P�blico a AMAT.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/noviembre/circular_119.08.pdf">circular</a></p>', '2008-11-18', '0000-00-00', '119', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (504, 'Nuevo dise�o de formato del registro de afiliaci�n de empresas y trabajadores.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/noviembre/circular_120.08.pdf">circular</a></p>', '2008-11-20', '0000-00-00', '120', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (505, 'Proyecto de Orden Ministerial por la que se desarrollan las normas de cotizaci�n a la Seguridad Social para el a�o 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/noviembre/circular_121.08.pdf">circular</a></p>', '2008-11-20', '0000-00-00', '121', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (506, 'Avance Estad�stico de Accidentes de Trabajo. (Enero-Septiembre de 2008).', '<p><a href="/uploads/file/Circulares/2008/diciembre/circular_122.08.01.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/diciembre/circular_122.08.02.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2008-12-04', NULL, '122', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:32:52', 0);
INSERT INTO `circular` VALUES (507, 'Evoluci�n de la Recaudaci�n y Deducciones por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Septiembre de 2008).', '<p><a href="/uploads/file/Circulares/2008/diciembre/circular_123.08.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2008/diciembre/circular_123.08.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2008-12-09', NULL, '123', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:38:42', 0);
INSERT INTO `circular` VALUES (508, 'Publicaci�n en el B.O.E. y entrada en vigor del Convenio Colectivo Sectorial para los a�os 2008-2011.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/diciembre/circular_124.08.pdf">circular</a></p>', '2008-12-15', '0000-00-00', '124', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (509, 'Proyecto de Real Decreto por el que se regula el establecimiento de un Sistema de "Bonus-Malus" con cargo al 80 por ciento del exceso de excedentes de la gesti�n de las Mutuas de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social, con la finalidad de incentivar a las empresas que contribuyan eficazmente y de manera contrastable a la reducci�n de la siniestralidad laboral.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/diciembre/circular_125.08.pdf">circular</a></p>', '2008-12-15', NULL, '125', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:39:44', 0);
INSERT INTO `circular` VALUES (510, 'Proyecto de Real Decreto por el que se modifica el Real Decreto 39/1997, de 17 de enero, por el que se aprueba el Reglamento de los Servicios de Prevenci�n, en relaci�n con la aplicaci�n de medidas para promover la mejora de la seguridad y de la salud en el trabajo de la trabajadora embarazada, que haya dado a luz o en periodo de lactancia.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/diciembre/circular_126.08.pdf">circular</a></p>', '2008-12-18', '0000-00-00', '126', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (511, 'Proyecto de "Orden por la que se establece la compensaci�n de gastos de transporte en caso de asistencia sanitaria derivada de riesgos profesionales".', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/diciembre/circular_127.08.pdf">circular</a></p>', '2008-12-30', NULL, '127', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 17:40:57', 0);
INSERT INTO `circular` VALUES (512, 'Relaci�n de circulares elaboradas por AMAT en 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2008/diciembre/circular_128.08.pdf">circular</a></p>', '2008-12-30', '0000-00-00', '128', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (513, 'Publicaci�n en el Bolet�n Oficial del Estado de la Ley 2/2008, de 23 de diciembre, de Presupuestos Generales del Estado para el a�o 2009. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_01_09.pdf">circular</a></p>', '2009-01-05', NULL, '01', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 17:16:48', 0);
INSERT INTO `circular` VALUES (514, 'Forum Europeo de Seguros de Accidentes de Trabajo y Enfermedades Profesionales. Preparaci�n de la Agenda del Grupo de Trabajo legislativo para el a�o 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_02_09.pdf">circular</a></p>', '2009-01-05', NULL, '02', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 17:33:53', 0);
INSERT INTO `circular` VALUES (515, 'Informe sobre el establecimiento de un sistema espec�fico de protecci�n por cese de actividad a favor de de los trabajadores aut�nomos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_03.09.pdf">circular</a></p>', '2009-01-07', '0000-00-00', '03', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (516, 'Puesta al cobro de la aportaci�n para la Unidad de Atenci�n Telef�nica al Usuario para la transmisi�n de los Partes M�dicos de I.T.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_04.09.pdf">circular</a></p>', '2009-01-07', '0000-00-00', '04', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (517, 'Consulta de la Comisi�n Europea de Interlocutores Sociales Europeos sobre la protecci�n de los trabajadores contra los riesgos inherentes a la exposici�n al humo del tabaco en el centro de trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_05.09.pdf">circular</a></p>', '2009-01-08', '0000-00-00', '05', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (518, 'Gu�a de buenas pr�cticas sobre implementaci�n de la Directiva 2002/44/EC (Vibraciones en el trabajo).', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_06.09.pdf">circular</a></p>', '2009-01-08', '0000-00-00', '06', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (519, 'Temas tratados por la Comisi�n de Recursos-Tesorer�a de AMAT, en su reuni�n del 13 de enero de 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_07.09.pdf">circular</a></p>', '2009-01-15', '0000-00-00', '07', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (520, 'Valores l�mite para el Tetracloruro de Carbono y �cido Ac�tico.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_08.09.pdf">circular</a></p>', '2009-01-16', '0000-00-00', '08', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (521, '2� Sesi�n Anual Abierta de la Agencia Espa�ola de Protecci�n de Datos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_09.09.pdf">circular</a></p>', '2009-01-16', '0000-00-00', '09', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (522, 'Convenio Colectivo 2008-20011.- Nuevas Tablas salariales por desviaci�n del IPC y nuevas condiciones econ�micas 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_10.09.pdf">circular</a></p>', '2009-01-16', '0000-00-00', '10', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (523, '"Proyecto de Orden por la que se modifica el art�culo 8 de la Orden TAS/3623/2006, de 28 de noviembre, por la que se regulan las actividades preventivas en el �mbito de la Seguridad Social y la financiaci�n de la Fundaci�n para la Prevenci�n de Riesgos Laborales".', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_11.09.pdf">circular</a></p>', '2009-01-20', NULL, '11', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 12:53:34', 0);
INSERT INTO `circular` VALUES (524, 'Comunicaci�n al Instituto Nacional de la Seguridad Social de los procesos de incapacidad temporal que van a cumplir doce meses.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_12_09.pdf">circular</a></p>', '2009-01-23', NULL, '12', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-03 12:46:27', 0);
INSERT INTO `circular` VALUES (525, 'Documento de posici�n de Businesseurope sobre la propuesta de la Comisi�n Europea de enmienda de la Directiva de trabajadoras embarazadas.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_13.09.pdf">circular</a></p>', '2009-01-23', '0000-00-00', '13', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (526, 'Publicaci�n en el BOE de la Orden de Cotizaci�n para el a�o 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/enero/circular_14.09.pdf">circular</a></p>', '2009-01-26', '0000-00-00', '14', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (527, 'Protecci�n de los trabajadores contra riesgos del humo del tabaco en el centro de trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/febrero/circular_15.09.pdf">circular</a></p>', '2009-02-02', '0000-00-00', '15', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (528, 'Actualizaci�n de las tarifas del Convenio Marco de cooperaci�n entre el INSS y AMAT para la pr�ctica de pruebas m�dicas.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/febrero/circular_16.09.pdf">circular</a></p>', '2009-02-03', '0000-00-00', '16', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (529, 'Promoci�n de la salud en el lugar de trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/febrero/circular_17.09.pdf">circular</a></p>', '2009-02-03', '0000-00-00', '17', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (530, 'Proyecto de Real Decreto por el que se modifica el Reglamento General de Recaudaci�n de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/febrero/circular_18.09.pdf">circular</a></p>', '2009-02-03', '0000-00-00', '18', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (531, 'Segundo Borrador de la Estrategia Iberoamericana de Seguridad y Salud en el Trabajo 2010-2013 y su Plan de Acci�n y Seguimiento.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/febrero/circular_19.09.pdf">circular</a></p>', '2009-02-05', '0000-00-00', '19', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (532, 'XXVIII Jornada Monogr�fica de Derecho vivo del trabajo. "R�gimen jur�dico-social de los trabajadores aut�nomos: puntos cr�ticos (Especial atenci�n a la problem�tica de Seguridad Social)".', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/febrero/circular_20.09.pdf">circular</a></p>', '2009-02-13', '0000-00-00', '20', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (533, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes (Enero-Diciembre de 2008).', '<p><a href="/uploads/file/Circulares/2009/febrero/circular_21.09.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2009/febrero/circular_21.09.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>', '2009-02-19', NULL, '21', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:03:13', 0);
INSERT INTO `circular` VALUES (534, 'Convenio Colectivo- Condiciones econ�micas 2008 y 2009. Comisi�n de Interpretaci�n.- Contestaci�n a las consultas n�s. 1 a 5.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/febrero/circular_22.09.pdf">circular</a></p>', '2009-02-23', '0000-00-00', '22', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (535, 'Pago de Cuotas correspondientes al Presupuesto Ordinario de Gastos de AMAT para el Ejercicio 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/marzo/circular_23.09.pdf">circular</a></p>', '2009-03-02', '0000-00-00', '23', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (536, 'Avance Estad�stico de Accidentes de Trabajo. (Enero-Diciembre de 2008)', '<p><a href="/uploads/file/Circulares/2009/marzo/circular_24.09.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2009/marzo/circular_24.09.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2009-03-13', NULL, '24', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:04:50', 0);
INSERT INTO `circular` VALUES (537, 'Evoluci�n de la Recaudaci�n y Deducciones por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Diciembre de 2008).', '<p>&nbsp;</p>\r\n<p><a href="/uploads/file/Circulares/2009/marzo/circular_25.09.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2009/marzo/circular_25.09.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>', '2009-03-13', NULL, '25', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:05:43', 0);
INSERT INTO `circular` VALUES (538, 'Migraci�n a IFIWeb de la actual aplicaci�n de descarga de ficheros del INSS y de TGSS.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/marzo/circular_26.09.pdf">circular</a></p>', '2009-03-13', '0000-00-00', '26', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (539, 'Comparativas internacionales de sistemas de cotizaciones y gastos de contingencias profesionales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/marzo/circular_27.09.pdf">circular</a></p>', '2009-03-13', '0000-00-00', '27', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (540, 'Petici�n de aclaraciones sobre las Ordenes que regulan la contraprestaci�n a satisfacer por las Mutuas por los servicios de administraci�n complementaria de la directa.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/marzo/circular_28.09.pdf">circular</a></p>', '2009-03-20', '0000-00-00', '28', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (541, 'Publicaci�n en el Bolet�n Oficial del Estado del Real Decreto 295/2009, por el que se regulan las prestaciones econ�micas del Sistema de Seguridad Social por maternidad, paternidad, riesgo durante el embarazo y riesgo durante la lactancia natural. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/marzo/circular_29.09.pdf">circular</a></p>', '2009-03-23', '0000-00-00', '29', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (542, 'Convocatoria y Bases Reguladoras de los Premios Nacionales 28 de Abril de la Fundaci�n para la Prevenci�n de Riesgos Laborales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/marzo/circular_30.09.pdf">circular</a></p>', '2009-03-23', '0000-00-00', '30', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (543, 'Bolet�n Forum News n� 30 ? 01/ 2009 del Forum Europeo de seguros contra los Accidentes de Trabajo y Enfermedades Profesionales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/marzo/circular_31.09.pdf">circular</a></p>', '2009-03-23', '0000-00-00', '31', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (544, 'Criterio T�cnico de la Inspecci�n de Trabajo y Seguridad Social en relaci�n con los procedimientos de regulaci�n de empleo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/marzo/circular_32.09.pdf">circular</a></p>', '2009-03-23', '0000-00-00', '32', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (545, 'Proposici�n no de Ley presentada por el Grupo Parlamentario Socialista, para que, en el seno del di�logo social, se realice un an�lisis de los resultados obtenidos en la aplicaci�n de los nuevos mecanismos de control de la incapacidad temporal, a fin de avanzar en su perfeccionamiento y en la mejora de la cooperaci�n y coordinaci�n de todas las partes implicadas en el mismo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/marzo/circular_33.09.pdf">circular</a></p>', '2009-03-27', '0000-00-00', '33', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (546, 'Convenio Colectivo. Comisi�n Mixta de Interpretaci�n.- Contestaci�n a la consulta n�. 6.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/abril/circular_34.09.pdf">circular</a></p>', '2009-04-01', '0000-00-00', '34', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (547, 'Nota sobre la 71 reuni�n del Comit� Cient�fico para los l�mites de exposici�n profesional a agentes qu�micos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/abril/circular_35.09.pdf">circular</a></p>', '2009-04-20', '0000-00-00', '35', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (548, 'Publicaci�n en el Bolet�n Oficial del Estado de la Orden por la que se establece la compensaci�n de gastos de transporte en los casos de asistencia sanitaria derivada de riesgos profesionales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/abril/circular_36.09.pdf">circular</a></p>', '2009-04-21', '0000-00-00', '36', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (549, 'Proyecto de Real Decreto de adaptaci�n de la legislaci�n de Prevenci�n de Riesgos Laborales a la Administraci�n General del Estado.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/abril/circular_37.09.pdf">circular</a></p>', '2009-04-24', '0000-00-00', '37', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (550, 'Proyecto de Orden TIN por la que se dictan las normas para la elaboraci�n de los Presupuestos de la Seguridad Social para el ejercicio 2010.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/abril/circular_38.09.pdf">circular</a></p>', '2009-04-24', '0000-00-00', '38', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (551, 'Publicaciones de inter�s: "Previsi�n sobre riesgos emergentes qu�micos relacionados con seguridad laboral y salud" (Agencia Europea para la Seguridad y Salud en el Trabajo) y "Las Enfermedades profesionales en Europa. Estad�sticas 1990-2006 y actualidad jur�dica" (EUROGIP).', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/abril/circular_39.09.pdf">circular</a></p>', '2009-04-27', NULL, '39', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:10:46', 0);
INSERT INTO `circular` VALUES (552, 'Proyecto de Resoluci�n por la que se dictan instrucciones en materia de c�lculo de capitales coste y sobre constituci�n de la Mutuas del capital correspondiente a determinadas prestaciones derivadas de enfermedades profesionales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/abril/circular_40.09.pdf">circular</a></p>', '2009-04-28', '0000-00-00', '40', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (553, 'Nueva aplicaci�n de acceso al servicio de informaci�n laboral de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/abril/circular_41.09.pdf">circular</a></p>', '2009-04-29', '0000-00-00', '41', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (554, '"Gu�a para la elaboraci�n del Plan de actuaci�n de las empresas frente a emergencias. Pandemia de gripe".', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/mayo/circular_42.09.pdf">circular</a></p>', '2009-05-05', NULL, '42', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:21:46', 0);
INSERT INTO `circular` VALUES (555, 'Proyecto de Real Decreto sobre distintivo "Igualdad en la Empresa". ', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/mayo/circular_43.09.pdf">circular</a></p>', '2009-05-07', NULL, '43', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:25:08', 0);
INSERT INTO `circular` VALUES (556, '"Informe sobre las actuaciones en relaci�n con el control de los procesos y el gasto de la prestaci�n de incapacidad temporal".', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/mayo/circular_44.09.pdf">circular</a></p>', '2009-05-07', NULL, '44', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:24:39', 0);
INSERT INTO `circular` VALUES (557, 'Proyecto de Resoluci�n de la Secretar�a de Estado de la Seguridad Social por la que se dictan instrucciones complementarias para la elaboraci�n del Anteproyecto de Presupuestos para el ejercicio 2010.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/mayo/circular_45.09.pdf">circular</a></p>', '2009-05-19', '0000-00-00', '45', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (558, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes del periodo Enero-Marzo de 2009.', '<p><a href="/uploads/file/Circulares/2009/mayo/circular_46.09.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2009/mayo/circular_46.09.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2009-05-20', NULL, '46', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:27:28', 0);
INSERT INTO `circular` VALUES (559, 'Modificaci�n del formato de Fichero de Recaudaci�n por nueva cotizaci�n REA 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/mayo/circular_47.09.pdf">circular</a></p>', '2009-05-20', '0000-00-00', '47', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (560, '"La calidad de la Prevenci�n de Riesgos Laborales".', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/mayo/circular_48.09.pdf">circular</a></p>', '2009-05-26', NULL, '48', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:28:34', 0);
INSERT INTO `circular` VALUES (561, 'Convenio Colectivo. Comisi�n Mixta de Interpretaci�n.- Contestaci�n a las consultas n�s. 7 a 10.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/mayo/circular_49.09.pdf">circular</a></p>', '2009-05-28', '0000-00-00', '49', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (562, 'Tel�fono de Informaci�n sobre Mutuas 902 112 651. Llamadas recibidas.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/junio/circular_50.09.pdf">circular</a></p>', '2009-06-02', '0000-00-00', '50', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (563, 'Incidencia en la recaudaci�n de julio 2008.- Asignaci�n de importes de cobros y compensaciones a Mutuas por IT de contingencias comunes.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/junio/circular_51.09.pdf">circular</a></p>', '2009-06-02', '0000-00-00', '51', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (564, 'Fecha de inicio de la Migraci�n a IFIWeb de la actual aplicaci�n de descarga de ficheros del INSS y de TGSS. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/junio/circular_52.09.pdf">circular</a></p>', '2009-06-02', '0000-00-00', '52', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (565, 'Temas tratados por la Ponencia de Relaciones Laborales de AMAT, en su reuni�n del 19 de mayo de 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/junio/circular_53.09.pdf">circular</a></p>', '2009-06-08', '0000-00-00', '53', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (566, 'Avance Estad�stico de Accidentes de Trabajo y Enfermedades Profesionales. (Enero a Marzo de 2009).', '<p><a href="/uploads/file/Circulares/2009/junio/circular_54.09.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2009/junio/circular_54.09.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>', '2009-06-09', NULL, '54', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:35:06', 0);
INSERT INTO `circular` VALUES (567, 'Aplazamiento de la fecha de finalizaci�n del servicio telnet 3270, de acceso al servicio de informaci�n laboral de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/junio/circular_55.09.pdf">circular</a></p>', '2009-06-10', '0000-00-00', '55', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (568, 'Proyecto de Real Decreto por el que se modifica el Reglamento General sobre colaboraci�n en la gesti�n de las Mutuas de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/junio/circular_56.09.pdf">circular</a></p>', '2009-06-10', '0000-00-00', '56', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (569, 'Comparecencia del Sr. Secretario General de la CEOE en la Comisi�n de Trabajo e Inmigraci�n del Congreso de los Diputados .', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/junio/circular_57.09.pdf">circular</a></p>', '2009-06-12', '0000-00-00', '57', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (570, 'Protocolo de colaboraci�n entre el Ministerio de Trabajo e Inmigraci�n y la Comunidad Aut�noma de Arag�n para el fomento de la cooperaci�n en materia de asistencia sanitaria.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/junio/circular_58.09.pdf">circular</a></p>', '2009-06-19', '0000-00-00', '58', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (571, 'Tiempos est�ndar de INCAPACIDAD TEMPORAL ', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/junio/circular_59.09.pdf">circular</a></p>', '2009-06-26', '0000-00-00', '59', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (572, 'Abono del exceso de excedentes de A.T. e I.T.C.C. derivados de la gesti�n realizada por las Mutuas correspondiente al ejercicio 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/julio/circular_60.09.pdf">circular</a></p>', '2009-07-01', '0000-00-00', '60', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (573, 'Acuerdo Marco de Colaboraci�n entre el Ministerio de Trabajo e Inmigraci�n y el Departamento de Salud de la Administraci�n de la Generalidad de Catalu�a.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/julio/circular_61.09.pdf">circular</a></p>', '2009-07-08', '0000-00-00', '61', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (574, 'Bolet�n Forum News n� 31 ? 06/ 2009 del Forum Europeo de seguros contra los Accidentes de Trabajo y Enfermedades Profesionales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/julio/circular_62.09.pdf">circular</a></p>', '2009-07-10', '0000-00-00', '62', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (575, 'Orden por la que se implanta el proceso telem�tico normalizado cas@.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/julio/circular_63.09.pdf">circular</a></p>', '2009-07-20', '0000-00-00', '63', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (576, 'Proyecto de Resoluci�n por la que se establecen las actuaciones de control y verificaci�n de las compensaciones en los documentos de cotizaci�n por pago delegado del subsidio de incapacidad temporal. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/julio/circular_64.09.pdf">circular</a></p>', '2009-07-20', '0000-00-00', '64', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (577, 'Aplazamiento de la fecha de finalizaci�n del servicio telnet 3270, de acceso al servicio de informaci�n laboral de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/julio/circular_65.09.pdf">circular</a></p>', '2009-07-24', '0000-00-00', '65', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (578, 'Solicitud de informaci�n para la elaboraci�n de una publicaci�n sobre Trabajo y Mujer en el contexto de la Seguridad y la Salud en el Trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/agosto/circular_66.09.pdf">circular</a></p>', '2009-08-05', '0000-00-00', '66', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (579, 'Proyecto de Orden por la que se fijan las compensaciones a los miembros de la Junta Directiva y de la Comisi�n de Prestaciones Especiales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/agosto/circular_67.09.pdf">circular</a></p>', '2009-08-11', '0000-00-00', '67', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (580, 'Contestaci�n de la Tesorer�a General a consultas planteadas.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/septiembre/circular_68.09.pdf">circular</a></p>', '2009-09-11', '0000-00-00', '68', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (581, '"L�mites de Exposici�n Profesional para Agentes Qu�micos en Espa�a 2010".', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/septiembre/circular_69.09.pdf">circular</a></p>', '2009-09-11', NULL, '69', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:44:53', 0);
INSERT INTO `circular` VALUES (582, 'Evoluci�n de la prestaci�n de Riesgo durante el Embarazo y Riesgo durante la Lactancia (Enero-Junio de 2009).', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/septiembre/circular_70.09.pdf">circular</a></p>', '2009-09-22', '0000-00-00', '70', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (583, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes del periodo Enero-Junio de 2009.', '<p><a href="/uploads/file/Circulares/2009/septiembre/circular_71.09.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2009/septiembre/circular_71.09.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2009-09-24', NULL, '71', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:46:59', 0);
INSERT INTO `circular` VALUES (584, 'Evoluci�n de la Recaudaci�n y Deducciones por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Junio de 2009).', '<p><a href="/uploads/file/Circulares/2009/septiembre/circular_72.09.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2009/septiembre/circular_72.09.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2009-09-30', NULL, '72', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:47:51', 0);
INSERT INTO `circular` VALUES (585, 'Avance Estad�stico de Accidentes de Trabajo y Enfermedades Profesionales. (Enero a Junio de 2009).', '<p><a href="/uploads/file/Circulares/2009/septiembre/circular_73.09.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2009/septiembre/circular_73.09.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2009-09-30', NULL, '73', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 13:48:51', 0);
INSERT INTO `circular` VALUES (586, 'Instrucciones del Instituto Nacional de la Seguridad Social en relaci�n con el Real Decreto 1430/2009, de 11 de septiembre, por el que se desarrolla reglamentariamente la Ley 40/2007, de 4 de diciembre.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/septiembre/circular_74.09.pdf">circular</a></p>', '2009-09-30', '0000-00-00', '74', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (587, 'Otras Instrucciones del Instituto Nacional de la Seguridad Social en relaci�n con el Real Decreto 1430/2009, de 11 de septiembre, por el que se desarrolla reglamentariamente la Ley 40/2007, de 4 de diciembre.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_75.09.pdf">circular</a></p>', '2009-10-01', '0000-00-00', '75', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (588, 'Informe de llamadas del Tel�fono de Informaci�n sobre Mutuas de septiembre de 2009.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_76.09.pdf">circular</a></p>', '2009-10-01', '0000-00-00', '76', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (589, 'Proyecto de Ley de Presupuestos Generales del Estado para el a�o 2010. Aspectos de inter�s.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_77.09.pdf">circular</a></p>', '2009-10-02', '0000-00-00', '77', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (590, 'Fecha de cierre de la transacci�n ATK43.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_78.09.pdf">circular</a></p>', '2009-10-02', '0000-00-00', '78', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (591, 'Informe Preliminar sobre el Anteproyecto de Presupuesto de la Seguridad Social para el Sector de las Mutuas de Accidentes de Trabajo para el ejercicio 2010.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_79.09.pdf">circular</a></p>', '2009-10-02', '0000-00-00', '79', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (592, 'Proyecto de Real Decreto sobre protecci�n de la salud y la seguridad de los trabajadores contra los riesgos relacionados con la exposici�n a radiaciones �pticas artificiales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_80.09.pdf">circular</a></p>', '2009-10-06', '0000-00-00', '80', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (593, 'Comparecencia del Sr. Secretario de Estado de la Seguridad Social en el Congreso al objeto de informar sobre temas relativos al proyecto de Ley de Presupuestos Generales del Estado para el a�o 2010.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_81.09.pdf">circular</a></p>', '2009-10-14', '0000-00-00', '81', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (594, 'Criterio del Instituto Nacional de la Seguridad Social en relaci�n con las propuestas que deben plantear las Mutuas en los procesos por incapacidad temporal por contingencias profesionales que superen los doce meses.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_82.09.pdf">circular</a></p>', '2009-10-15', '0000-00-00', '82', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (595, 'Proyecto de Real Decreto por el que se regula el establecimiento de un sistema de incentivos a las empresas que contribuyan eficazmente y de manera contrastable a la reducci�n y a la prevenci�n de la siniestralidad laboral.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_83.09.pdf">circular</a></p>', '2009-10-16', '0000-00-00', '83', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (596, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes del periodo Enero-Septiembre de 2009.', '<p><a href="/uploads/file/Circulares/2009/octubre/circular_84.09.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2009/octubre/circular_84.09.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2009-10-16', NULL, '84', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 14:19:31', 0);
INSERT INTO `circular` VALUES (597, 'Contestaci�n a la solicitud de AMAT del informe de la Abogac�a General del Estado en relaci�n con la consulta formulada por el MTIN sobre competencia de las Mutuas para controlar situaciones de Incapacidad temporal.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_85.09.pdf">circular</a></p>', '2009-10-28', '0000-00-00', '85', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (598, 'Solicitud de confirmaci�n sobre la previsi�n de aplicaci�n de la figura del reaseguro a las enfermedades profesionales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_86.09.pdf">circular</a></p>', '2009-10-28', '0000-00-00', '86', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (599, 'Proyecto de Real Decreto por el que se regulan las condiciones para el reconocimiento de efectos profesionales a t�tulos de especialista obtenidos en estados no miembros de la Uni�n Europea.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/octubre/circular_87.09.pdf">circular</a></p>', '2009-10-29', '0000-00-00', '87', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (600, '"Proyecto de Orden por la que se regulan las operaciones de cierre del ejercicio 2009".', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/noviembre/circular_88.09.pdf">circular</a></p>', '2009-11-06', NULL, '88', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-02 14:16:25', 0);
INSERT INTO `circular` VALUES (601, 'Nueva versi�n del protocolo de comunicaci�n al Instituto Nacional de la Seguridad Social de los procesos de incapacidad temporal que van a cumplir doce meses.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/noviembre/circular_89.09.pdf">circular</a></p>', '2009-11-10', '0000-00-00', '89', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (602, 'Propuesta de modelo de Indicadores para el Seguimiento de la Estrategia Espa�ola de Seguridad y Salud en el Trabajo 2007-2012.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/noviembre/circular_90.09.pdf">circular</a></p>', '2009-11-12', '0000-00-00', '90', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (603, 'Proyecto de Real Decreto sobre revalorizaci�n de las pensiones del Sistema de la Seguridad Social y de otras prestaciones sociales p�blicas para el ejercicio 2010.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/noviembre/circular_91.09.pdf">circular</a></p>', '2009-11-13', '0000-00-00', '91', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (604, 'Modificaci�n del protocolo de comunicaci�n al Instituto Nacional de la Seguridad Social de los procesos de incapacidad temporal que van a cumplir doce meses.', '<p>&nbsp;<a href="/uploads/file/Circulares/2009/noviembre/circular_92.09.pdf">circular</a></p>', '2009-11-13', '0000-00-00', '92', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (736, 'Publicaci�n de la Orden por la que se establece el modelo de parte de enfermedad profesional.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/enero/circular_01.07.pdf">circular</a></p>', '2007-01-08', '0000-00-00', '01', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (737, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Septiembre de 2006).', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/enero/circular_02.07.1.pdf">circular</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/enero/circular_02.07.2.xls">Enlace con fichero XLS</a></p>', '2007-01-12', NULL, '02', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-12-10 17:19:43', 0);
INSERT INTO `circular` VALUES (738, 'Nuevo dise�o de formato de los registros de afiliaci�n de trabajadores por cuenta ajena. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/enero/circular_03.07.pdf">circular</a></p>', '2007-01-22', '0000-00-00', '03', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (739, 'Nuevo plazo para la entrada en vigor de la nueva versi�n de Delt@.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/enero/circular_04.07.pdf">circular</a></p>', '2007-01-22', '0000-00-00', '04', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (740, 'Convenio Colectivo 2004-2007.- Aplicaci�n de la cl�usula de revisi�n salarial y nuevas condiciones econ�micas 2007.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/enero/circular_05.07.pdf">circular</a></p>', '2007-01-23', '0000-00-00', '05', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (741, 'Pago de Cuotas Ordinarias a AMAT para el Ejercicio 2007', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/enero/circular_06.07.pdf">circular</a></p>', '2007-01-25', '0000-00-00', '06', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (742, 'Documento de discusi�n para una Estrategia de Salud', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/enero/circular_07.07.pdf">circular</a></p>', '2007-01-29', '0000-00-00', '07', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (743, 'Aclaraciones sobre la aplicaci�n de la Nueva Tarifa de AT y EP. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/enero/circular_08.07.pdf">circular</a></p>', '2007-01-29', '0000-00-00', '08', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (744, 'Actualizaci�n del Convenio Marco entre el INSS y AMAT para la emisi�n de informes y pr�ctica de pruebas complementarias.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/enero/circular_09.07.pdf">circular</a></p>', '2007-01-31', '0000-00-00', '09', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (745, 'Interpretaci�n del Convenio Colectivo.- Contestaci�n a las consultas n�s. 61 y 62.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular__10.07.pdf">circular</a></p>', '2007-02-01', NULL, '10', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-11-17 22:24:09', 0);
INSERT INTO `circular` VALUES (746, 'Env�o a las Mutuas de las copias de las resoluciones de devoluci�n de ingresos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular_11.07.pdf">circular</a></p>', '2007-02-01', '0000-00-00', '11', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (747, 'Consulta sobre pago a colaboradores por aut�nomos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular_12.07.pdf">circular</a></p>', '2007-02-08', '0000-00-00', '12', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (748, 'Acta de la sesi�n extraordinaria del Consejo General del Instituto Nacional de la Seguridad Social, celebrada el d�a dieciocho de diciembre de dos mil seis.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular_13.07.pdf">circular</a></p>', '2007-02-12', '0000-00-00', '13', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (749, 'Proyecto de Real Decreto sobre la publicidad de las sanciones por infracciones muy graves en materia de prevenci�n de riesgos laborales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular_14.07.pdf">circular</a></p>', '2007-02-13', '0000-00-00', '14', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (750, 'Noticias del Sistema RED informando sobre la cotizaci�n por accidentes de trabajo y enfermedades profesionales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular_15.07.pdf">circular</a></p>', '2007-02-15', '0000-00-00', '15', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (751, 'Fusi�n de SAT y EGARA / Fusi�n de REDDIS y MATT. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular_16.07.pdf">circular</a></p>', '2007-02-20', '0000-00-00', '16', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (752, 'Resoluci�n de la Secretar�a de Estado de la Seguridad Social, por la que se determinan las actividades preventivas a realizar por las mutuas de accidentes de trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular_17.07.pdf">circular</a></p>', '2007-02-21', '0000-00-00', '17', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (753, 'Informaci�n sobre nueva tarifa de accidentes en la Intranet de AMAT.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular_18.07.pdf">circular</a></p>', '2007-02-21', '0000-00-00', '18', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (754, 'Modificaci�n de los Documentos de Asociaci�n por aplicaci�n de la nueva tarifa de accidentes. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular_19.07.pdf">circular</a></p>', '2007-02-22', '0000-00-00', '19', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (755, 'Grupo de Trabajo de Aut�nomos y la PRL. Formaci�n. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/febrero/circular_20.07.pdf">circular</a></p>', '2007-02-27', '0000-00-00', '20', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (756, 'Proyecto de Resoluci�n de la Secretar�a de Estado de la Seguridad Social, por la que se desarrolla la Orden de 2 de agosto de 1995 en materia de competencias y funcionamiento de las Comisiones de Control y Seguimiento.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_21.07.pdf">circular</a></p>', '2007-03-01', '0000-00-00', '21', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (757, 'Proyecto de Resoluci�n de la Secretar�a de Estado de la Seguridad Social, por la que se determinan las actividades a realizar durante el a�o 2007 por el Instituto Nacional de Seguridad e Higiene en el Trabajo, en desarrollo de la Orden TAS/3623/2006, de 28 de noviembre, por la que se regulan las actividades preventivas en el �mbito de la Seguridad Social y la financiaci�n de la Fundaci�n para la Prevenci�n de Riesgos Laborales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_22.07.pdf">circular</a></p>', '2007-03-02', '0000-00-00', '22', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (758, 'Informe presentado por AMAT a la Secretar�a de Estado de la Seguridad Social, en relaci�n con el proyecto de Resoluci�n por la que se determinan las actividades preventivas a realizar por las Mutuas de Accidentes de Trabajo durante el a�o 2007.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_23.07.pdf">circular</a></p>', '2007-03-05', '0000-00-00', '23', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (759, 'Estrategia comunitaria para promover la salud y seguridad en el trabajo (2007-2012).', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_24.07.pdf">circular</a></p>', '2007-03-06', '0000-00-00', '24', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (760, 'Temas tratados en la reuni�n celebrada con la Tesorer�a General de la Seguridad Social el d�a 26 de febrero de 2007. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_25.07.pdf">circular</a></p>', '2007-03-08', '0000-00-00', '25', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (761, 'Interpretaci�n del Convenio Colectivo.- Contestaci�n a la consulta n�. 64 .- Publicaci�n en el BOE salarios 2007.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_26.07.pdf">circular</a></p>', '2007-03-14', '0000-00-00', '26', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (762, 'Evoluci�n de la Recaudaci�n y Deducciones por Contingencias Profesionales y por Contingencias Comunes del periodo Enero-Diciembre de 2006.', '<p><a href="/uploads/file/Circulares/2007/marzo/circular_27.07.1.pdf">Enlace con documentaci&oacute;n adjunta (Fichero PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/marzo/circular_27.07.2.xls">Enlace con documentaci&oacute;n adjunta (Fichero XLS)</a></p>\r\n<p>&nbsp;</p>', '2007-03-15', NULL, '27', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-12-22 10:15:59', 0);
INSERT INTO `circular` VALUES (763, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero - Diciembre de 2006).', '<p><a href="/uploads/file/Circulares/2007/marzo/circular_28.07.1.pdf"><u><span style="text-decoration: underline;">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</span></u></a></p>\r\n<p><a href="/uploads/file/Circulares/2007/marzo/circular_28.07.2.xls"><u>Enlace con documentaci&oacute;n adjunta (Archivo XLS)</u></a></p>', '2007-03-15', NULL, '28', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-12-22 10:21:42', 0);
INSERT INTO `circular` VALUES (764, 'Criterios interpretativos, dados por la Direcci�n General de Ordenaci�n de la Seguridad Social, en relaci�n con la aplicaci�n de la Tarifa de primas de AT y EP. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_29.07.pdf">circular</a></p>', '2007-03-16', '0000-00-00', '29', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (765, 'SEMANA EUROPEA 2008. EVALUACI�N DE RIESGOS.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_30.07.pdf">circular</a></p>', '2007-03-19', '0000-00-00', '30', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (766, 'Informe del Observatorio de Riesgos: Perspectivas de los expertos sobre riesgos biol�gicos emergentes relacionados con la seguridad y la salud en el trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_31.07.pdf">circular</a></p>', '2007-03-22', '0000-00-00', '31', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (767, 'Segunda fase de Consulta de la Comisi�n Europea a los Agentes Sociales sobre los trastornos m�sculo-esquel�ticos de origen profesional.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_32.07.pdf">circular</a></p>', '2007-03-23', '0000-00-00', '32', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (768, 'Informe de salud laboral. Espa�a, 2006.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_33.07.pdf">circular</a></p>', '2007-03-23', '0000-00-00', '33', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (769, 'Proyecto de Orden Ministerial por la que se dictan las normas para la elaboraci�n de los Presupuestos de la Seguridad Social para el ejercicio 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_34.07.pdf">circular</a></p>', '2007-03-27', '0000-00-00', '34', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (770, 'Fusi�n de "La Previsora" y "Mutualia".', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_35.07.pdf">circular</a></p>', '2007-03-28', NULL, '35', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-11-17 22:30:59', 0);
INSERT INTO `circular` VALUES (771, 'Propuesta de posici�n de Businesseurope (UNICE) sobre la Estrategia comunitaria para promover la salud y seguridad en el trabajo (2007-2012).', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_36.07.pdf">circular</a></p>', '2007-03-29', '0000-00-00', '36', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (772, 'Observaciones enviadas a CEOE respecto a la Segunda fase de Consulta de la Comisi�n Europea sobre los trastornos m�sculoesquel�ticos de origen profesional.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_37.07.pdf">circular</a></p>', '2007-03-29', '0000-00-00', '37', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (773, 'Planes y objetivos de la Inspecci�n de Trabajo y Seguridad Social para el a�o 2007', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_38.07.pdf">circular</a></p>', '2007-03-30', '0000-00-00', '38', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (774, 'Documento de Businesseurope (UNICE) sobre la evaluaci�n de la estrategia para los a�os 2002-2006.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/marzo/circular_39.07.pdf">circular</a></p>', '2007-03-30', '0000-00-00', '39', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (775, 'Comunicaci�n al Instituto Nacional de la Seguridad Social de los procesos de incapacidad temporal que van a cumplir doce meses.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_40.07.pdf">circular</a></p>', '2007-04-09', '0000-00-00', '40', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (776, 'Puesta al cobro de la aportaci�n para el �rgano de Resoluci�n de Conflictos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_41.07.pdf">circular</a></p>', '2007-04-09', '0000-00-00', '41', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (777, 'Plan estrat�gico de la Inspecci�n de Trabajo y Seguridad Social para el periodo 2004-2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_42.07.pdf">circular</a></p>', '2007-04-11', '0000-00-00', '42', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (778, 'Gu�as T�cnicas para la Evaluaci�n y Prevenci�n de los Riesgos relacionados con las vibraciones mec�nicas y el ruido en los lugares de trabajo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_43.07.pdf">circular</a></p>', '2007-04-16', '0000-00-00', '43', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (779, 'Creaci�n de nueva Situaci�n Adicional de Afiliaci�n para el r�gimen 3011 y Nueva transacci�n de Tesorer�a.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_44.07.pdf">circular</a></p>', '2007-04-16', '0000-00-00', '44', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (780, 'Nueva transacci�n de Tesorer�a para mecanizar, directamente por las Mutuas en el F.G.A., las solicitudes recibidas de Trabajadores Aut�nomos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_45.07.pdf">circular</a></p>', '2007-04-16', '0000-00-00', '45', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (781, 'Constituci�n de la Comisi�n Negociadora del primer Convenio Colectivo de �mbito estatal para el sector de Prevenci�n de Riesgos Laborales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_46.07.pdf">circular</a></p>', '2007-04-16', '0000-00-00', '46', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (782, 'Incidencia en la imputaci�n de cuotas del RETA en la recaudaci�n correspondiente a enero de 2007. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_47.07.pdf">circular</a></p>', '2007-04-19', '0000-00-00', '47', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (783, 'Temas tratados por la Ponencia de Recursos Econ�micos de AMAT, en su reuni�n del 17 de abril de 2007. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_48.07.pdf">circular</a></p>', '2007-04-19', '0000-00-00', '48', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (784, 'Aprobaci�n de la Comisi�n Mixta para las relaciones con el Tribunal de Cuentas del Informe de Fiscalizaci�n especial sobre la constituci�n y materializaci�n de la provisi�n para contingencias en tramitaci�n y de las reservas obligatorias.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_49.07.pdf">circular</a></p>', '2007-04-19', '0000-00-00', '49', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (785, 'Interpretaci�n del Convenio Colectivo.- Contestaci�n a las consultas n�s. 65 a 67.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_50.07.pdf">circular</a></p>', '2007-04-20', '0000-00-00', '50', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (786, 'Proyecto de Resoluci�n de la Secretar�a de Estado de la Seguridad Social por el que se dictan instrucciones complementarias para la elaboraci�n del anteproyecto de Presupuesto para el ejercicio 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_51.07.pdf">circular</a></p>', '2007-04-27', '0000-00-00', '51', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (787, 'Dise�o de registro para comunicar a Tesorer�a, v�a IFIWEB, movimientos en el R�gimen 3011. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/abril/circular_52.07.pdf">circular</a></p>', '2007-04-27', '0000-00-00', '52', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (788, 'Proyecto de Reglamento de desarrollo de la Ley Org�nica de Protecci�n de Datos de Car�cter Personal. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_53.07.pdf">circular</a></p>', '2007-05-08', '0000-00-00', '53', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (789, 'Ley Reguladora del Fondo de Reserva de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_54.07.pdf">circular</a></p>', '2007-05-08', '0000-00-00', '54', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (790, 'Subsanaci�n de la incidencia en la imputaci�n de cuotas del RETA en la recaudaci�n correspondiente a enero de 2007. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_55.07.pdf">circular</a></p>', '2007-05-08', '0000-00-00', '55', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (791, 'Puesta en funcionamiento para las Mutuas de la transacci�n ATK 43, de la Tesorer�a General de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_56.07.pdf">circular</a></p>', '2007-05-08', '0000-00-00', '56', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (792, 'Modificaci�n del Dise�o de registro de datos del Fichero de Datos TC2. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_57.07.pdf">circular</a></p>', '2007-05-10', '0000-00-00', '57', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (793, 'Env�o de informaci�n a Tesorer�a de los pagos directos realizados por las Mutuas a las trabajadoras por riesgo durante la lactancia natural y el embarazo.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_58.07.pdf">circular</a></p>', '2007-05-10', '0000-00-00', '58', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (794, 'Dise�o de registro de intercambio de ficheros en la transacci�n ATK 43. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_59.07.pdf">circular</a></p>', '2007-05-10', '0000-00-00', '59', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (795, 'Traspasos autom�ticos de duplicidades de cobros atrasados procedentes de pago electr�nico. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_60.07.pdf">circular</a></p>', '2007-05-10', '0000-00-00', '60', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (796, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Marzo de 2007).', '<p><a href="/uploads/file/Circulares/2007/mayo/circular_61.07.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/mayo/circular_61.07.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>', '2007-05-16', NULL, '61', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-12-22 10:57:36', 0);
INSERT INTO `circular` VALUES (797, 'Borrador sobre la "Gu�a T�cnica sobre la integraci�n de la prevenci�n de riesgos laborales en el sistema general de gesti�n de la empresa".', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_62.07.pdf">circular</a></p>', '2007-05-24', NULL, '62', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-11-17 22:35:16', 0);
INSERT INTO `circular` VALUES (798, 'Semana Europea 2008. Evaluaci�n de Riesgos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_63.07.pdf">circular</a></p>', '2007-05-29', '0000-00-00', '63', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (799, 'Mensaje aparecido en las consultas de Mutuas a Tesorer�a sobre justificaci�n de acceso datos protegidos. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/mayo/circular_64.07.pdf">circular</a></p>', '2007-05-30', '0000-00-00', '64', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (800, 'Avance Estad�stico de Accidentes de Trabajo. (Enero a Marzo de 2007)', '<p><a href="/uploads/file/Circulares/2007/junio/circular_65.07.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/junio/circular_65.07.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a><span style="text-decoration: underline;"><br />\r\n</span></p>', '2007-06-01', NULL, '65', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-12-22 11:26:16', 0);
INSERT INTO `circular` VALUES (801, 'Informe presentado por AMAT en relaci�n con el Proyecto de Reglamento de desarrollo de la Ley Org�nica de Protecci�n de Datos de Car�cter Personal. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/junio/circular_66.07.pdf">circular</a></p>', '2007-06-05', '0000-00-00', '66', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (802, 'Incidencia en recaudaci�n de febrero 2007.- env�o de ficheros complementarios.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/junio/circular_67.07.pdf">circular</a></p>', '2007-06-07', '0000-00-00', '67', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (803, 'Env�o del Oficio de Tesorer�a General sobre Bonificaciones en I+D+I.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/junio/circular_68.07.pdf">circular</a></p>', '2007-06-11', '0000-00-00', '68', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (804, 'Evoluci�n de la Recaudaci�n y Deducciones por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Marzo de 2007).', '<p><a href="/uploads/file/Circulares/2007/junio/circular_69.07.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/junio/circular_69.07.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>', '2007-06-14', NULL, '69', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:16:18', 0);
INSERT INTO `circular` VALUES (805, 'Proyecto de Real Decreto sobre receta m�dica y orden hospitalaria de dispensaci�n.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/junio/circular_70.07.pdf">circular</a></p>', '2007-06-15', '0000-00-00', '70', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (806, 'Interpretaci�n del Convenio Colectivo.- Contestaci�n a las consultas n�s. 68 a 72.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/junio/circular_71.07.pdf">circular</a></p>', '2007-06-22', '0000-00-00', '71', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (807, 'Ingreso de Excedentes Contingencias Comunes y Profesionales.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_72.07.pdf">circular</a></p>', '2007-07-02', '0000-00-00', '72', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (808, 'Estrategia Espa�ola de Seguridad y Salud en el Trabajo (2007- 2012).', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_73.07.pdf">circular</a></p>', '2007-07-04', '0000-00-00', '73', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (809, 'Comunicaci�n a Tesorer�a de las situaciones adicionales de afiliaci�n 216 a trav�s de IFIWEB.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_74.07.pdf">circular</a></p>', '2007-07-09', '0000-00-00', '74', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (810, 'Nuevo dise�o de formato del registro de afiliaci�n con motivo del cambio de encuadramiento del r�gimen especial agrario.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_75.07.pdf">circular</a></p>', '2007-07-09', '0000-00-00', '75', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (811, 'Criterio de la Direcci�n General de Trabajo sobre el Libro Registro de Contratas y Subcontratas.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_76.07.pdf">circular</a></p>', '2007-07-20', '0000-00-00', '76', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (812, 'Plan de continuidad de las empresas frente a emergencias. Pandemia de gripe', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_77.07.pdf">circular</a></p>', '2007-07-24', '0000-00-00', '77', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (813, 'Proyecto de Orden por la que se modifica la Orden TAS/2865/2003, de 13 de octubre, por la que se regula el convenio especial en el Sistema de Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_78.07.pdf">circular</a></p>', '2007-07-24', '0000-00-00', '78', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (814, 'Proyecto de Orden Ministerial por la que se modifica la Orden TAS/1562/2005, de 25 de mayo, por la que se establecen normas para la aplicaci�n y desarrollo del Reglamento general de recaudaci�n de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_79.07.pdf">circular</a></p>', '2007-07-25', '0000-00-00', '79', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (815, 'Borrador de "Gu�a T�cnica para la evaluaci�n y prevenci�n de los riesgos relacionados con la exposici�n al amianto. Gu�a t�cnica del Real Decreto 396/2006, de 31 de Marzo, por el que se establecen disposiciones m�nimas de seguridad y salud aplicables a los trabajos con riesgo de exposici�n al amianto".', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_80.07.pdf">circular</a></p>', '2007-07-25', NULL, '80', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-11-17 22:39:03', 0);
INSERT INTO `circular` VALUES (816, 'Proyecto de Real Decreto "Plan General de Contabilidad de Peque�as y Medianas Empresas".', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_81.07.pdf">circular</a></p>', '2007-07-25', NULL, '81', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-11-17 22:39:26', 0);
INSERT INTO `circular` VALUES (817, 'Borrador de Orden por la que se establece la entrega a las empresas de botiquines como material de primeros auxilios en caso de accidente de trabajo, como parte de la acci�n protectora del Sistema de Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_82.07.pdf">circular</a></p>', '2007-07-26', '0000-00-00', '82', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (818, 'Incidencia en la recaudaci�n de abril 2007.- Asignaci�n de importes de cobros y compensaciones a Mutuas por IT de contingencias comunes. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_83.07.pdf">circular</a></p>', '2007-07-26', '0000-00-00', '83', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (819, 'Temas tratados en la reuni�n celebrada con la Subdirecci�n General de Proceso de Datos del MTAS el d�a 10 de julio de 2007. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_84.07.pdf">circular</a></p>', '2007-07-26', '0000-00-00', '84', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (820, 'Borrador del "Plan de Acci�n para el impulso y la ejecuci�n de la Estrategia Espa�ola de Seguridad y Salud en el Trabajo (2007-2012)". ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_85.07.pdf">circular</a></p>', '2007-07-27', NULL, '85', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-11-17 22:40:16', 0);
INSERT INTO `circular` VALUES (821, 'Petici�n de informe de AMAT sobre el Proyecto de Orden por la que se establece la entrega a las empresas de botiquines como material de primeros auxilios en caso de accidente de trabajo, como parte de la acci�n protectora del Sistema de Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/julio/circular_86.07.pdf">circular</a></p>', '2007-07-30', '0000-00-00', '86', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (822, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes (Enero-Junio de 2007).', '<p><a href="/uploads/file/Circulares/2007/agosto/circular_87.07.01.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/agosto/circular_87.07.02.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2007-08-06', NULL, '87', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:25:04', 0);
INSERT INTO `circular` VALUES (823, 'Evoluci�n de la Recaudaci�n y Deducciones por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Junio de 2007).', '<p><a href="/uploads/file/Circulares/2007/septiembre/circular_88.07.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/septiembre/circular_88.07.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>', '2007-09-20', NULL, '88', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:26:10', 0);
INSERT INTO `circular` VALUES (824, 'Temas tratados por la Comisi�n de Recursos de AMAT, en su reuni�n del 18 de septiembre de 2007.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_89.07.pdf">circular</a></p>', '2007-10-01', '0000-00-00', '89', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (825, 'Proyecto de Presupuestos Generales del Estado para el a�o 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_90.07.pdf">circular</a></p>', '2007-10-01', '0000-00-00', '90', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (826, 'Denuncia del Convenio Colectivo por los Sindicatos CC.OO y UGT.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_91.07.pdf">circular</a></p>', '2007-10-04', '0000-00-00', '91', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (827, 'Revisi�n del Convenio-Marco de Cooperaci�n para la emisi�n de informes y pr�ctica de pruebas m�dicas y exploraciones complementarias para la valoraci�n, revisi�n y calificaci�n de incapacidades.', '<p><a href="/uploads/file/Circulares/2007/octubre/circular_92.07.01.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/octubre/circular_92.07.02.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>', '2007-10-05', NULL, '92', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:28:24', 0);
INSERT INTO `circular` VALUES (828, 'Temas tratados en la reuni�n mantenida por AMAT con la Subdirecci�n General de Inscripci�n Afiliaci�n y Recaudaci�n de la Tesorer�a General de la Seguridad Social.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_93.07.pdf">circular</a></p>', '2007-10-09', '0000-00-00', '93', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (829, 'Diferencias entre el texto, publicado en el BOE, de la Orden por la que se establece el contenido a las empresas de botiquines con material de primeros auxilios en caso de accidente de trabajo, como parte de la acci�n protectora de la Seguridad Social y el Borrador de esa norma.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_94.07.pdf">circular</a></p>', '2007-10-11', '0000-00-00', '94', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (830, 'Interpretaci�n del Convenio Colectivo.- Contestaci�n a las consultas n�s. 73 a 76.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_95.07.pdf">circular</a></p>', '2007-10-17', '0000-00-00', '95', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (831, 'Intervenci�n del Secretario de Estado de la Seguridad Social en la Comisi�n de Presupuestos del Congreso.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_96.07.pdf">circular</a></p>', '2007-10-17', '0000-00-00', '96', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (832, 'Nuevo dise�o de formato del registro de afiliaci�n con motivo de la creaci�n del Sistema Especial para Trabajadores por Cuenta Propia Agrarios. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_97.07.pdf">circular</a></p>', '2007-10-23', '0000-00-00', '97', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (833, 'Proyecto de Orden por la que se establecen las condiciones m�nimas para el desarrollo de las actividades de las Mutuas en su �mbito de actuaci�n.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_98.07.pdf">circular</a></p>', '2007-10-24', '0000-00-00', '98', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (834, 'Proyecto de Orden por la que se regula la contraprestaci�n a satisfacer por las Mutuas por los servicios de administraci�n complementaria.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_99.07.pdf">circular</a></p>', '2007-10-30', '0000-00-00', '99', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (835, 'Publicaci�n en el BOE de la Ley de Contratos del Sector P�blico y entrada en vigor. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/octubre/circular_100.07.pdf">circular</a></p>', '2007-10-31', '0000-00-00', '100', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (836, 'Anotaci�n de cambios de clave de Mutua de Trabajadores del REA cuenta propia.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_101.07.pdf">circular</a></p>', '2007-10-31', NULL, '101', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:35:30', 0);
INSERT INTO `circular` VALUES (837, 'Transacci�n ATK 43.- Intercambio de ficheros entre Tesorer�a y Mutuas.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_102.07.pdf">circular</a></p>', '2007-10-31', NULL, '102', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:34:26', 0);
INSERT INTO `circular` VALUES (838, 'Gu�a m�dica para la valoraci�n de los riesgos profesionales a efectos de la prestaci�n de riesgo durante el embarazo y riesgo en la lactancia.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_103.07.pdf">circular</a></p>', '2007-11-02', '0000-00-00', '103', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (839, 'Evoluci�n de la Afiliaci�n de Empresas y Trabajadores por Contingencias Profesionales y por Contingencias Comunes (Enero-Septiembre de 2007).', '<p><a href="/uploads/file/Circulares/2007/noviembre/circular_104.07.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/noviembre/circular_104.07.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>', '2007-11-05', NULL, '104', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:37:17', 0);
INSERT INTO `circular` VALUES (840, 'Avance Estad�stico de Accidentes de Trabajo. (Primer semestre de 2007).', '<p><a href="/uploads/file/Circulares/2007/noviembre/circular_105.07.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/noviembre/circular_105.07.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>', '2007-11-05', NULL, '105', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:38:56', 0);
INSERT INTO `circular` VALUES (841, 'Proyecto de Orden por la que se modifica la Orden de 24 de septiembre de 1970, por la que se dictan normas para la aplicaci�n y desarrollo del R�gimen Especial de la Seguridad Social de los Trabajadores por Cuenta Propia o Aut�nomos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_106.07.pdf">circular</a></p>', '2007-11-07', '0000-00-00', '106', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (842, 'Proyecto de Real Decreto sobre revalorizaci�n de las pensiones del Sistema de la Seguridad Social y de otras prestaciones sociales p�blicas para el ejercicio 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_107.07.pdf">circular</a></p>', '2007-11-07', '0000-00-00', '107', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (843, 'Subsanaci�n por Tesorer�a de la incidencia en la recaudaci�n de abril 2007: Asignaci�n de importes de cobros y compensaciones a Mutuas por IT de contingencias comunes.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_108.07.pdf">circular</a></p>', '2007-11-07', '0000-00-00', '108', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (844, 'Borrador de Gu�a B�sica y General de Orientaci�n de las Actividades de Vigilancia de la Salud de los Trabajadores.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_110.07.pdf">circular</a></p>', '2007-11-12', '0000-00-00', '110', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (845, '"Proyecto de Orden por la que se regulan las operaciones de cierre del ejercicio 2007"', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_111.07.pdf">circular</a></p>', '2007-11-22', NULL, '111', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-11-17 22:50:37', 0);
INSERT INTO `circular` VALUES (846, 'Avance Estad�stico de Accidentes de Trabajo. (Enero-Septiembre de 2007)', '<p><a href="/uploads/file/Circulares/2007/noviembre/circular_112.07.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/noviembre/circular_112.07.2.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p>&nbsp;</p>', '2007-11-22', NULL, '112', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:42:46', 0);
INSERT INTO `circular` VALUES (847, 'Temas tratados en la reuni�n mantenida por AMAT con la Subdirecci�n General de Inscripci�n Afiliaci�n y Recaudaci�n de la Tesorer�a General de la Seguridad Social. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_113.07.pdf">circular</a></p>', '2007-11-22', '0000-00-00', '113', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (848, 'Plazo para remisi�n a Tesorer�a del fichero de rechazados por no tener solicitado el cese con la Mutua actual (ATK43). ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_114.07.pdf">circular</a></p>', '2007-11-28', '0000-00-00', '114', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (849, 'Pago de Cuotas correspondientes a la modificaci�n del Presupuesto Ordinario de Gastos de AMAT para el Ejercicio 2007.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_115.07.pdf">circular</a></p>', '2007-12-05', '0000-00-00', '115', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (850, 'Publicaci�n en el BOE de la Ley 40/2007, de 4 de diciembre, de medidas en materia de Seguridad Social. ', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_116.07.pdf">circular</a></p>', '2007-12-05', '0000-00-00', '116', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (851, 'Proyecto de Orden de por la que se desarrollan las normas de cotizaci�n a la Seguridad Social para el a�o 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_117.07.pdf">circular</a></p>', '2007-12-05', '0000-00-00', '117', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (852, 'Modificaci�n del Reglamento de Colaboraci�n a trav�s del Proyecto de Real Decreto sobre revalorizaci�n de las pensiones del Sistema de la Seguridad Social y de otras prestaciones sociales p�blicas para el ejercicio 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_118.07.pdf">circular</a></p>', '2007-12-10', '0000-00-00', '118', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (853, 'Informe presentado por AMAT en relaci�n con el Proyecto de Orden por la que se regulan las operaciones de cierre del ejercicio 2007.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_119.07.pdf">circular</a></p>', '2007-12-12', '0000-00-00', '119', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (854, 'Cobertura de IT trabajadores aut�nomos.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_120.07.pdf">circular</a></p>', '2007-12-12', '0000-00-00', '120', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (855, 'Suscripci�n del Convenio Marco de Cooperaci�n para la emisi�n de informes y pr�cticas de pruebas m�dicas.', '<p><a href="/uploads/file/Circulares/2007/diciembre/circular_121.07.1.pdf">Enlace con documentaci&oacute;n adjunta (Archivo PDF)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/diciembre/circular_121.07.3.xls">Enlace con documentaci&oacute;n adjunta (Archivo XLS)</a></p>\r\n<p><a href="/uploads/file/Circulares/2007/diciembre/circular_121.07.2.doc">Enlace con documentaci&oacute;n adjunta (Archivo DOC)</a></p>', '2007-12-14', NULL, '121', NULL, NULL, NULL, '0000-00-00 00:00:00', '2010-02-01 13:48:04', 0);
INSERT INTO `circular` VALUES (856, 'Evoluci�n de la Recaudaci�n y Deducciones por Contingencias Profesionales y por Contingencias Comunes del periodo (Enero-Septiembre de 2007).', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_122.07.1.pdf">circular</a></p>', '2007-12-17', NULL, '122', NULL, NULL, NULL, '0000-00-00 00:00:00', '2009-11-17 21:48:43', 0);
INSERT INTO `circular` VALUES (857, 'Texto y Memoria justificativa del Proyecto de Disposici�n Final por la que se modifica el Real Decreto 39/1997 de 17 de Enero por el que se aprueba el reglamento de los Servicios de Prevenci�n.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_123.07.pdf">circular</a></p>', '2007-12-17', '0000-00-00', '123', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (858, 'Nueva funcionalidad en la transacci�n ATG62.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_124.07.pdf">circular</a></p>', '2007-12-18', '0000-00-00', '124', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (859, 'Informe presentado por AMAT en relaci�n al Proyecto de Orden de por la que se desarrollan las normas de cotizaci�n a la Seguridad Social para el a�o 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_125.07.pdf">circular</a></p>', '2007-12-19', '0000-00-00', '125', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (860, 'Informe sobre la Disposici�n Adicional Octava del Proyecto de Real Decreto sobre revalorizaci�n de las pensiones del Sistema de la Seguridad Social, en relaci�n a la modificaci�n del art�culo 14.2 del Reglamento sobre Colaboraci�n.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_126.07.pdf">circular</a></p>', '2007-12-19', '0000-00-00', '126', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (861, 'Pr�rroga del Acuerdo Interconfederal para la Negociaci�n Colectiva.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_127.07.pdf">circular</a></p>', '2007-12-19', '0000-00-00', '127', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (862, 'Puesta al cobro de la aportaci�n para la Unidad de Atenci�n Telef�nica al Usuario para la transmisi�n de los Partes M�dicos de I.T.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_128.07.pdf">circular</a></p>', '2007-12-21', '0000-00-00', '128', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (863, 'Novedades normativas introducidas por la Ley 40/2007.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_129.07.pdf">circular</a></p>', '2007-12-26', '0000-00-00', '129', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (864, 'Interpretaci�n del Convenio Colectivo.- Contestaci�n a las consultas n�s. 77 a 79.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_130.07.pdf">circular</a></p>', '2007-12-26', '0000-00-00', '130', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (865, 'Nueva transacci�n para consulta de bases de cotizaci�n de contingencias comunes (RDT 53).', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_131.07.pdf">circular</a></p>', '2007-12-27', '0000-00-00', '131', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (866, 'Relaci�n de circulares elaboradas por AMAT en 2007.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/diciembre/circular_132.07.pdf">circular</a></p>', '2007-12-31', '0000-00-00', '132', NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
INSERT INTO `circular` VALUES (867, 'prueba de icox', NULL, '2009-11-16', '2009-11-17', '78', '5721e462c3f2ab27acc7c2946810227b64bf5c16.doc', NULL, NULL, '2009-11-16 19:42:05', '2009-11-16 19:44:10', 1);
INSERT INTO `circular` VALUES (868, 'prueba de icosx', '<p>prueba de icox</p>', '2009-11-17', '2009-11-18', '77', '45c562081b9862f5c18f6db9b8b080e51c60442d.doc', NULL, NULL, '2009-11-16 19:45:34', '2009-11-16 19:45:54', 1);
INSERT INTO `circular` VALUES (869, 'Puesta a disposici�n de las Mutuas del Fichero de trabajadores del RETA que han solicitado el cambio de entidad de IT para el a�o 2008.', '<p>&nbsp;<a href="/uploads/file/Circulares/2007/noviembre/circular_109.07.pdf">circular</a></p>', '2007-11-08', NULL, '109', NULL, NULL, NULL, '2009-11-17 22:53:50', '2009-11-17 22:55:50', 0);
INSERT INTO `circular` VALUES (870, 'Nuevla lista de Enfermedades profesionales de la Organizaci�n Internacional del Trabajo.', '<p><a href="/uploads/file/Circulares/2009/noviembre/circular_88.09.pdf">Enlace con documentaci&oacute;n adjunta</a></p>', '2009-11-17', NULL, '93', 'd9ef4d5b86f8c3da3f108b5a895500a9ffdff694.pdf', NULL, NULL, '2010-02-03 12:55:03', '2010-02-03 12:57:18', 1);
INSERT INTO `circular` VALUES (871, 'Cualquier c', '<div class="noticias nuevodetalle" style="padding-top: 20px;"><a class="nottit">Titulo</a><br />\r\n<p class="notentrada" style="font-weight: bold;">Entradilla</p>\r\n<p style="border-bottom: 1px dotted; margin: 10px 0px; color: rgb(204, 204, 204);">&nbsp;</p>\r\n<p>Desccripcion</p>\r\n<div class="clear">&nbsp;</div>\r\n</div>', '2009-11-17', NULL, '93', NULL, NULL, NULL, '2010-02-03 12:57:50', '2010-02-03 12:59:50', 1);
INSERT INTO `circular` VALUES (872, 'Nueva lista de Enfermedades profesinales de la Organizaci�n Internacional del Trabajo.', '<p>Enlace con documentaci&oacute;n adjunta</p>\r\n<br />', '2009-11-17', NULL, '93', NULL, NULL, NULL, '2010-02-03 13:21:58', '2010-02-03 13:21:58', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `circular_cat_tema`
#

CREATE TABLE `circular_cat_tema` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(100) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

#
# Volcar la base de datos para la tabla `circular_cat_tema`
#

INSERT INTO `circular_cat_tema` VALUES (1, 'ertertretretret 2', '2009-10-22 22:01:08', '2009-11-17 21:18:10', 1);
INSERT INTO `circular_cat_tema` VALUES (2, 'Principal 1', '2009-10-29 21:51:58', '2009-11-17 21:18:05', 1);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `circular_sub_tema`
#

CREATE TABLE `circular_sub_tema` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(100) default NULL,
  `circular_cat_tema_id` bigint(20) NOT NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `circular_cat_tema_id_idx` (`circular_cat_tema_id`),
  CONSTRAINT `circular_sub_tema_ibfk_1` FOREIGN KEY (`circular_cat_tema_id`) REFERENCES `circular_cat_tema` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

#
# Volcar la base de datos para la tabla `circular_sub_tema`
#

INSERT INTO `circular_sub_tema` VALUES (1, 'ertertertretret', 1, '2009-10-22 22:01:19', '2009-10-29 22:00:38', 1);
INSERT INTO `circular_sub_tema` VALUES (2, 'Secundaria', 2, '2009-10-29 21:56:52', '2009-10-29 21:56:52', 0);
INSERT INTO `circular_sub_tema` VALUES (3, 'secundaria 2', 2, '2009-10-29 21:58:49', '2009-10-29 21:58:49', 0);
INSERT INTO `circular_sub_tema` VALUES (4, 'Terciaria', 1, '2009-10-29 21:59:14', '2009-11-17 21:17:54', 1);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `comunicado`
#

CREATE TABLE `comunicado` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `detalle` longtext,
  `en_intranet` tinyint(1) default NULL,
  `enviado` tinyint(1) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

#
# Volcar la base de datos para la tabla `comunicado`
#

INSERT INTO `comunicado` VALUES (1, 'yrtyrty', '<p>ryrtyrtyrtyrtyrtyrtyrty</p>', 0, 1, '2009-10-29 19:22:25', '2009-10-30 09:40:37', 0);
INSERT INTO `comunicado` VALUES (2, 'Prueba de circular', '<p style="text-align: right"><img height="135" width="900" alt="" src="/uploads/image/Dibujo.jpg" /></p><div align="right"><span style="font-family: Arial">&nbsp;</span></div><div style="line-height: normal; text-align: right">&nbsp;<span style="font-family: Arial">Madrid, 16 de Octubre de 2009</span></div><div>&nbsp;</div><div>&nbsp;</div><div>&nbsp;</div><div style="margin-left: 160px"><span style="font-family: Arial; letter-spacing: -0.15pt">CIRCULAR N&ordm;&nbsp;83/09</span></div><div style="margin-left: 160px">&nbsp;</div><div style="margin-left: 160px; text-align: justify">&nbsp;</div><div style="margin-left: 160px; text-align: justify"><b>&nbsp;</b></div><div style="margin-left: 160px; text-align: justify"><b><span style="font-family: Arial; letter-spacing: -0.15pt">A LA ATENCI&Oacute;N DEL SR. DIRECTOR</span></b></div><div style="margin: 0cm 0cm 0pt 240px; text-indent: -21.3pt; text-align: justify">&nbsp;</div><div style="margin-left: 160px"><b><u><span style="font-family: Arial; letter-spacing: -0.15pt">Ref&ordf;.:&nbsp;</span></u></b><b><u><span style="font-family: Arial">Proyecto de Real Decreto por el que se regula el establecimiento de un sistema de incentivos a las empresas que contribuyan eficazmente y de manera contrastable a la reducci&oacute;n y a la prevenci&oacute;n de la siniestralidad laboral</span></u></b><b><u><span style="color: black; font-family: Arial">.</span></u></b></div><div style="margin-left: 160px; text-align: justify">&nbsp;</div><div style="margin-left: 160px"><span style="font-family: Arial">Adjunto acompa&ntilde;amos texto y memoria explicativa del <i>&ldquo;Proyecto de Real Decreto por el que se regula el establecimiento de un sistema de incentivos a las empresas que contribuyan eficazmente y de manera contrastable a la reducci&oacute;n y a la prevenci&oacute;n de la siniestralidad laboral&rdquo;</i>, que nos ha sido remitido por la Secretar&iacute;a de Estado de la Seguridad Social, a efectos de que, conforme al art&iacute;culo 24.1 c) de la Ley 50/1997, de 27 de noviembre, del Gobierno, por esta Asociaci&oacute;n se emita el correspondiente informe.</span></div><div style="margin-left: 160px">&nbsp;</div><div style="margin-left: 160px"><font face="Arial">A tal fin, y teniendo en cuenta el plazo concedido, le agradecer&iacute;amos nos hiciera llegar las observaciones que considere oportunas antes del pr&oacute;ximo d&iacute;a 26 del corriente mes de octubre<span style="color: black">.</span></font></div><div style="margin-left: 160px">&nbsp;</div><div style="margin-left: 160px"><span style="color: black; font-family: Arial">Atentamente,</span></div><div style="margin-left: 160px; text-indent: 35.4pt">&nbsp;</div><div style="margin-left: 160px; text-indent: 35.4pt">&nbsp;</div><div style="margin: 0cm 0cm 0pt 280px; text-indent: 36pt"><span style="color: black"><font face="Arial">Firmado por Enrique Valenzuela de Quinta</font></span></div><div style="margin: 0cm 0cm 0pt 360px; text-indent: 36pt"><span style="color: black"><font face="Arial">Director Gerente</font></span></div><div style="margin-left: 160px; line-height: normal"><b>&nbsp;</b></div><div style="margin-left: 160px; line-height: normal"><b>&nbsp;</b></div><div style="margin-left: 160px; line-height: normal"><b>&nbsp;</b></div><div style="margin-left: 160px; line-height: normal">&nbsp;</div><div style="margin-left: 160px; line-height: normal"><b>&nbsp;</b></div><div style="margin-left: 160px"><b><span style="font-family: Arial">R/P.P.Sanz</span></b></div><div style="margin-left: 160px">&nbsp;</div><div style="margin-left: 160px"><b><span style="font-family: Arial"><div align="center"><span style="font-size: 8pt">Asociaci&oacute;n profesional de la Ley 19/1977, N&ordm; de Dep&oacute;sito 3.604 &ndash; C.I.F. G-78/383767</span></div></span></b></div><p>&nbsp;</p>', 0, 1, '2009-10-30 10:15:36', '2009-10-30 10:21:05', 0);
INSERT INTO `comunicado` VALUES (3, 'Prueba de Circular 2', '<p>&nbsp;</p>\r\n<p style="text-align: right;"><img height="135" width="900" src="http://www.intranet.amat.es/uploads/image/Dibujo.jpg" alt="" /></p>\r\n<div align="right">&nbsp;</div>\r\n<div style="line-height: normal;">&nbsp;</div>\r\n<div align="right">Madrid, 16 de Octubre de 2009</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div style="margin-left: 160px;"><span style="letter-spacing: -0.15pt;">CIRCULAR N&ordm;&nbsp;83/09</span></div>\r\n<div style="margin-left: 160px; text-align: justify;">&nbsp;</div>\r\n<div style="margin-left: 160px; text-align: justify;">&nbsp;</div>\r\n<div style="margin-left: 160px; text-align: justify;"><b>&nbsp;</b></div>\r\n<div style="margin-left: 160px; text-align: justify;"><b><span style="letter-spacing: -0.15pt;">A LA ATENCI&Oacute;N DEL SR. DIRECTOR</span></b></div>\r\n<div style="margin: 0cm 0cm 0pt 240px; text-indent: -21.3pt; text-align: justify;">&nbsp;</div>\r\n<div style="margin-left: 160px;"><b><u><span style="letter-spacing: -0.15pt;">Ref&ordf;.:&nbsp;</span></u></b><b><u>Proyecto de Real Decreto por el que se regula el establecimiento de un sistema de incentivos a las empresas que contribuyan eficazmente y de manera contrastable a la reducci&oacute;n y a la prevenci&oacute;n de la siniestralidad laboral</u></b><b><u><span style="color: black;">.</span></u></b></div>\r\n<div style="margin-left: 160px; text-align: justify;">&nbsp;</div>\r\n<div style="margin-left: 160px;">Adjunto acompa&ntilde;amos texto y memoria explicativa del <i>&ldquo;Proyecto de Real Decreto por el que se regula el establecimiento de un sistema de incentivos a las empresas que contribuyan eficazmente y de manera contrastable a la reducci&oacute;n y a la prevenci&oacute;n de la siniestralidad laboral&rdquo;</i>, que nos ha sido remitido por la Secretar&iacute;a de Estado de la Seguridad Social, a efectos de que, conforme al art&iacute;culo 24.1 c) de la Ley 50/1997, de 27 de noviembre, del Gobierno, por esta Asociaci&oacute;n se emita el correspondiente informe.</div>\r\n<div style="margin-left: 160px;">&nbsp;</div>\r\n<div style="margin-left: 160px;">A tal fin, y teniendo en cuenta el plazo concedido, le agradecer&iacute;amos nos hiciera llegar las observaciones que considere oportunas antes del pr&oacute;ximo d&iacute;a 26 del corriente mes de octubre<span style="color: black;">.</span></div>\r\n<div style="margin-left: 160px;">&nbsp;</div>\r\n<div style="margin-left: 160px;"><span style="color: black;">Atentamente,</span></div>\r\n<div style="margin-left: 160px; text-indent: 35.4pt;">&nbsp;</div>\r\n<div style="margin-left: 160px; text-indent: 35.4pt;">&nbsp;</div>\r\n<div style="margin: 0cm 0cm 0pt 280px; text-indent: 36pt;"><span style="color: black;">Firmado por Enrique Valenzuela de Quinta</span></div>\r\n<div style="margin: 0cm 0cm 0pt 360px; text-indent: 36pt;"><span style="color: black;">Director Gerente</span></div>\r\n<div style="margin-left: 160px; line-height: normal;"><b>&nbsp;</b></div>\r\n<div style="margin-left: 160px; line-height: normal;"><b>&nbsp;</b></div>\r\n<div style="margin-left: 160px; line-height: normal;"><b>&nbsp;</b></div>\r\n<div style="margin-left: 160px; line-height: normal;"><b>&nbsp;</b></div>\r\n<div style="margin-left: 160px;"><b>R/P.P.Sanz</b></div>\r\n<div style="margin-left: 160px;">&nbsp;</div>\r\n<div style="margin-left: 160px;"><b>\r\n<div style="text-align: center;"><span style="font-size: 8pt; font-family: \'Times New Roman\';">Asociaci&oacute;n profesional de la Ley 19/1977, N&ordm; de Dep&oacute;sito 3.604 &ndash; C.I.F. G-78/383767</span></div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n<div style="text-align: right;"><span style="font-size: 8pt; font-family: \'Times New Roman\';"><a href="http://www.intranet.amat.es/uploads/file/Modeloparacabeceraypie.pdf">Descargar Circular</a></span></div>\r\n</b></div>\r\n<p>&nbsp;</p>', 0, 1, '2009-10-30 10:25:27', '2009-10-30 10:46:48', 0);
INSERT INTO `comunicado` VALUES (4, 'Prueba 3', '<p>aaa</p>', 0, 1, '2009-10-30 10:39:01', '2009-10-30 10:44:46', 0);
INSERT INTO `comunicado` VALUES (5, 'aa', '<p>aa</p>', 0, 0, '2009-10-30 10:44:55', '2009-10-30 10:44:55', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `consejo_territorial`
#

CREATE TABLE `consejo_territorial` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `detalle` longtext,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

#
# Volcar la base de datos para la tabla `consejo_territorial`
#

INSERT INTO `consejo_territorial` VALUES (1, 'Andaluc�a', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-10-20 17:49:34', '2009-12-22 08:53:19', 0);
INSERT INTO `consejo_territorial` VALUES (2, 'Arag�n', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-10-20 17:49:34', '2009-12-22 08:53:38', 0);
INSERT INTO `consejo_territorial` VALUES (3, 'Asturias', '<p>&nbsp;</p><p>&nbsp;</p>', '2009-10-20 17:49:34', '2009-12-22 08:53:56', 0);
INSERT INTO `consejo_territorial` VALUES (4, 'Baleares', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-10-20 17:49:34', '2009-12-22 10:03:32', 0);
INSERT INTO `consejo_territorial` VALUES (5, 'Pa�s Vasco', '<p>&nbsp;</p><p>&nbsp;</p>', '2009-12-22 08:51:01', '2009-12-22 08:51:51', 0);
INSERT INTO `consejo_territorial` VALUES (6, 'Canarias', '<p><a href="#"></a></p>', '2009-12-22 10:03:57', '2009-12-22 10:03:57', 0);
INSERT INTO `consejo_territorial` VALUES (7, 'Cantabria', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-12-22 10:04:17', '2009-12-22 10:04:31', 0);
INSERT INTO `consejo_territorial` VALUES (8, 'Castilla y Le�n', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-12-22 10:04:51', '2009-12-22 10:04:51', 0);
INSERT INTO `consejo_territorial` VALUES (9, 'Castilla la Mancha', '<p>&nbsp;</p><p>&nbsp;</p>', '2009-12-22 10:05:09', '2009-12-22 10:05:09', 0);
INSERT INTO `consejo_territorial` VALUES (10, 'Catalu�a', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-12-22 10:05:37', '2009-12-22 10:05:37', 0);
INSERT INTO `consejo_territorial` VALUES (11, 'Extremadura', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-12-22 10:06:01', '2009-12-22 10:06:01', 0);
INSERT INTO `consejo_territorial` VALUES (12, 'Galicia', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-12-22 10:06:19', '2009-12-22 10:06:42', 0);
INSERT INTO `consejo_territorial` VALUES (13, 'La Rioja', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-12-22 10:06:59', '2009-12-22 10:06:59', 0);
INSERT INTO `consejo_territorial` VALUES (14, 'Madrid', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-12-22 10:07:15', '2009-12-22 10:07:15', 0);
INSERT INTO `consejo_territorial` VALUES (15, 'Murcia', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-12-22 10:07:32', '2009-12-22 10:07:32', 0);
INSERT INTO `consejo_territorial` VALUES (16, 'Navarra', '<p>&nbsp;</p><p><a href="#"></a></p><p>&nbsp;</p>', '2009-12-22 10:07:49', '2009-12-22 10:07:49', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `contenido`
#

CREATE TABLE `contenido` (
  `id` bigint(20) NOT NULL auto_increment,
  `titulo` varchar(100) default NULL,
  `contenido` longtext,
  `permalink` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

#
# Volcar la base de datos para la tabla `contenido`
#


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `contenido_notificacion`
#

CREATE TABLE `contenido_notificacion` (
  `id` bigint(20) NOT NULL auto_increment,
  `titulo` varchar(255) default NULL,
  `mensaje` varchar(255) default NULL,
  `accion` varchar(255) default NULL,
  `entidad` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

#
# Volcar la base de datos para la tabla `contenido_notificacion`
#

INSERT INTO `contenido_notificacion` VALUES (1, 'Creaci�n de evento', NULL, 'creacion', 'Evento', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `contenido_notificacion` VALUES (2, 'Modificaci�n de evento', NULL, 'modificacion', 'Evento', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `contenido_notificacion` VALUES (3, 'Creaci�n de noticia', NULL, 'creacion', 'Noticia', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `contenido_notificacion` VALUES (4, 'Convocaci�n de Asamblea', NULL, 'lectura', 'Asamblea', '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `contenido_notificacion` VALUES (5, 'Creaci�n de Documento', NULL, 'creacion', 'Grupo', NULL, NULL, 0);
INSERT INTO `contenido_notificacion` VALUES (6, 'Creaci�n de Documento', NULL, 'creacion', 'Consejo', NULL, NULL, 0);
INSERT INTO `contenido_notificacion` VALUES (7, 'Creac�on de Documento ', NULL, 'creacion', 'Organismo', NULL, NULL, 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `convocatoria`
#

CREATE TABLE `convocatoria` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(100) default NULL,
  `detalle` longtext,
  `asamblea_id` bigint(20) default NULL,
  `owner_id` bigint(20) default NULL,
  `usuario_id` bigint(20) default NULL,
  `estado` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `asamblea_id_idx` (`asamblea_id`),
  KEY `usuario_id_idx` (`usuario_id`),
  CONSTRAINT `convocatoria_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `convocatoria_ibfk_2` FOREIGN KEY (`asamblea_id`) REFERENCES `asamblea` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=latin1 AUTO_INCREMENT=110 ;

#
# Volcar la base de datos para la tabla `convocatoria`
#

INSERT INTO `convocatoria` VALUES (44, NULL, NULL, 7, 3, 3, 'aceptada', '2009-11-12 19:15:22', '2009-11-12 19:15:22', 0);
INSERT INTO `convocatoria` VALUES (45, NULL, NULL, 7, 3, 4, 'pendiente', '2009-11-12 19:15:22', '2009-11-12 19:15:22', 0);
INSERT INTO `convocatoria` VALUES (46, NULL, NULL, 7, 3, 7, 'pendiente', '2009-11-12 19:15:22', '2009-11-12 19:15:22', 0);
INSERT INTO `convocatoria` VALUES (47, NULL, NULL, 7, 3, 8, 'pendiente', '2009-11-12 19:15:22', '2009-11-12 19:15:22', 0);
INSERT INTO `convocatoria` VALUES (48, NULL, NULL, 7, 3, 9, 'pendiente', '2009-11-12 19:15:22', '2009-11-12 19:15:22', 0);
INSERT INTO `convocatoria` VALUES (49, NULL, NULL, 7, 3, 11, 'pendiente', '2009-11-12 19:15:22', '2009-11-12 19:15:22', 0);
INSERT INTO `convocatoria` VALUES (50, NULL, NULL, 7, 3, 13, 'pendiente', '2009-11-12 19:15:22', '2009-11-12 19:15:22', 0);
INSERT INTO `convocatoria` VALUES (51, NULL, NULL, 7, 3, 14, 'pendiente', '2009-11-12 19:15:22', '2009-11-12 19:15:22', 0);
INSERT INTO `convocatoria` VALUES (52, NULL, NULL, 7, 3, 16, 'pendiente', '2009-11-12 19:15:22', '2009-11-12 19:15:22', 0);
INSERT INTO `convocatoria` VALUES (53, NULL, NULL, 9, 7, 4, 'pendiente', '2009-11-21 11:12:34', '2009-11-21 11:12:34', 0);
INSERT INTO `convocatoria` VALUES (54, NULL, NULL, 9, 7, 7, 'aceptada', '2009-11-21 11:12:34', '2009-11-21 11:12:34', 0);
INSERT INTO `convocatoria` VALUES (55, NULL, NULL, 9, 7, 8, 'pendiente', '2009-11-21 11:12:34', '2009-11-21 11:12:34', 0);
INSERT INTO `convocatoria` VALUES (56, NULL, NULL, 9, 7, 9, 'aceptada', '2009-11-21 11:12:34', '2009-11-21 11:19:40', 0);
INSERT INTO `convocatoria` VALUES (57, NULL, NULL, 9, 7, 13, 'pendiente', '2009-11-21 11:12:34', '2009-11-21 11:12:34', 0);
INSERT INTO `convocatoria` VALUES (58, NULL, NULL, 9, 7, 14, 'pendiente', '2009-11-21 11:12:35', '2009-11-21 11:12:35', 0);
INSERT INTO `convocatoria` VALUES (59, NULL, NULL, 9, 7, 16, 'pendiente', '2009-11-21 11:12:35', '2009-11-21 11:12:35', 0);
INSERT INTO `convocatoria` VALUES (60, NULL, NULL, 10, 7, 3, 'pendiente', '2009-12-29 10:10:38', '2009-12-29 10:10:38', 0);
INSERT INTO `convocatoria` VALUES (61, NULL, NULL, 10, 7, 6, 'pendiente', '2009-12-29 10:10:38', '2009-12-29 10:10:38', 0);
INSERT INTO `convocatoria` VALUES (62, NULL, NULL, 10, 7, 7, 'aceptada', '2009-12-29 10:10:38', '2009-12-29 10:10:38', 0);
INSERT INTO `convocatoria` VALUES (63, NULL, NULL, 10, 7, 9, 'aceptada', '2009-12-29 10:10:38', '2009-12-29 10:34:20', 0);
INSERT INTO `convocatoria` VALUES (64, NULL, NULL, 10, 7, 12, 'pendiente', '2009-12-29 10:10:38', '2009-12-29 10:10:38', 0);
INSERT INTO `convocatoria` VALUES (65, NULL, NULL, 10, 7, 15, 'pendiente', '2009-12-29 10:10:38', '2009-12-29 10:10:38', 0);
INSERT INTO `convocatoria` VALUES (66, NULL, NULL, 10, 7, 16, 'pendiente', '2009-12-29 10:10:39', '2009-12-29 10:10:39', 0);
INSERT INTO `convocatoria` VALUES (67, NULL, NULL, 11, 7, 3, 'pendiente', '2009-12-29 10:13:02', '2009-12-29 10:13:02', 0);
INSERT INTO `convocatoria` VALUES (68, NULL, NULL, 11, 7, 6, 'pendiente', '2009-12-29 10:13:02', '2009-12-29 10:13:02', 0);
INSERT INTO `convocatoria` VALUES (69, NULL, '', 11, 7, 7, 'aceptada', '2009-12-29 10:13:02', '2009-12-30 12:41:56', 0);
INSERT INTO `convocatoria` VALUES (70, NULL, NULL, 11, 7, 9, 'aceptada', '2009-12-29 10:13:02', '2009-12-29 10:33:49', 0);
INSERT INTO `convocatoria` VALUES (71, NULL, NULL, 11, 7, 12, 'pendiente', '2009-12-29 10:13:02', '2009-12-29 10:13:02', 0);
INSERT INTO `convocatoria` VALUES (72, NULL, NULL, 11, 7, 15, 'pendiente', '2009-12-29 10:13:02', '2009-12-29 10:13:02', 0);
INSERT INTO `convocatoria` VALUES (73, NULL, NULL, 11, 7, 16, 'pendiente', '2009-12-29 10:13:02', '2009-12-29 10:13:02', 0);
INSERT INTO `convocatoria` VALUES (74, NULL, NULL, 12, 7, 3, 'pendiente', '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `convocatoria` VALUES (75, NULL, NULL, 12, 7, 6, 'pendiente', '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `convocatoria` VALUES (76, NULL, NULL, 12, 7, 7, 'aceptada', '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `convocatoria` VALUES (77, NULL, NULL, 12, 7, 9, 'pendiente', '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `convocatoria` VALUES (78, NULL, NULL, 12, 7, 12, 'pendiente', '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `convocatoria` VALUES (79, NULL, NULL, 12, 7, 15, 'pendiente', '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `convocatoria` VALUES (80, NULL, NULL, 12, 7, 16, 'pendiente', '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `convocatoria` VALUES (81, NULL, NULL, 13, 7, 3, 'pendiente', '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `convocatoria` VALUES (82, NULL, NULL, 13, 7, 6, 'pendiente', '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `convocatoria` VALUES (83, NULL, NULL, 13, 7, 7, 'aceptada', '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `convocatoria` VALUES (84, NULL, NULL, 13, 7, 9, 'rechazada', '2009-12-29 10:43:42', '2009-12-29 10:45:59', 0);
INSERT INTO `convocatoria` VALUES (85, NULL, NULL, 13, 7, 12, 'pendiente', '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `convocatoria` VALUES (86, NULL, NULL, 13, 7, 15, 'pendiente', '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `convocatoria` VALUES (87, NULL, NULL, 13, 7, 16, 'pendiente', '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `convocatoria` VALUES (88, NULL, NULL, 14, 7, 3, 'pendiente', '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `convocatoria` VALUES (89, NULL, NULL, 14, 7, 6, 'pendiente', '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `convocatoria` VALUES (90, NULL, NULL, 14, 7, 7, 'aceptada', '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `convocatoria` VALUES (91, NULL, NULL, 14, 7, 9, 'pendiente', '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `convocatoria` VALUES (92, NULL, NULL, 14, 7, 12, 'pendiente', '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `convocatoria` VALUES (93, NULL, NULL, 14, 7, 14, 'pendiente', '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `convocatoria` VALUES (94, NULL, NULL, 14, 7, 15, 'pendiente', '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `convocatoria` VALUES (95, NULL, NULL, 14, 7, 16, 'pendiente', '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `convocatoria` VALUES (96, NULL, NULL, 15, 7, 3, 'pendiente', '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `convocatoria` VALUES (97, NULL, NULL, 15, 7, 6, 'pendiente', '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `convocatoria` VALUES (98, NULL, NULL, 15, 7, 9, 'pendiente', '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `convocatoria` VALUES (99, NULL, NULL, 15, 7, 12, 'pendiente', '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `convocatoria` VALUES (100, NULL, NULL, 15, 7, 14, 'pendiente', '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `convocatoria` VALUES (101, NULL, NULL, 15, 7, 15, 'pendiente', '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `convocatoria` VALUES (102, NULL, NULL, 15, 7, 16, 'pendiente', '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `convocatoria` VALUES (103, NULL, NULL, 16, 7, 3, 'pendiente', '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `convocatoria` VALUES (104, NULL, NULL, 16, 7, 4, 'pendiente', '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `convocatoria` VALUES (105, NULL, NULL, 16, 7, 7, 'aceptada', '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `convocatoria` VALUES (106, NULL, NULL, 16, 7, 9, 'pendiente', '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `convocatoria` VALUES (107, NULL, NULL, 16, 7, 14, 'pendiente', '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `convocatoria` VALUES (108, NULL, NULL, 16, 7, 16, 'pendiente', '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `convocatoria` VALUES (109, NULL, NULL, 17, 7, 11, 'pendiente', '2010-01-18 16:27:52', '2010-01-18 16:27:52', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `documentacion_consejo`
#

CREATE TABLE `documentacion_consejo` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `contenido` longtext,
  `fecha` date NOT NULL,
  `consejo_territorial_id` bigint(20) NOT NULL,
  `categoria_c_t_id` bigint(20) NOT NULL,
  `estado` varchar(255) default NULL,
  `owner_id` bigint(20) default NULL,
  `modificador_id` bigint(20) default NULL,
  `publicador_id` bigint(20) default NULL,
  `fecha_publicacion` date default NULL,
  `user_id_creador` bigint(20) default NULL,
  `user_id_modificado` bigint(20) default NULL,
  `user_id_publicado` bigint(20) default NULL,
  `fecha_publicado` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `consejo_territorial_id_idx` (`consejo_territorial_id`),
  KEY `categoria_c_t_id_idx` (`categoria_c_t_id`),
  CONSTRAINT `documentacion_consejo_ibfk_1` FOREIGN KEY (`consejo_territorial_id`) REFERENCES `consejo_territorial` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documentacion_consejo_ibfk_2` FOREIGN KEY (`categoria_c_t_id`) REFERENCES `categoria_c_t` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

#
# Volcar la base de datos para la tabla `documentacion_consejo`
#

INSERT INTO `documentacion_consejo` VALUES (1, 'Fase II - Acuerdos en Sevilla', '<p>Estos son los documentos</p>', '2009-11-07', 1, 2, 'publicado', 7, NULL, NULL, NULL, 7, NULL, NULL, NULL, '2009-11-07 18:40:04', '2009-11-07 18:40:04', 0);
INSERT INTO `documentacion_consejo` VALUES (2, 'Actas de Reuni�n', '<p>En este apartado se registran las Actas de Reuni&oacute;n, de aquellas reuniones No Gestionadas desde la intranet</p>', '2010-01-12', 14, 7, 'publicado', 1, NULL, NULL, NULL, 1, 1, NULL, NULL, '2010-01-12 10:52:31', '2010-01-12 10:53:40', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `documentacion_grupo`
#

CREATE TABLE `documentacion_grupo` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `contenido` longtext,
  `fecha` date NOT NULL,
  `grupo_trabajo_id` bigint(20) NOT NULL,
  `categoria_d_g_id` bigint(20) NOT NULL,
  `estado` varchar(255) default NULL,
  `owner_id` bigint(20) default NULL,
  `modificador_id` bigint(20) default NULL,
  `publicador_id` bigint(20) default NULL,
  `fecha_publicacion` date default NULL,
  `user_id_creador` bigint(20) default NULL,
  `user_id_modificado` bigint(20) default NULL,
  `user_id_publicado` bigint(20) default NULL,
  `fecha_publicado` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `grupo_trabajo_id_idx` (`grupo_trabajo_id`),
  KEY `categoria_d_g_id_idx` (`categoria_d_g_id`),
  CONSTRAINT `documentacion_grupo_ibfk_1` FOREIGN KEY (`grupo_trabajo_id`) REFERENCES `grupo_trabajo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documentacion_grupo_ibfk_2` FOREIGN KEY (`categoria_d_g_id`) REFERENCES `categoria_d_g` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

#
# Volcar la base de datos para la tabla `documentacion_grupo`
#

INSERT INTO `documentacion_grupo` VALUES (2, 'dfgdfgdfgdfgdfg', '<p>gdfgdfgdgdf dfg dfg dfgdf df dfgdfgdf gd df df g</p>', '2009-11-18', 3, 10, 'pendiente', 3, NULL, NULL, NULL, 3, 3, NULL, NULL, '2009-11-18 18:40:22', '2009-11-18 18:48:59', 1);
INSERT INTO `documentacion_grupo` VALUES (3, 'dfdsfdsfsdfsdf', '<p>sdfsdfdsfdsdfsdf sf sdf sdsdf sd sf sf sf sdfds</p>', '2009-11-18', 3, 10, 'pendiente', 3, NULL, NULL, NULL, 3, 3, NULL, NULL, '2009-11-18 18:47:01', '2009-11-18 18:48:55', 1);
INSERT INTO `documentacion_grupo` VALUES (4, 'edici�n', '<p>prueba de icox</p>', '2009-11-05', 3, 10, 'publicado', 3, NULL, NULL, NULL, 3, 7, NULL, NULL, '2009-11-25 19:29:23', '2009-12-18 11:43:57', 0);
INSERT INTO `documentacion_grupo` VALUES (5, 'prueba de icox ', '<p>prueba de icox</p>', '2010-01-14', 9, 10, 'pendiente', 7, NULL, NULL, NULL, 7, NULL, NULL, NULL, '2010-01-15 14:08:16', '2010-01-15 14:08:16', 0);
INSERT INTO `documentacion_grupo` VALUES (6, 'prueba de icox ', '<p>prueba de icox</p>', '2010-01-15', 9, 10, 'pendiente', 7, NULL, NULL, NULL, 7, NULL, NULL, NULL, '2010-01-15 14:11:11', '2010-01-15 14:11:11', 0);
INSERT INTO `documentacion_grupo` VALUES (7, 'Carpeta 1 (Mikel)', '<p>Documentos tipo</p>', '2010-01-18', 7, 10, 'publicado', 7, NULL, NULL, NULL, 7, NULL, NULL, NULL, '2010-01-18 12:39:46', '2010-01-18 12:39:46', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `documentacion_organismo`
#

CREATE TABLE `documentacion_organismo` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `contenido` longtext,
  `fecha` date NOT NULL,
  `categoria_organismo_id` bigint(20) default NULL,
  `subcategoria_organismo_id` bigint(20) default NULL,
  `organismo_id` bigint(20) default NULL,
  `estado` varchar(255) default NULL,
  `owner_id` bigint(20) default NULL,
  `modificador_id` bigint(20) default NULL,
  `publicador_id` bigint(20) default NULL,
  `fecha_publicacion` date default NULL,
  `user_id_creador` bigint(20) default NULL,
  `user_id_modificado` bigint(20) default NULL,
  `user_id_publicado` bigint(20) default NULL,
  `fecha_publicado` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `organismo_id_idx` (`organismo_id`),
  KEY `categoria_organismo_id_idx` (`categoria_organismo_id`),
  KEY `subcategoria_organismo_id_idx` (`subcategoria_organismo_id`),
  CONSTRAINT `documentacion_organismo_ibfk_1` FOREIGN KEY (`subcategoria_organismo_id`) REFERENCES `sub_categoria_organismo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documentacion_organismo_ibfk_2` FOREIGN KEY (`organismo_id`) REFERENCES `organismo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documentacion_organismo_ibfk_3` FOREIGN KEY (`categoria_organismo_id`) REFERENCES `categoria_organismo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

#
# Volcar la base de datos para la tabla `documentacion_organismo`
#


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `envio_comunicado`
#

CREATE TABLE `envio_comunicado` (
  `id` bigint(20) NOT NULL auto_increment,
  `comunicado_id` bigint(20) default NULL,
  `tipo_comunicado_id` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `comunicado_id_idx` (`comunicado_id`),
  KEY `tipo_comunicado_id_idx` (`tipo_comunicado_id`),
  CONSTRAINT `envio_comunicado_ibfk_1` FOREIGN KEY (`tipo_comunicado_id`) REFERENCES `tipo_comunicado` (`id`) ON DELETE CASCADE,
  CONSTRAINT `envio_comunicado_ibfk_2` FOREIGN KEY (`comunicado_id`) REFERENCES `comunicado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

#
# Volcar la base de datos para la tabla `envio_comunicado`
#

INSERT INTO `envio_comunicado` VALUES (1, 1, 2, '2009-10-30 09:40:37', '2009-10-30 09:40:37', 0);
INSERT INTO `envio_comunicado` VALUES (2, 3, 1, '2009-10-30 10:21:05', '2009-10-30 10:26:28', 0);
INSERT INTO `envio_comunicado` VALUES (3, 3, 1, '2009-10-30 10:42:43', '2009-10-30 10:42:43', 0);
INSERT INTO `envio_comunicado` VALUES (4, 4, 1, '2009-10-30 10:44:46', '2009-10-30 10:44:46', 0);
INSERT INTO `envio_comunicado` VALUES (5, 3, 1, '2009-10-30 10:46:48', '2009-10-30 10:46:48', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `evento`
#

CREATE TABLE `evento` (
  `id` bigint(20) NOT NULL auto_increment,
  `titulo` varchar(100) default NULL,
  `descripcion` longtext,
  `mas_info` longtext,
  `imagen` varchar(255) default NULL,
  `documento` varchar(255) default NULL,
  `fecha` date default NULL,
  `fecha_caducidad` date default NULL,
  `organizador` varchar(255) default NULL,
  `estado` varchar(255) default NULL,
  `ambito` varchar(255) default NULL,
  `owner_id` bigint(20) default NULL,
  `user_id_creador` bigint(20) default NULL,
  `user_id_modificado` bigint(20) default NULL,
  `user_id_publicado` bigint(20) default NULL,
  `fecha_publicado` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

#
# Volcar la base de datos para la tabla `evento`
#

INSERT INTO `evento` VALUES (5, 'Nuevas Jornadas de PCAE', '<p>Otro de los pilares de AMAT es su af&aacute;n de colaboraci&oacute;n  con otras asociaciones y organismos para la puesta en marcha de iniciativas reladicionadas con su &aacute;mbito de actuaci&oacute;n. Seguidamente se recogen las realizadas durante el 2008.   En este sentido el apoyo de AMAT en la puesta en marcha de el programa de Coordinaci&oacute;n de Actividades Empresariales para la Prevenci&oacute;n de Riesgos Laborales (PCAE) ha sido muy destacable. El PCAE es un canal de comunicaci&oacute;n com&uacute;n para empresarios gratuito, organizado, accesible, universal y &uacute;til puesto a disposici&oacute;n de los empresarios para ayudarles en la organizaci&oacute;n y gesti&oacute;n de la Prevenci&oacute;n de Riesgos laborales cuando concurran con otros empresarios o aut&oacute;nomos en un mismo Centro de Trabajo.</p>', NULL, '49bf5ae4a4674.jpg', '49bf5ae4a754a.pdf', '2009-03-13', NULL, '', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-03-17 09:10:12', NULL, 0);
INSERT INTO `evento` VALUES (8, 'JORNADA T�CNICA DEL REGLAMENTO DEL  REACH', '<p>ACTIVA MUTUA 2008 organiza el pr&oacute;ximo d&iacute;a 28 de abril, en el Hotel  Ciutat de Tarragona,una jornada gratuita bajo el nombre \\"Jornada T&eacute;cnica del Reglamento del REACH\\".</p>', NULL, '49d4b8a2cabf6.jpg', '49d4b8a342049.pdf', '2009-04-02', '2009-04-28', 'Activa Mutua 2008', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-04-02 15:07:46', NULL, 0);
INSERT INTO `evento` VALUES (10, 'XI Jornadas de la Asociaci�n Profesional del Cuerpo Superior de Letrados de la Administraci�n de la ', '', NULL, '49e4355ee49e1.jpg', '49e4355eee61f.pdf', '2009-04-14', '2009-05-28', '', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-04-14 09:03:58', NULL, 0);
INSERT INTO `evento` VALUES (11, 'Jornada en Oviedo ', '<p>Coordinaci&oacute;n de Actividades Empresariales en PRL. PCAE  Plaza de la Gesta s/n</p>', NULL, '49e45e8878ece.jpg', '49e45e888e674.pdf', '2009-04-14', '2009-05-13', 'CEOE', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-04-14 11:06:12', NULL, 0);
INSERT INTO `evento` VALUES (12, 'Jornada en Merida ', '<p>Coordinaci&oacute;n de Actividades Empresariales en PRL. PCAE Hotel Las Lomas, Avda Reina Sof&iacute;a 78</p>', NULL, '49e45d3cca833.jpg', '49e737a1681ff.pdf', '2009-04-14', '2009-04-22', '', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-04-14 11:54:04', NULL, 0);
INSERT INTO `evento` VALUES (13, 'Taller IT. Doctor vengo a por la baja', '<p>23 de mayo. Residencia de Investigadors.  C/ Del Carme, 41.  08001 Barcelona  Objetivos &middot;Conocer la normativa actual sobre el manejo de la IT. &middot;Adquirir conocimientos para orientar los casos concretos. &middot;Revisar los principales aspectos conflictivos desde el punto de vista de la legalidad en el control de la IT. &middot;Adquirir la capacidad para impartir formaci&oacute;n b&aacute;sica a otros m&eacute;dicos de familia.</p>', NULL, '49e4a09a392f7.jpg', '49e4a09a43ed4.pdf', '2009-04-14', '2009-05-23', 'AMAT y SEMFYC', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-04-14 16:41:30', NULL, 0);
INSERT INTO `evento` VALUES (14, 'Taller IT. Doctor vengo a por la baja', '<p>1 de diciembre.  Sede de la semFYC (Sociedad Espa&ntilde;ola de Medicina de Familia y Comunitaria). C/ Fuencarral, 18, 1&ordm; dcha.  28004 Madrid  Objetivos &middot;Conocer la normativa actual sobre el manejo de la IT. &middot;Adquirir conocimientos para orientar los casos concretos. &middot;Revisar los principales aspectos conflictivos desde el punto de vista de la legalidad en el control de la IT. &middot;Adquirir la capacidad para impartir formaci&oacute;n b&aacute;sica a otros m&eacute;dicos de familia.</p>', NULL, '49e4a0fa28d7e.jpg', '49e4a0fa33946.pdf', '2009-04-14', '2009-12-01', 'AMAT y SEMFYC', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-04-14 16:43:06', NULL, 0);
INSERT INTO `evento` VALUES (16, 'Jornada en Palma de Mallorca ', '<p>Coordinaci&oacute;n de Actividades Empresariales en PRL. PCAE C/ Arag&oacute;n 215, 2&ordm; (CAEB) 07008 Palma de Mallorca</p>', NULL, '49e70409b0caa.jpg', '49e70409c54c5.pdf', '2009-04-16', '2009-04-29', 'CEOE', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-04-16 12:10:17', NULL, 0);
INSERT INTO `evento` VALUES (18, 'Gesti�n del Absentismo', '', NULL, '49e708fb202b3.gif', '', '2009-04-16', '2009-04-16', '', 'pendiente', NULL, 1, NULL, NULL, NULL, NULL, '2009-04-16 12:31:23', NULL, 0);
INSERT INTO `evento` VALUES (19, 'Jornada en Pamplona ', '<p>Coordinaci&oacute;n de Actividades Empresariales en PRL. PCAE 27 de mayo de 2009 Lugar: Sede de la CEN C/ Doctor Huarte, 3</p>', NULL, '49f950edb77c9.jpg', '49f950edcc003.pdf', '2009-04-30', '2009-05-27', '', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-04-30 09:19:09', NULL, 0);
INSERT INTO `evento` VALUES (20, 'Jornada San Sebasti�n', '<p>Coordinaci&oacute;n de Actividades Empresariales en PRL. PCAE Lugar:   Edificio Central P&ordf; Mikeletegi, 53. Parque Tecnol&oacute;gico de Miram&oacute;n.</p>', NULL, '4a09458c323d5.jpg', '4a2f4d9b87bc2.pdf', '2009-05-12', '2009-06-15', '', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-05-12 11:46:52', NULL, 0);
INSERT INTO `evento` VALUES (21, 'Jornada en Valladolid', '<p>Coordinaci&oacute;n de Actividades Empresariales en PRL. PCAE  VALLADOLID 17 JUNIO 09 Sal&oacute;n de Actos Caja Duero Plaza de Zorrilla, 3 - Valladolid</p>', NULL, '4a153fa1397de.jpg', '4a153fa14ef8d.pdf', '2009-05-21', '2009-06-17', 'CEOE', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-05-21 13:48:49', NULL, 0);
INSERT INTO `evento` VALUES (22, 'Jornada en La Coru�a', '<p>Coordinaci&oacute;n de Actividades Empresariales en PRL. PCAE LA CORU&Ntilde;A 10 JUNIO 09 Confederaci&oacute;n de Empresarios de Galicia R&uacute;a de Villar, 54 - 15705 Santiago de Compostela (A Coru&ntilde;a)</p>', NULL, '4a153ff1c4327.jpg', '4a153ff1d9acc.pdf', '2009-05-21', '2009-06-10', '', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-05-21 13:50:09', NULL, 0);
INSERT INTO `evento` VALUES (25, 'Congreso Espa�ol de Medicina y Enfermer�a del Trabajo', '<p>Durante la celebraci&oacute;n de dicho congreso, el 2 de octubre en el  Hotel NH Central de Convenciones, tendr&aacute; lugar el Foro/Taller: El M&eacute;dico Especialista en Medicina del Trabajo y el Absentismo Laboral.</p>', NULL, '', '', '2009-06-18', '2009-10-02', '', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-06-18 12:20:34', NULL, 0);
INSERT INTO `evento` VALUES (26, 'UMIVALE CELEBRA EN VALENCIA UNA JORNADA DEDICADA A ANALIZAR EL ABSENTISMO LABORAL. CAUSAS Y SOLUCION', '<p>Martes 23 de junio  Fundaci�n Universidad- Empresa de Valencia Sal�n de Actos del ADEIT Plaza Virgen de la Paz, 3 46001 Valencia</p>', '<p>edici&oacute;n</p>', '', '4a3a4984ea815.pdf', '2009-06-18', '2009-06-23', 'aaa', 'publicado', 'intranet', 1, NULL, 7, NULL, NULL, '2009-06-18 16:02:09', '2009-12-18 11:45:57', 0);
INSERT INTO `evento` VALUES (27, 'Fremap organiza una jornada en Talavera sobre prevenci�n de riesgos laborales', '<p>Con la asistencia de representantes de la Federaci&oacute;n Empresarial Talaverana, del alcalde de la ciudad, Sr. Rivas, y diferentes representantes sindicales, la Jornada iba dirigida de manera particular a los profesionales del sector de la construcci&oacute;n  El regidor municipal mostr&oacute; su preocupaci&oacute;n por los &iacute;ndices de siniestralidad y pidi&oacute; una reflexi&oacute;n para garantizar y proteger la salud laboral  Asimismo, D. Jos&eacute; Francisco Rivas dijo que: &ldquo;no se puede distinguir a la hora de velar permanentemente por los empleados y ante eso la Federaci&oacute;n de Municipios y Provincias hemos hecho posible que en todos los lugares de nuestra regi&oacute;n se aporten criterios y mecanismos que garanticen higiene y seguridad en el desempe&ntilde;o de nuestras tareas&rdquo;  Por su parte el director de Fremap en Talavera, Javier Gil, se&ntilde;al&oacute; que &ldquo;hay que poner en marcha todas las medidas preventivas necesarias para evitar los accidentes, y cuanto lo hagamos mucho mejor&rdquo;  Las cifras de siniestralidad son ligeramente inferiores a otras regiones, pero no por ello se hace preciso focalizar los esfuerzos hacia su reducci&oacute;n</p>', NULL, '4a3b6eaa6d90b', '', '2009-06-19', '2009-06-18', 'Fremap', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-06-19 12:55:38', NULL, 0);
INSERT INTO `evento` VALUES (29, 'VII Jornada T�cnica de Seguridad en Hopitales', '<p>7&ordf; Edici&oacute;n del &uacute;nico evento anual para el encuentro entre profesionales de la Seguridad en Centros Sanitarios.  Conoce las soluciones implantadas en otros hospitales e intercambia experiencias sobre seguridad y gesti&oacute;n  En el programa oficial de las VII Jornadas T&eacute;cnicas sobre Seguridad en Hospitales tendr&aacute;n lugar intervenciones sobre algunos de los temas m&aacute;s destacados a cargo de responsables de los centros hospitalarios reconocidos por su actividad en el &aacute;rea de la Seguridad y de la Gesti&oacute;n de Riesgos:  &bull; Planes de Prevenci&oacute;n de Agresiones a Profesionales Sanitarios  &bull; Relaciones entre el Director de Seguridad y las Autoridades Jur&iacute;dicas y Policiales  &bull; C&oacute;mo planificar la Gesti&oacute;n de Crisis en Centros Hospitalarios  &bull; Mejoras en la Gesti&oacute;n a trav&eacute;s de las Nuevas Gerencias &Uacute;nicas de &Aacute;rea  &bull; Sistemas e Instalaciones de Seguridad y Vigilancia en Centros Hospitalarios  &bull; Problem&aacute;tica especial de la Protecci&oacute;n contra Incendios en Centros Sanitarios  &bull; Seguridad en relaci&oacute;n a la Gesti&oacute;n de la Calidad, Gesti&oacute;n de Residuos y Protecci&oacute;n de la Imagen Corporativa   Lugar de Celebraci&oacute;n: Murcia, 6-8 de octubre de 2009  Informaci&oacute;n e Inscripciones: Tel: 91 500 17 24 o en www.seguridadenhopitales.es  Condiciones especiales para Mutuas: 25% de descuento si la inscripci&oacute;n se realiza antes del 31 de julio, 10% de descuento para fechas posteriores.</p>', NULL, '4a69a32533c1c.jpg', '4a69a3d3e9972.pdf', '2009-07-24', '2009-10-06', '', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-07-24 14:02:56', NULL, 0);
INSERT INTO `evento` VALUES (30, 'El impacto de las reestructuraciones en la Salud', '<p>El proyecto HIRES PLUS financiado por la Comisi&oacute;n Europea,  celebrar&aacute; su Taller en Espa&ntilde;a sobre &ldquo;El impacto de las reestructuraciones en la salud&rdquo; el 24 de septiembre en Madrid, en la sede del Instituto Nacional de Seguridad y Higiene en el Trabajo. Adjuntamos el programa del mismo.   El proyecto se dirige a analizar las vinculaciones entre las reestructuraciones empresariales y sus efectos sobre la salud de los trabajadores en su conjunto, al tiempo que analiza algunas pr&aacute;cticas preventivas desarrolladas en algunos pa&iacute;ses europeos. El proyecto se desarrolla en 13 Estados miembros de la UE.  El Taller contar&aacute; con varias presentaciones,  entre ellas algunas sobre experiencias a nivel europeo, que contribuyan a iniciar el debate. En este sentido, le pedir&iacute;amos que en caso de estar interesado, nos comunicara su intenci&oacute;n de realizar alguna exposici&oacute;n con relaci&oacute;n al tema de este proyecto.   Los interesados que deseen tomar parte en el Taller, pueden confirmar su asistencia  a:  Maribel Fern&aacute;ndez  Tel: 91 428 07 10 ext. 258 e-mail: mfernandez@labour-asociados.com  Ricardo Rodriguez  e-mail: rrodriguez@labour-asociados.com  El proyecto puede financiar los viajes y estancias de algunas personas. Aquellos que provengan de fuera de Madrid, pueden solicitar esta posibilidad, ya que el presupuesto es limitado (y en todo caso, se trata de gastos a justificar con la factura y el documento utilizado para el medio de transporte utilizado).</p>', NULL, '', '4a781feb52673.pdf', '2009-08-04', '2009-09-24', '', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-08-04 13:47:55', NULL, 0);
INSERT INTO `evento` VALUES (31, 'Jornada Cardiovascular en el Auditorio de Mutua Universal', '<p>Infartos de miocardio, anginas de pecho y accidentes vasculares representan la segunda causa de muerte en el trabajo. Cerca de 70.000 espa&ntilde;oles sufren un infarto. Y m&aacute;s del 30% fallecen antes de conseguir atenci&oacute;n hospitalaria.  &iquest;Qu&eacute; puede hacerse desde el &aacute;mbito laboral para su prevenci&oacute;n? A pesar de que los factores de riesgo de las enfermedades cardiovasculares son diversos, s&iacute; podemos intervenir sobre los m&aacute;s importantes y disminuir sus consecuencias. Le invitamos a prevenir, a saber actuar y poder salvar vidas.  Mutua Universal colabora en la jornada &ldquo;Vida Cardiosaludable y Trabajo&rdquo; organizada por la Fundaci&oacute;n Privada de Investigaci&oacute;n Cardiovascular y la Fundaci&oacute;n de Medicina Solidaria.   Especialistas y profesionales del mundo de la medicina de reconocido prestigio, como el Dr. Antoni Bay&eacute;s de Luna uno de los cardi&oacute;logos m&aacute;s destacados del mundo, habiendo sido nombrado Doctor Honoris Causa por las Universidades de Lisboa y Budapest, o la Dra. Lina Badimon Maestro profesora asociada adjunta de Mount Sinai School of Medicine (Nueva York), nombrada en 1999 presidenta de la Sociedad Europea para la Investigaci&oacute;n Cl&iacute;nica (ESCI), los cuales le aportar&aacute;n, junto a sus conocimientos, su dilatada experiencia en la prevenci&oacute;n de enfermedades cardiovasculares. El acto, adem&aacute;s, contar&aacute; con la presencia de la Honorable Consellera de Salut Marina Geli.  Inscr&iacute;base ahora mismo, y no se pierda esta jornada especialmente sensible para la salud de todos y cada uno de los trabajadores de su empresa. Empezando por la suya propia. Env&iacute;enos un e-mail a marketing@mutuauniversal.net o entre directamente en registrate.mutuauniversal.net. Su salud y la de sus colaboradores se lo agradecer&aacute;n. 	 Lugar de celebraci&oacute;n: Auditorio Mutua Universal Avda. Tibidabo, 17-19. 08022 Barcelona</p>', NULL, '4aa763da751c5.jpg', '4aa763da899d1.pdf', '2009-09-09', '2009-09-30', '', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-09-09 10:14:18', NULL, 0);
INSERT INTO `evento` VALUES (33, 'Jornadas de Incapacidad Temporal, manejo cl�nico de situaciones especiales', '<p>Estas jornadas est&aacute;n dirigids a profesionales m&eacute;dicos que intervienen en la gesti&oacute;n de la Incapacidad Temporal: &middot; Coordinadores y M&eacute;dicos de Atenci&oacute;n Primaria del Sistema P&uacute;blico de Salud. &middot; Inspectores M&eacute;dicos &middot; M&eacute;dicos de las Unidades M&eacute;dicas de los equipos de Evaluaci&oacute;n de Incapacidad del INSS  &middot; M&eacute;dicos de Mutuas  Los objetivos de las Jornadas son:  &middot; Fomentar la colaboraci&oacute;n entre los distintos agentes que intervienen en la gesti&oacute;n de la incapacidad laboral de los trabajadores. &middot; Incrementar el conocimiento mutuo entre los profesionales sanitarios con competencia en la valoraci&oacute;n de las incapacidades laborales (Servicio P&uacute;blico de Salud, INSS, MATEPSS). &middot; Avanzar en el correcto diagnostico y tratamiento de las patolog&iacute;as de la poblaci&oacute;n activa espa&ntilde;ola subsidiarias de incapacidad laboral.  Las Jornadas tendr&aacute;n lugar el 17 de Noviembre de 2009 Lugar de celebraci&oacute;n: Escuela de Administraci&oacute;n Regional C/ Rio Cabriel 45007 Toledo Tel:. 925 25 96 34 Asistencia gratuita previa inscripci&oacute;n</p>', NULL, '', '4adecdb22551a.pdf', '2009-10-21', '2009-11-17', 'AMAT, INSS y SESCAM', 'publicado', NULL, 1, NULL, NULL, NULL, NULL, '2009-10-21 11:00:34', NULL, 0);
INSERT INTO `evento` VALUES (34, 'Tercera Jornada de I.T', '<p>Objetivo de la jornada: Adecuar las situaciones de IT al contexto de crisis econ�mica en la que estamos inmersos en relaci�n a diferentes campos de acci�n: el desempleo, la justificaci�n de despidos encubierto, la presi�n en las consultas m�dicas y en las organizaciones/empresas,�etc.  Dirigido a: Profesionales sanitarios, m�dicos, enfermer�a de Atenci�n Primaria y Especializada y otros interesados. Servicios de Inspecci�n Sanitaria, Servicios M�dicos de INSS y Mutuas de ATEP, Servicios de Prevenci�n de Riesgos Laborales, Servicios M�dicos de Empresa, Organizaciones Sindicales y profesionales de la gesti�n de prestaciones en INSS, INEM, SEPECAM, Mutuas, etc, y cuantos otros consideren el contenido de la jornada de su inter�s.  Plazo de Inscripci�n de la Jornada: Inscripci�n gratuita hasta las 14:00 h. del d�a 27 de noviembre de 2009, en la Secretar�a del Servicio de Inspecci�n Sanitaria de la OPP-SESCAM-GUADALAJARA, C/ Ferial n� 31, 2� Planta. 19071 - Guadalajara. Tel�fono: 949 234050 Fax: 949 229606 E-mail: acampuzanou@sescam.jccm.es mnesteban@sescam.org</p>', '<p>edici&oacute;n</p>', '4ae9abb892b1e.jpg', '4ae9ab108f7ee.jpg', '2009-10-29', '2009-12-03', 'SESCAM, INSTITUTO NACIONAL DE LA SEGURDAD SOCIAL, OPP, AMAT Y LA COMUNIDAD AUT�NOMA DE CASTILLA Y LA MANCHA', 'publicado', 'intranet', 1, NULL, 1, NULL, NULL, '2009-10-29 15:47:44', '2009-12-28 14:07:20', 0);
INSERT INTO `evento` VALUES (35, 'Conferencia Empresarial 2009. Caminos para la recuperaci�n y el empleo', '<p><span style=\\"font-family: arial,helvetica,sans-serif;\\"><span style=\\"font-size: x-small;\\">Querido/a amigo/a:</span></span></p>\r\n<p style=\\"text-align: justify;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\"><span style=\\"font-size: x-small;\\">Tengo el gusto de convocarte a la Conferencia Empresarial Anual de CEOE que celebraremos el pr�ximo 2 de diciembre en el Palacio Municipal de Congresos de Madrid.</span></span></p>\r\n<p style=\\"text-align: justify;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\"><span style=\\"font-size: x-small;\\">La delicada situaci�n que atraviesa nuestra econom�a y el edici�n momento cr�tico que viven nuestras empresas, grandes, peque�as, medianas y empresarios aut�nomos, nos obliga a estar presentes en este acto de reafirmaci�n del valor del empresario en nuestra sociedad. Tenemos que transmitir un testimonio vivo al Gobierno, partidos pol�ticos, a los sindicatos y a los ciudadanos en general, de que la voz de los empresarios espa�oles reclama medidas y ofrece soluciones para la recuperaci�n econ�mica y el empleo. Queromos manifestar el m�s firme compromiso con nuestro pa�s.</span></span></p>\r\n<p style=\\"text-align: justify;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\"><span style=\\"font-size: x-small;\\">Vamos a contar con la presencia de empresarios de todos los lugares de Espa�a, de sectores diversos, hombres y mujeres, peque�os emprearios, j�venes emprendedores, aut�nomos que nos va a transmitir sus experiencias, sus inquietudes y tambi�n sus �xitos en estos momentos dif�ciles. Participar�n tambi�n los representantes de las organizaciones empresariales europeas y de otras instituciones empresariales espa�olas.</span></span></p>\r\n<p style=\\"text-align: justify;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\"><span style=\\"font-size: x-small;\\">Los empresarios no debemos asistir resignados a la desaparici�n silenciosa de cientos de empresas que cada d�a gneran paro y m�s paro. Tenemos que alzar nuestra voz firme y solidaria de los empresarios y de nuestros trabajadores, para exigir reformas que permitan a las empresas disponer de recursos para seguir creando riqueza, exportar, innovar, producir en las mismas condiciones que nuestros competidores internacionales, pagar impuestos razonables, alentar nuevas iniciativas empresariales entre los j�venes para que podamos seguir creando empleo y bienestar para toda la sociedad espa�ola.</span></span></p>\r\n<p style=\\"text-align: justify;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\"><span style=\\"font-size: x-small;\\">No podemos faltar. Manteng�monos unidos frente a la crisis. Revaloricemos la noble funci�n de ser empresario. Exijamos a las Administracones P�blicas las f�rmulas para crear empleo y detener la desaparaci�n de empresas.</span></span></p>\r\n<p style=\\"text-align: justify;\\">�</p>', '', '', '4afa84cab1ea4.pdf', '2009-11-11', '2009-12-02', 'CEOE', 'guardado', 'intranet', 1, NULL, 7, NULL, NULL, '2009-11-11 10:32:58', '2009-12-18 11:44:51', 0);
INSERT INTO `evento` VALUES (36, 'II CURSO PR�CTICO de T�cnicas Quir�rgicas en Cirug�a de Mano (en cadaver)', '<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 10pt;\\"><span style=\\"font-family: "Tahoma","sans-serif";\\"><span style=\\"font-size: small;\\">La Fundaci�n MAZ de Prevenci�n y <span style=\\"mso-spacerun: yes;\\">�</span>Medicina presenta el II CURSO PR�CTICO DE T�CNICAS QUIR�RGICAS EN CIRUG�A DE MANO (en cad�ver), los d�as 26 y 27 de noviembre de 2009, en el Hospital MAZ de Zaragoza.</span></span></p>', '', '4b03b80b432a9.jpg', '4b03b80b47ba8.pdf', '2009-11-18', '2009-11-26', 'Fundaci�n MAZ de Prevenci�n y Medicina', 'publicado', 'web', 1, NULL, 7, NULL, NULL, '2009-11-18 10:02:03', '2009-12-18 12:19:21', 0);
INSERT INTO `evento` VALUES (37, 'La verdad de las cosas', 'Como viene siendo normal en estos casos, metemos la info que m�s nos conviene', '<div style="padding-top: 20px;" class="noticias nuevodetalle">\r\n<h1><img align="left" src="/uploads/image/noimage.jpg" style="width: 124px; height: 138px; margin-right: 10px;" nottit="" alt="" />Titulo <big>Esto no se para que es</big></h1>\r\n<p style="font-weight: bold;" class="notentrada">Entradilla desde luego que esto tampoco</p>\r\n<p style="border-bottom: 1px dotted; margin: 10px 0px; color: rgb(204, 204, 204);">&nbsp;</p>\r\n<p>Desccripcion</p>\r\n<div class="clear">&nbsp;</div>\r\n<div class="clear">De ahora en adelante tendremos que hacer m&aacute;s cosas</div>\r\n</div>', 'a67bbe25a0f1d8c718d9e2759c03ce1d1d673ef1.jpg', '25a36e9b3cdf46a21d2a250359063dffe68f2a72.pdf', '2010-01-06', '2010-01-08', 'AMAT', 'publicado', 'web', 14, 14, 1, NULL, NULL, '2010-01-06 17:43:06', '2010-01-18 09:47:00', 0);
INSERT INTO `evento` VALUES (38, 'La verdad de las cosas II', 'Como viene siendo normal en estos casos, metemos la info que m�s nos conviene', '<div class="noticias nuevodetalle" style="padding-top: 20px;">\r\n<h1><img align="left" alt="" nottit="" style="width: 124px; margin-right: 10px; height: 138px;" src="/uploads/image/noimage.jpg" />Titulo <big>Esto no se para que es</big></h1>\r\n<p class="notentrada" style="font-weight: bold;">Entradilla desde luego que esto tampoco</p>\r\n<p style="border-bottom: 1px dotted; margin: 10px 0px; color: rgb(204, 204, 204);">&nbsp;</p>\r\n<p>Desccripcion</p>\r\n<div class="clear">&nbsp;</div>\r\n<div class="clear">De ahora en adelante tendremos que hacer m&aacute;s cosas</div>\r\n<div class="clear">&nbsp;</div>\r\n<div class="clear">Mikel</div>\r\n</div>', 'fa7ca184c32e54cddd57ca3f6811bdf2dfdd963d.jpg', '485d286c9cf7fe443ef31cff542e3796464f2963.pdf', '2010-01-06', '2010-01-08', 'AMAT', 'publicado', 'web', 14, 14, 7, NULL, NULL, '2010-01-06 17:44:37', '2010-01-18 11:42:55', 0);
INSERT INTO `evento` VALUES (39, 'esta es otra m�s', 'esto es la leche', '', '8175c25c8eae19bb6e8ab3ec9e9b5ccaddc85e6e.jpg', '358e81ddcfe086146d643d4e89e9776fcc5d7b08.pdf', '2010-01-10', '2010-01-18', 'playboy', 'publicado', 'web', 14, 14, 1, NULL, NULL, '2010-01-06 17:49:16', '2010-01-18 09:46:39', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `grupo_trabajo`
#

CREATE TABLE `grupo_trabajo` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `detalle` longtext,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

#
# Volcar la base de datos para la tabla `grupo_trabajo`
#

INSERT INTO `grupo_trabajo` VALUES (1, 'M�dico', '<p>&nbsp;</p><p>&nbsp;</p>', '2009-10-20 17:49:34', '2009-12-22 09:04:42', 0);
INSERT INTO `grupo_trabajo` VALUES (2, 'Jur�dico', '<p>&nbsp;</p><p>&nbsp;</p>', '2009-10-20 17:49:34', '2009-12-22 09:04:10', 0);
INSERT INTO `grupo_trabajo` VALUES (3, 'Prestaciones', '<p>&nbsp;</p><p>&nbsp;</p>', '2009-10-20 17:49:34', '2009-12-22 09:04:27', 0);
INSERT INTO `grupo_trabajo` VALUES (4, 'Comunicaci�n', '<p>&nbsp;</p><p>&nbsp;</p>', '2009-10-20 17:49:34', '2009-12-22 08:56:16', 0);
INSERT INTO `grupo_trabajo` VALUES (5, 'mauro   ', '<p><img alt="" align="left" nottit="" style="width: 69px; margin-right: 10px; height: 65px" src="/uploads/image/noimage.jpg" /></p><p><a href="#"><strong>T&iacute;tulo documentaci&oacute;n 1</strong></a></p><p>Descripci&oacute;n 1 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>', '2009-12-01 20:03:26', '2009-12-01 20:03:39', 1);
INSERT INTO `grupo_trabajo` VALUES (6, 'mauro', '<p><img alt="" align="left" nottit="" style="width: 69px; margin-right: 10px; height: 65px" src="/uploads/image/noimage.jpg" /></p><p><a href="#"><strong>T&iacute;tulo documentaci&oacute;n 1</strong></a></p><p>Descripci&oacute;n 1 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>', '2009-12-01 20:05:19', '2009-12-01 20:07:18', 1);
INSERT INTO `grupo_trabajo` VALUES (7, 'Absentismo', '', '2009-12-22 08:46:49', '2009-12-29 09:31:58', 0);
INSERT INTO `grupo_trabajo` VALUES (8, 'Jur�dico', '<p><img alt="" align="left" nottit="" style="width: 69px; margin-right: 10px; height: 65px" src="/uploads/image/noimage.jpg" /></p><p><a href="#"><strong>T&iacute;tulo documentaci&oacute;n 1</strong></a></p><p>Descripci&oacute;n 1 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>', '2009-12-22 08:47:20', '2009-12-29 09:13:49', 1);
INSERT INTO `grupo_trabajo` VALUES (9, 'Litigiosidad', '<p>&nbsp;</p><p>&nbsp;</p>', '2009-12-22 08:48:37', '2009-12-29 09:11:47', 0);
INSERT INTO `grupo_trabajo` VALUES (10, 'Presupuestos', '<p>&nbsp;</p><p>&nbsp;</p>', '2009-12-22 08:50:40', '2009-12-29 09:13:11', 0);
INSERT INTO `grupo_trabajo` VALUES (11, 'Recursos Sanitarios', '<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>', '2009-12-22 09:03:50', '2009-12-29 09:12:35', 0);
INSERT INTO `grupo_trabajo` VALUES (12, 'mauro', '<p><img alt="" align="left" nottit="" style="width: 69px; margin-right: 10px; height: 65px" src="/uploads/image/noimage.jpg" /></p><p><a href="#"><strong>T&iacute;tulo documentaci&oacute;n 1</strong></a></p><p>Descripci&oacute;n 1 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>', '2009-12-24 13:55:42', '2009-12-24 13:56:40', 1);
INSERT INTO `grupo_trabajo` VALUES (13, 'mauro', '<p><img alt="" align="left" nottit="" style="width: 69px; margin-right: 10px; height: 65px" src="/uploads/image/noimage.jpg" /></p><p><a href="#"><strong>T&iacute;tulo documentaci&oacute;n 1</strong></a></p><p>Descripci&oacute;n 1 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>', '2009-12-24 13:58:35', '2009-12-24 13:59:20', 1);
INSERT INTO `grupo_trabajo` VALUES (14, 'Prevenci�n de Riesgos Laborales', '<p>&nbsp;</p><p>&nbsp;</p>', '2009-12-28 09:57:58', '2009-12-28 09:57:58', 0);
INSERT INTO `grupo_trabajo` VALUES (15, 'mauro', '<p><img alt="" align="left" nottit="" style="width: 69px; margin-right: 10px; height: 65px" src="/uploads/image/noimage.jpg" /></p><p><a href="#"><strong>T&iacute;tulo documentaci&oacute;n 1</strong></a></p><p>Descripci&oacute;n 1 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>', '2009-12-28 15:04:09', '2009-12-28 18:34:15', 1);
INSERT INTO `grupo_trabajo` VALUES (16, 'Mikel Prueba', '', '2010-01-18 12:12:50', '2010-01-18 12:12:50', 0);
INSERT INTO `grupo_trabajo` VALUES (17, 'grupo TEST 2', '<p>descripcion grupo Test 2</p>', '2010-01-21 12:31:04', '2010-01-21 12:35:16', 1);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `iniciativa`
#

CREATE TABLE `iniciativa` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `contenido` longtext,
  `fecha` date NOT NULL,
  `documento` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

#
# Volcar la base de datos para la tabla `iniciativa`
#

INSERT INTO `iniciativa` VALUES (1, 'La iniciativa', '<p><span class="Apple-style-span" style="border-collapse: separate; color: rgb(0, 0, 0); font-family: \'Times New Roman\'; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px;"><span class="Apple-style-span" style="color: rgb(102, 102, 102); font-family: Verdana,Geneva,Arial,Helvetica,sans-serif; font-size: 14px; text-align: left;">Las<span class="Apple-converted-space">&nbsp;</span><i>botnets</i><span class="Apple-converted-space">&nbsp;</span>son redes de<span class="Apple-converted-space">&nbsp;</span>ordenadores zombi, PCs infectados con<span class="Apple-converted-space">&nbsp;</span><i>malware</i><span class="Apple-converted-space">&nbsp;</span>y controlados a distancia para enviar spam, realizar ataques inform&aacute;ticos y otro tipo de actos delictivos.<br />\r\n<br />\r\nPero &iquest;qui&eacute;n y por qu&eacute; est&aacute; detr&aacute;s de las<span class="Apple-converted-space">&nbsp;</span><i>botnets</i>? Eso es lo que<span class="Apple-converted-space">&nbsp;</span><span style="color: rgb(255, 0, 0);">trat&oacute; de averiguar</span><span class="Apple-converted-space">&nbsp;</span>un equipo de investigadores de Cisco, que se infiltraron en el universo de los<span class="Apple-converted-space">&nbsp;</span><i>botmasters</i><span class="Apple-converted-space">&nbsp;</span>para saber m&aacute;s sobre ellos.</span></span></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', '2009-10-14', 'dadb70293016b0bce4ddff6b5e7e25b450b40d10.pdf', '2009-10-29 22:19:31', '2009-10-29 22:19:31', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `lista_comunicado`
#

CREATE TABLE `lista_comunicado` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

#
# Volcar la base de datos para la tabla `lista_comunicado`
#

INSERT INTO `lista_comunicado` VALUES (1, 'AMAT', '2009-10-29 11:58:51', '2009-10-29 11:58:51', 0);
INSERT INTO `lista_comunicado` VALUES (2, 'preuba de icox', '2009-12-14 20:02:05', '2009-12-14 20:08:53', 1);
INSERT INTO `lista_comunicado` VALUES (3, 'prueba  ', '2009-12-14 20:08:46', '2009-12-14 20:09:10', 1);
INSERT INTO `lista_comunicado` VALUES (4, 'kk', '2009-12-18 09:10:28', '2009-12-18 09:10:33', 1);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `lista_comunicado_envio`
#

CREATE TABLE `lista_comunicado_envio` (
  `envio_comunicado_id` bigint(20) NOT NULL default '0',
  `lista_comunicado_id` bigint(20) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`envio_comunicado_id`,`lista_comunicado_id`),
  KEY `lista_comunicado_id` (`lista_comunicado_id`),
  CONSTRAINT `lista_comunicado_envio_ibfk_1` FOREIGN KEY (`lista_comunicado_id`) REFERENCES `lista_comunicado` (`id`),
  CONSTRAINT `lista_comunicado_envio_ibfk_2` FOREIGN KEY (`envio_comunicado_id`) REFERENCES `envio_comunicado` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Volcar la base de datos para la tabla `lista_comunicado_envio`
#

INSERT INTO `lista_comunicado_envio` VALUES (1, 1, '2009-10-30 09:40:37', '2009-10-30 09:40:37', 0);
INSERT INTO `lista_comunicado_envio` VALUES (2, 1, '2009-10-30 10:21:05', '2009-10-30 10:21:05', 0);
INSERT INTO `lista_comunicado_envio` VALUES (3, 1, '2009-10-30 10:42:43', '2009-10-30 10:42:43', 0);
INSERT INTO `lista_comunicado_envio` VALUES (4, 1, '2009-10-30 10:44:46', '2009-10-30 10:44:46', 0);
INSERT INTO `lista_comunicado_envio` VALUES (5, 1, '2009-10-30 10:46:48', '2009-10-30 10:46:48', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `menu`
#

CREATE TABLE `menu` (
  `id` bigint(20) NOT NULL auto_increment,
  `padre_id` bigint(20) default NULL,
  `nombre` varchar(100) default NULL,
  `descripcion` varchar(255) default NULL,
  `aplicacion_id` bigint(20) default NULL,
  `url_externa` varchar(255) default NULL,
  `posicion` bigint(20) default NULL,
  `habilitado` tinyint(1) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `aplicacion_id_idx` (`aplicacion_id`),
  CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`aplicacion_id`) REFERENCES `aplicacion` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1 AUTO_INCREMENT=62 ;

#
# Volcar la base de datos para la tabla `menu`
#

INSERT INTO `menu` VALUES (1, 0, 'Canal Corporativo', '', NULL, '', 1, 1, NULL, '2009-11-30 21:32:31', 0);
INSERT INTO `menu` VALUES (2, 1, 'Eventos', NULL, 2, NULL, 1, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (3, 1, 'Novedades', '', 1, '', 2, 1, NULL, '2009-11-20 15:10:54', 0);
INSERT INTO `menu` VALUES (4, 1, 'Aplicaciones', NULL, 23, NULL, 3, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (5, 1, 'Avisos', NULL, 17, NULL, 4, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (6, 1, 'Web Amat', '', 57, '', 5, 1, NULL, NULL, 0);
INSERT INTO `menu` VALUES (7, 6, 'Cifras y Datos', NULL, 18, NULL, 1, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (8, 6, 'Actividades', NULL, 19, NULL, 2, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (9, 6, 'Publicaciones', NULL, 20, NULL, 3, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (10, 0, 'Documentaci�n', NULL, NULL, NULL, 2, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (11, 10, 'Normativas', NULL, 13, NULL, 1, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (12, 10, 'Iniciativas Formativas', NULL, 14, NULL, 2, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (13, 10, 'Circulares', NULL, 12, NULL, 3, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (14, 13, 'Categoria de tema', NULL, 10, NULL, 1, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (15, 13, 'Subcategor�as de temas', NULL, 11, NULL, 2, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (16, 0, 'Directores Gerente', NULL, NULL, NULL, 3, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (17, 16, 'Asambleas', '', 4, '', 1, 1, NULL, NULL, 0);
INSERT INTO `menu` VALUES (18, 0, 'Grupos de Trabajo', NULL, NULL, NULL, 4, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (19, 18, 'Miembros', '', 41, '', 3, 1, NULL, '2009-12-18 10:55:26', 0);
INSERT INTO `menu` VALUES (20, 18, 'Grupos de Trabajo', '', 21, '', 1, 1, NULL, '2009-12-18 10:55:13', 0);
INSERT INTO `menu` VALUES (21, 18, 'Tipos de Documentos', '', 25, '', 9, 1, NULL, '2009-12-18 11:00:58', 0);
INSERT INTO `menu` VALUES (22, 18, 'Documentaci�n', '', 24, '', 4, 1, NULL, NULL, 0);
INSERT INTO `menu` VALUES (23, 18, 'Archivos', '', 26, '', 5, 1, NULL, '2009-12-18 10:56:34', 0);
INSERT INTO `menu` VALUES (24, 0, 'Consejos Territoriales', NULL, NULL, NULL, 5, 1, '2009-11-16 14:53:24', '2009-11-16 14:53:24', 0);
INSERT INTO `menu` VALUES (25, 24, 'Consejos Territoriales', '', 22, '', 1, 1, NULL, NULL, 0);
INSERT INTO `menu` VALUES (26, 24, 'Tipos de Documentos', '', 27, '', 9, 1, NULL, '2009-12-18 11:00:44', 0);
INSERT INTO `menu` VALUES (27, 24, 'Documentaci�n', '', 28, '', 3, 1, NULL, '2009-12-18 10:59:57', 0);
INSERT INTO `menu` VALUES (28, 24, 'Archivos', '', 29, '', 4, 1, NULL, NULL, 0);
INSERT INTO `menu` VALUES (29, 0, 'Administraci�n', NULL, NULL, NULL, 6, 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `menu` VALUES (30, 29, 'Gesti�n de Usuarios', NULL, 5, NULL, 1, 1, '2009-11-16 14:53:25', '2009-11-16 14:53:25', 0);
INSERT INTO `menu` VALUES (31, 29, 'Aplicaciones de Rol', NULL, 6, NULL, 3, 1, '2009-11-16 14:53:25', '2010-01-18 18:22:58', 0);
INSERT INTO `menu` VALUES (32, 29, 'Cuenta de Correo de Contacto', NULL, 9, NULL, 4, 1, '2009-11-16 14:53:25', '2010-01-18 18:22:58', 0);
INSERT INTO `menu` VALUES (33, 29, 'Gesti�n de Mutuas', NULL, 15, NULL, 5, 1, '2009-11-16 14:53:25', '2010-01-18 18:22:58', 0);
INSERT INTO `menu` VALUES (34, 29, 'Organismos', '', 58, '', 7, 1, NULL, '2010-01-18 18:22:58', 0);
INSERT INTO `menu` VALUES (35, 34, 'Categor�as', '', 30, '', 1, 1, NULL, '2009-12-22 20:16:34', 0);
INSERT INTO `menu` VALUES (36, 34, 'Subcategor�as', '', 31, '', 8, 1, NULL, '2009-12-22 20:16:01', 0);
INSERT INTO `menu` VALUES (37, 34, 'Organismos', '', 32, '', 2, 1, NULL, '2009-12-22 20:16:01', 0);
INSERT INTO `menu` VALUES (38, 34, 'Documentaci�n', '', 33, '', 4, 1, NULL, '2009-12-22 20:16:01', 0);
INSERT INTO `menu` VALUES (39, 34, 'Archivos', '', 34, '', 5, 1, NULL, '2009-12-22 20:16:01', 0);
INSERT INTO `menu` VALUES (40, 29, 'Comunicados', NULL, 37, NULL, 8, 1, '2009-11-16 14:53:25', '2010-01-18 18:22:58', 0);
INSERT INTO `menu` VALUES (41, 40, 'Env�o', '', 38, '', 1, 1, NULL, NULL, 0);
INSERT INTO `menu` VALUES (42, 40, 'Tipos', '', 36, '', 2, 1, NULL, '2009-12-18 11:15:45', 0);
INSERT INTO `menu` VALUES (43, 40, 'Listas', '', 35, '', 3, 1, NULL, '2009-12-18 11:17:24', 0);
INSERT INTO `menu` VALUES (44, 29, 'Aplicaciones Externas', NULL, 23, NULL, 9, 1, '2009-11-16 14:53:25', '2010-01-18 18:22:58', 0);
INSERT INTO `menu` VALUES (45, 29, 'Administarcion del Menu', NULL, 39, NULL, 10, 1, '2009-11-16 14:53:25', '2010-01-18 18:22:58', 0);
INSERT INTO `menu` VALUES (46, 18, 'Convocatorias', '', 42, '', 6, 1, NULL, NULL, 0);
INSERT INTO `menu` VALUES (47, 24, 'Convocatorias', '', 43, '', 5, 1, NULL, '2009-12-18 11:00:32', 0);
INSERT INTO `menu` VALUES (48, 18, 'Actas ', '', 16, '', 7, 1, NULL, NULL, 0);
INSERT INTO `menu` VALUES (49, 24, 'Actas ', '', 45, '', 7, 1, NULL, NULL, 0);
INSERT INTO `menu` VALUES (50, 24, 'Miembros', '', 47, '', 2, 1, NULL, '2009-12-18 10:58:05', 0);
INSERT INTO `menu` VALUES (51, 34, 'Convocatoria', '', 48, '', 6, 1, NULL, '2009-12-22 20:16:01', 0);
INSERT INTO `menu` VALUES (52, 34, 'Miembros', '', 50, '', 3, 1, NULL, '2009-12-22 20:16:01', 0);
INSERT INTO `menu` VALUES (53, 29, 'Gestion de Aplicacion', '', 51, '', 6, 1, '2009-11-24 18:53:47', '2010-01-18 18:22:58', 0);
INSERT INTO `menu` VALUES (54, 10, 'Prueba de icox', '', 52, '', 4, 1, NULL, '2009-11-27 20:30:44', 0);
INSERT INTO `menu` VALUES (55, 5, 'una', '', 52, '', 0, 1, NULL, '2009-12-08 23:54:44', 1);
INSERT INTO `menu` VALUES (56, 18, 'Normas de Funcionamiento', '', 54, '', 0, 1, '2009-12-03 18:07:22', '2009-12-03 18:30:17', 1);
INSERT INTO `menu` VALUES (57, 18, 'Normas de Funcionamiento', '', 54, '', 2, 1, NULL, NULL, 0);
INSERT INTO `menu` VALUES (58, 16, 'Junta directiva', '', 55, '', 2, 1, '2009-12-22 14:46:30', '2009-12-22 14:46:30', 0);
INSERT INTO `menu` VALUES (59, 16, 'Asambleas - Otros', '', 56, '', 3, 1, '2009-12-22 15:18:37', '2009-12-22 15:18:37', 0);
INSERT INTO `menu` VALUES (60, 34, 'Actas', '', 49, '', 7, 1, NULL, '2009-12-22 20:16:34', 0);
INSERT INTO `menu` VALUES (61, 29, 'Perfiles', '', 59, '', 2, 1, '2010-01-18 18:22:58', '2010-01-18 18:22:58', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `mutua`
#

CREATE TABLE `mutua` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `detalle` longtext,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

#
# Volcar la base de datos para la tabla `mutua`
#

INSERT INTO `mutua` VALUES (1, 'Sin mutua', NULL, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `mutua` VALUES (2, '061 - FREMAP', NULL, '2009-10-20 17:49:34', '2009-12-18 09:50:49', 0);
INSERT INTO `mutua` VALUES (3, '015 - UMIVALE', NULL, '2009-10-20 17:49:34', '2009-12-18 09:50:09', 0);
INSERT INTO `mutua` VALUES (4, '003 - ACTIVA MUTUA 2008', NULL, '2009-10-29 22:38:35', '2009-12-18 09:48:42', 0);
INSERT INTO `mutua` VALUES (5, 'FRATERNIDAD 1', NULL, '2009-10-29 22:38:55', '2009-10-29 22:39:13', 1);
INSERT INTO `mutua` VALUES (6, '001 - MC MUTUAL', NULL, '2009-12-18 09:48:10', '2009-12-18 09:48:10', 0);
INSERT INTO `mutua` VALUES (7, '002 - MUTUALIA', NULL, '2009-12-18 09:48:25', '2009-12-18 09:48:25', 0);
INSERT INTO `mutua` VALUES (8, '007 - MUTUA MONTA�ESA', NULL, '2009-12-18 09:49:16', '2009-12-18 09:49:16', 0);
INSERT INTO `mutua` VALUES (9, '010 - MUTUA UNIVERSAL ', NULL, '2009-12-18 09:49:29', '2009-12-18 09:49:29', 0);
INSERT INTO `mutua` VALUES (10, '011 - MAZ', NULL, '2009-12-18 09:49:44', '2009-12-18 09:49:44', 0);
INSERT INTO `mutua` VALUES (11, '021 - MUTUA NAVARRA', NULL, '2009-12-18 09:50:26', '2009-12-18 09:50:26', 0);
INSERT INTO `mutua` VALUES (12, '039 - MUTUA INTERCOMARCAL', NULL, '2009-12-18 09:50:37', '2009-12-18 09:50:37', 0);
INSERT INTO `mutua` VALUES (13, '072 - SOLIMAT ', NULL, '2009-12-18 09:51:04', '2009-12-18 09:51:04', 0);
INSERT INTO `mutua` VALUES (14, '115 - CESMA', NULL, '2009-12-18 09:51:18', '2009-12-18 09:51:18', 0);
INSERT INTO `mutua` VALUES (15, '151 - ASEPEYO', NULL, '2009-12-18 09:51:29', '2009-12-18 09:51:29', 0);
INSERT INTO `mutua` VALUES (16, '183 - MUTUA BALEAR', NULL, '2009-12-18 09:51:44', '2009-12-18 09:51:44', 0);
INSERT INTO `mutua` VALUES (17, '201 - MUTUA GALLEGA', NULL, '2009-12-18 09:51:54', '2009-12-18 09:51:54', 0);
INSERT INTO `mutua` VALUES (18, '267 - UNI�N DE MUTUAS', NULL, '2009-12-18 09:52:05', '2009-12-18 09:52:05', 0);
INSERT INTO `mutua` VALUES (19, '272 - MAC, MUTUA DE ACCIDENTES DE CANARIAS', NULL, '2009-12-18 09:52:19', '2009-12-18 09:52:19', 0);
INSERT INTO `mutua` VALUES (20, '274 - IBERMUTUAMUR', NULL, '2009-12-18 09:52:31', '2009-12-18 09:52:31', 0);
INSERT INTO `mutua` VALUES (21, '275 - FRATERNIDAD - MUPRESPA', NULL, '2009-12-18 09:52:42', '2009-12-18 09:52:42', 0);
INSERT INTO `mutua` VALUES (22, '276 - EGARSAT', NULL, '2009-12-18 09:53:00', '2009-12-18 09:53:00', 0);
INSERT INTO `mutua` VALUES (23, '291 - CENTRO INTERMUTUAL DE EUSKADI', NULL, '2009-12-18 09:53:12', '2009-12-18 09:53:12', 0);
INSERT INTO `mutua` VALUES (24, '292 - CENTRO DE RECUPERACI�N Y REHABILITACI�N DE LEVANTE', NULL, '2009-12-18 09:53:35', '2009-12-18 09:53:35', 0);
INSERT INTO `mutua` VALUES (25, 'AMAT', NULL, '2009-12-18 09:53:43', '2009-12-18 09:53:43', 0);
INSERT INTO `mutua` VALUES (26, 'DGOSS', NULL, '2009-12-18 09:53:50', '2009-12-18 09:53:50', 0);
INSERT INTO `mutua` VALUES (27, 'MEDIOS', NULL, '2009-12-18 09:54:02', '2009-12-18 09:54:02', 0);
INSERT INTO `mutua` VALUES (28, 'aaa', NULL, '2009-12-18 10:04:43', '2009-12-18 10:04:51', 1);
INSERT INTO `mutua` VALUES (29, 'Desarrollo', NULL, '2009-12-22 09:13:07', '2009-12-22 09:13:07', 0);
INSERT INTO `mutua` VALUES (30, 'Mutua Test 2', '<p>Descripci&oacute;n mutua test 2</p>', '2010-01-21 12:15:00', '2010-01-21 12:19:58', 1);
INSERT INTO `mutua` VALUES (31, 'test2', '<p>detalle</p>', '2010-01-22 23:51:26', '2010-01-22 23:51:26', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `normas_de_funcionamiento`
#

CREATE TABLE `normas_de_funcionamiento` (
  `id` bigint(20) NOT NULL auto_increment,
  `titulo` varchar(100) default NULL,
  `descripcion` longtext,
  `grupo_trabajo_id` bigint(20) NOT NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `grupo_trabajo_id_idx` (`grupo_trabajo_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

#
# Volcar la base de datos para la tabla `normas_de_funcionamiento`
#

INSERT INTO `normas_de_funcionamiento` VALUES (1, 'prueba de icox', '<div class="noticias nuevodetalle" style="padding-top: 20px"><img alt="" align="left" nottit="" style="width: 124px; margin-right: 10px; height: 138px" src="/uploads/image/noimage.jpg" />Titulo<br /><p class="notentrada" style="font-weight: bold">Entradilla</p><p style="margin: 10px 0px; color: rgb(204,204,204); border-bottom: 1px dotted">&nbsp;</p><p>Desccripcion</p><div class="clear">&nbsp;</div></div>', 3, NULL, NULL, 0);
INSERT INTO `normas_de_funcionamiento` VALUES (2, 'segunda prueba de icox ', '<div class="noticias nuevodetalle" style="padding-top: 20px"><img alt="" align="left" nottit="" style="width: 124px; margin-right: 10px; height: 138px" src="/uploads/image/noimage.jpg" />Mauro Garcia<br /><p class="notentrada" style="font-weight: bold">Entradilla</p><p style="margin: 10px 0px; color: rgb(204,204,204); border-bottom: 1px dotted">&nbsp;</p><p>Desccripcion</p><div class="clear">&nbsp;</div></div>', 4, '2009-12-03 21:02:44', '2009-12-03 21:02:44', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `normativa`
#

CREATE TABLE `normativa` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `contenido` longtext,
  `fecha` date NOT NULL,
  `documento` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

#
# Volcar la base de datos para la tabla `normativa`
#

INSERT INTO `normativa` VALUES (1, 'Uno dos', '<p><span style="border-collapse: separate; color: rgb(29, 29, 29); font-family: Arial,Helvetica,sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px;" class="Apple-style-span"><span style="font-size: 14px;" class="Apple-style-span">La llegada de un sistema de navegaci&oacute;n GPS para m&oacute;viles con el software de Google provoc&oacute; el desplome en bolsa de los fabricantes de estos aparatos como TomTom y Garmin, con los que el buscador de internet competir&aacute; a partir de ahora.<br style="margin: 0px; padding: 0px; font-size: 13px; font-family: Arial,Helvetica,sans-serif; color: rgb(29, 29, 29); text-shadow: none;" />\r\n<br style="margin: 0px; padding: 0px; font-size: 13px; font-family: Arial,Helvetica,sans-serif; color: rgb(29, 29, 29); text-shadow: none;" />\r\nEl primer tel&eacute;fono m&oacute;vil que incorporar&aacute; esta funci&oacute;n es el esperado Droid de Motorola, que funciona con el software Android de Google.<em style="margin: 0px; padding: 0px; font-size: 13px; font-family: Arial,Helvetica,sans-serif; color: rgb(29, 29, 29); text-shadow: none;"><strong style="margin: 0px 0px 13px; padding: 0px; font-size: 14px; font-family: Arial,Helvetica,sans-serif; color: rgb(29, 29, 29); text-shadow: none;"><span class="Apple-converted-space">&nbsp;</span>(Notas relacionadas)</strong></em></span></span></p>', '2010-10-29', '42cd8a7bf6d631fae637c20cccfe6cf9d67221b5.pdf', '2009-10-29 22:02:28', '2009-10-29 22:12:03', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `noticia`
#

CREATE TABLE `noticia` (
  `id` bigint(20) NOT NULL auto_increment,
  `titulo` varchar(100) NOT NULL,
  `autor` varchar(100) NOT NULL,
  `entradilla` longtext NOT NULL,
  `contenido` longtext,
  `imagen` varchar(255) default NULL,
  `documento` varchar(255) default NULL,
  `fecha` date NOT NULL,
  `fecha_publicacion` date NOT NULL,
  `fecha_caducidad` date NOT NULL,
  `ambito` varchar(255) default NULL,
  `estado` varchar(255) default NULL,
  `destacada` tinyint(1) default NULL,
  `mutua_id` bigint(20) default NULL,
  `owner_id` bigint(20) default NULL,
  `user_id_creador` bigint(20) default NULL,
  `user_id_modificado` bigint(20) default NULL,
  `user_id_publicado` bigint(20) default NULL,
  `fecha_publicado` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `mutua_id_idx` (`mutua_id`),
  KEY `owner_id_idx` (`owner_id`),
  CONSTRAINT `noticia_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `noticia_ibfk_2` FOREIGN KEY (`mutua_id`) REFERENCES `mutua` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=latin1 AUTO_INCREMENT=129 ;

#
# Volcar la base de datos para la tabla `noticia`
#

INSERT INTO `noticia` VALUES (17, 'Egarsat abre una nueva delegaci�n en Abrera', 'EGARSAT', '<p>La nueva delegaci&oacute;n, que se suma a las m&aacute;s de 40 que ofrecen servicio a los mutualistas de la entidad, se encuentra ubicada en una posici&oacute;n estrat&eacute;gica para el tejido empresarial de la zona.</p>', '<p>El pasado 3 de marzo, Egarsat abri&oacute; una delegaci&oacute;n en la localidad de Abrera (Barcelona), desde la que se ofrecer&aacute; atenci&oacute;n administrativa a las empresas mutualistas, as&iacute; como, pr&oacute;ximamente, atenci&oacute;n m&eacute;dico-asistencial integral.  Con unas dependencias amplias y bien equipadas, las nuevas instalaciones se encuentran ubicadas en la calle Progr&eacute;s n&ordm;28, Nave 4, y dar&aacute; servicio en horario de 9h a 14h y de 15h a 18h.</p>', '49d1e1ad0f8b5.jpg', '', '2009-03-31', '2009-03-31', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-03-31 11:26:05', NULL, 0);
INSERT INTO `noticia` VALUES (18, 'Corbacho reclama a la CEOE que arrime el hombro para propiciar el', 'elplural.com', '<p>Celestino Corbacho, ministro de Trabajo e Inmigraci&oacute;n, considera que la Confederaci&oacute;n Espa&ntilde;ola de Organizaciones Empresariales (CEOE) \\"cometer&iacute;a un grave error\\" si pone en crisis el di&aacute;logo social, porque el crecimiento econ&oacute;mico que ha tenido Espa&ntilde;a en los &uacute;ltimos a&ntilde;os ha sido, en una parte muy importante, gracias a la ausencia de conflicto social.</p>', '', '', '49e31f48a1f5b.pdf', '2009-04-13', '2009-04-13', '2009-04-18', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-04-13 13:17:28', NULL, 0);
INSERT INTO `noticia` VALUES (19, 'La mutua Fremap entrega el tercer premio del Concurso de Proyectos Solidarios a la Fundaci�n Atabal', 'Europapress', '<p>La mutua de accidentes de trabajo de la Seguridad Social Fremap entreg&oacute; ayer el tercer premio de la pasada edici&oacute;n del Concurso de Proyectos Solidarios, organizado por la entidad, a la Fundaci&oacute;n Atabal para la Cooperaci&oacute;n y el Desarrollo. El premio consiste en una dotaci&oacute;n econ&oacute;mica de 3.650 euros.</p>', '', '', '49e31fa23dd0e.pdf', '2009-04-13', '2009-04-13', '2009-04-18', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-04-13 13:18:58', NULL, 0);
INSERT INTO `noticia` VALUES (20, 'Los sindicatos y patronal toman posiciones ante la negociaci�n social', 'Expansi�n', '', '', '', '49e31ff001946.pdf', '2009-04-13', '2009-04-13', '2009-04-18', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-04-13 13:20:15', NULL, 0);
INSERT INTO `noticia` VALUES (21, 'Discurso de investidura del Presidente de la CEOE', 'CEOE', '', '', '', '49e450aac6735.pdf', '2009-04-14', '2009-04-14', '2009-04-19', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-04-14 11:00:26', NULL, 0);
INSERT INTO `noticia` VALUES (24, 'Metodolog�a de Evaluaci�n de Riesgo de Atraco: Sector Banca', 'UMIVALE', '', '', '', '49e7140027743.pdf', '2009-04-16', '2009-04-16', '2009-04-21', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-04-16 13:18:24', NULL, 0);
INSERT INTO `noticia` VALUES (26, 'Jos� Vicente Morata y H�ctor Blasco galardonados en la X� Edici�n de los  Premios Nacionales e Inter', 'UMIVALE', '', '<p>M&aacute;s informaci&oacute;n</p>', '49ec26e4f1002.pdf', '', '2009-04-16', '2009-04-16', '2009-04-21', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-04-20 09:40:20', NULL, 0);
INSERT INTO `noticia` VALUES (27, 'La Comisi�n Sectorial de la Energ�a de umivale', 'UMIVALE', '', '<p>M&aacute;s informaci&oacute;n</p>', '', '49ec275014a2a.pdf', '2009-04-20', '2009-04-20', '2009-04-25', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-04-20 09:42:08', NULL, 0);
INSERT INTO `noticia` VALUES (28, 'umivale y la Fundaci�n Sagardoy analiza la gesti�n del absentismo laboral como clave para mejorar la', 'UMIVALE', '', 'M�s informaci�n', '', '49eda7215402c.pdf', '2009-04-21', '2009-04-21', '2009-04-26', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-04-21 12:59:45', NULL, 0);
INSERT INTO `noticia` VALUES (29, 'Asepeyo ha destinado 28,3 millones de euros en ayudas sociales a personas que han sufrido un acciden', 'ASEPEYO', '<p>En sus 25 a&ntilde;os de existencia, la Comisi&oacute;n de Prestaciones Especiales de la Mutua ha atendido 20.462 casos de trabajadores en esta situaci&oacute;n.   En 2008, la Mutua ha aumentado en un 58,5% el importe de estas ayudas.</p>', '<p>La Comisi&oacute;n de Prestaciones Especiales de Asepeyo, &oacute;rgano que gestiona el Fondo de Asistencia Social de la Mutua, ha otorgado, en sus 25 a&ntilde;os de existencia, m&aacute;s de 28,3 millones de euros, con un total de 20.462 casos atendidos de trabajadores que han sufrido un accidente de trabajo o enfermedad profesional.  Formada por ocho miembros pertenecientes, a partes iguales, a representantes de los empresarios asociados, designados por la Junta Directiva, y por trabajadores de las empresas asociadas, elegidos por las organizaciones sindicales, la Comisi&oacute;n promueve la integraci&oacute;n social de las personas con minusval&iacute;a derivada de un accidente de trabajo o enfermedad profesional, la sensibilizaci&oacute;n y el apoyo profesional a este colectivo mediante ayudas econ&oacute;micas y el programa de readaptaci&oacute;n laboral Asepeyo Integra.   Estas ayudas especiales tienen como objetivo mejorar las condiciones de calidad de vida y atender situaciones de especial necesidad que tengan los trabajadores que han sufrido un accidente de trabajo o enfermedad profesional. Se dedica especial atenci&oacute;n a las situaciones de gran invalidez, adaptaci&oacute;n y rehabilitaci&oacute;n de viviendas, eliminaci&oacute;n de barreras arquitect&oacute;nicas, ayudas familiares, adecuaci&oacute;n de veh&iacute;culos propios o cursos ocupacionales.  La profesionalidad y la responsabilidad de Asepeyo en la gesti&oacute;n de los recursos p&uacute;blicos han permitido incrementar hist&oacute;ricamente la cuant&iacute;a econ&oacute;mica del Fondo de Asistencia Social. As&iacute;, en el 2008, la Comisi&oacute;n ha podido destinar 2.938.916,27 euros a este fin, un 58,5 % m&aacute;s que en el ejercicio anterior, y ha atendido 1.055 casos, cifra que supone un aumento de un 36,8%.  Estas ayudas, que son extraordinarias en los casos de accidente de trabajo y enfermedad profesional, y complementarias a las prestaciones reglamentarias, se conceden conforme a la normativa legal de Mutuas de Accidentes de Trabajo y Enfermedades Profesionales.</p>', '', '49f04d23c1875.pdf', '2009-04-23', '2009-04-23', '2009-04-28', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-04-23 13:12:35', NULL, 0);
INSERT INTO `noticia` VALUES (31, 'Asepeyo celebra el D�a de la Seguridad y la Salud en el Trabajo en Valladolid', 'ASEPEYO', 'La jornada, que ha contado con la participaci�n de destacadas empresas de Castilla y Le�n, ha abordado la seguridad y salud de las empresas en tiempo de crisis', 'Con motivo del 28 de abril, Asepeyo ha organizado la s�ptima edici�n de la jornada del D�a de la Seguridad y la Salud en el Trabajo, celebrada este a�o en el Centro de Congresos Miguel Delibes, de Valladolid. \r\n\r\nEn esta ocasi�n el tema central ha sido La gesti�n de la seguridad y la salud en las empresas en tiempo de crisis. Dirigida a empresarios y agentes sociales relacionados con el mundo laboral y la prevenci�n, se ha contado con la participaci�n de distintas empresas de Castilla y Le�n, personalidades de prestigio a nivel nacional, adem�s de directivos y t�cnicos de Asepeyo.\r\n\r\n�El principal objetivo de esta jornada es concienciar a la sociedad de la importancia de implantar buenas pr�cticas en materia de seguridad e higiene y unas pol�ticas de prevenci�n adecuadas, as� como informar de los beneficios que, a medio y largo plazo, aportan a la salud de los trabajadores�, explica Francisco Javier Toca, director auton�mico de Asepeyo en Castilla y Le�n. \r\n\r\nIgnacio Javier Ariznavarreta Esteban, viceconsejero de Econom�a y Empleo de la Junta de Castilla y Le�n, ha inaugurado la jornada que se ha iniciado con una sesi�n donde se han explicado las patolog�as existentes en las organizaciones, los tipos de profesionales que existen y c�mo trabajar con ellos. Otros temas desarrollados han sido el an�lisis de la situaci�n actual de las mutuas de accidente de trabajo y enfermedades profesionales de la Seguridad Social, as� como una mesa redonda en la que diferentes sectores de actividad como el de la automoci�n, la construcci�n, el sector servicios y la Administraci�n han debatido sobre c�mo act�an y gestionan la seguridad y la salud de sus empresas en el contexto econ�mico actual. Moderada por Ignacio P�rez, director del peri�dico El Norte de Castilla, en esta mesa redonda han participado directivos de empresas como Ford, Renault, Acciona, Grupo Norte y la Junta de Castilla y Le�n. \r\n\r\nDurante la jornada se han entregado las distinciones al comportamiento preventivo de las empresas castellanoleonesas y de �mbito nacional que en el �ltimo a�o han desarrollado una mejor labor en materia de prevenci�n de riesgos laborales. Los criterios tenidos en cuenta para otorgar estas distinciones han sido la gesti�n de la prevenci�n, la reducci�n del n�mero de accidentes de trabajo y el desarrollo de un esfuerzo com�n para integrar unas pr�cticas preventivas adecuadas en todos los niveles jer�rquicos de la empresa. \r\n\r\nLas sesiones de la tarde se han dedicado a talleres t�cnicos monogr�ficos, que han analizado, por un lado, las pr�cticas preventivas en el sector de la automoci�n, y por otro, se ha debatido sobre la gesti�n de la seguridad y la salud en las empresas de Castilla y Le�n. En los talleres han participado entidades y organismos como la Inspecci�n de Trabajo y Seguridad Social de Castilla y Le�n, PPG Ib�rica, ISS o Grupo Europac. \r\n', '49f968f34de0d.pdf', '49f968f34fd43.pdf', '2009-04-30', '2009-04-30', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-04-30 11:01:39', NULL, 0);
INSERT INTO `noticia` VALUES (33, 'Fraternidad Muprespa pone en marcha Previene, un nuevo portal divulgativo sobre prevenci�n', 'FRATERNIDAD - MUPRESPA', '<p>Fraternidad Muprespa pone a disposici&oacute;n de todo el p&uacute;blico un nuevo portal de car&aacute;cter divulgativo \\"PREVIENE\\", con la intenci&oacute;n de constituir un espacio destinado a informar al visitante sobre aspectos relativos a la prevenci&oacute;n de accidentes de trabajo y enfermedades profesionales.</p>', '<p>Fraternidad Muprespa pone a disposici&oacute;n de todo el p&uacute;blico un nuevo portal de car&aacute;cter divulgativo \\"PREVIENE\\", con la intenci&oacute;n de constituir un espacio destinado a informar al visitante sobre aspectos relativos a la prevenci&oacute;n de accidentes de trabajo y enfermedades profesionales.  Desde este nuevo portal, Fraternidad Muprespa pretende presentar la prevenci&oacute;n desde un prisma distinto al habitual: m&aacute;s amigable, m&aacute;s cercano, m&aacute;s pr&aacute;ctico y sobre todo m&aacute;s interesante.  Para ello, el nuevo portal, mediante una original y atractiva presentaci&oacute;n, quiere acercarse al lector a trav&eacute;s de cualquiera de sus 7 secciones:  DOCUMENTACI&Oacute;N. Secci&oacute;n en la que se publica gran cantidad de informaci&oacute;n en materia preventiva a trav&eacute;s manuales de buenas pr&aacute;cticas, posters, carteles y tr&iacute;pticos. Todo este material puede ser descargado libremente.  BOLET&Iacute;N INFOPREVENCI&Oacute;N. Secci&oacute;n constituida por el bolet&iacute;n publicado cada mes en d&oacute;nde se reflejan novedades legislativas, noticias de inter&eacute;s, informaci&oacute;n sobre eventos, se comentan sentencias, etc. Desde la secci&oacute;n podr&aacute; acceder a todos los boletines publicados y podr&aacute; tambi&eacute;n inscribirse para recibirlo gratuitamente en su correo electr&oacute;nico.  REVISTA \\"LA MUTUA\\" Secci&oacute;n constituida por esta revista publicada peri&oacute;dicamente con art&iacute;culos t&eacute;cnicos de gran inter&eacute;s en el campo de la salud laboral y la prevenci&oacute;n de accidentes de trabajo y enfermedades profesionales. Desde la secci&oacute;n podr&aacute; acceder a todos los n&uacute;meros que han sido publicados.  OFERTA EDUCATIVA. Secci&oacute;n dedicada a nuestra oferta educativa, en la que encontrar&aacute; toda la informaci&oacute;n acerca del tipo de jornadas existente, el detalle del programa, el calendario de actividades y la solicitud de inscripci&oacute;n. La oferta educativa forma parte de las actividades que Fraternidad Muprespa, desarrolla para la prevenci&oacute;n de los accidentes de trabajo y enfermedades profesionales de las empresas asociadas, en su condici&oacute;n de colaboradora en la gesti&oacute;n de la Seguridad Social.  VIDEOS. Secci&oacute;n en la que se pueden visualizar videos que muestran de manera amena y divertida, cu&aacute;les son los riesgos a los que podemos exponernos a consecuencia del trabajo, y cu&aacute;les son las acciones que se pueden poner en pr&aacute;ctica para resolverlos.  GALERIA VITUAL. Secci&oacute;n en la que se expone virtualmente la exposici&oacute;n itinerante \\"ACCIDENTES Y PREVENCI&Oacute;N. CARTELES ESPA&Ntilde;OLES DEL SIGLO XX\\" que Fraternidad Muprespa llev&oacute; a distintos puntos de la geograf&iacute;a espa&ntilde;ola y a ra&iacute;z de su acogida, lo ponemos a su disposici&oacute;n.   FORO. Secci&oacute;n destinada al foro COMITIUM de Fraternidad Muprespa. Aqu&iacute; podr&aacute;, de una forma sencilla e intuitiva, dar respuesta a sus dudas o cuestiones relacionadas con prevenci&oacute;n, a trav&eacute;s del di&aacute;logo con nuestros especialistas en las distintas materias y con otras personas con las mismas inquietudes que las suyas.  Por &uacute;ltimo, en Fraternidad Muprespa estamos convencidos de que esta nueva herramienta divulgativa ser&aacute; de su inter&eacute;s y confiamos en contar con usted como lector habitual de nuestras secciones.  http://www.fraternidad.com/previene</p>', '49feed1867a2b.jpg', '', '2009-05-04', '2009-05-04', '2009-05-09', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-05-04 15:26:36', NULL, 0);
INSERT INTO `noticia` VALUES (34, 'Asepeyo concreta su plan de igualdad', 'ASEPEYO', '<p>El Plan de Igualdad Asepeyo Monalisa supone un paso m&aacute;s hacia el bienestar laboral: promueve medidas encaminadas a la mejora de la calidad de vida de todos los trabajadores y garantiza el principio de igualdad de oportunidades entre mujeres y hombres</p>', '<p>El Plan de Igualdad Asepeyo Monalisa, firmado el pasado 27 de enero entre los representantes de la Mutua Asepeyo y la representaci&oacute;n legal de los trabajadores, culmina el proceso de implantaci&oacute;n de pol&iacute;ticas de igualdad y gesti&oacute;n de la diversidad iniciado por la Mutua en el a&ntilde;o 2005.   Este acuerdo forma parte del compromiso de Asepeyo para llevar a cabo pol&iacute;ticas que promuevan la igualdad de trato, evitando toda discriminaci&oacute;n en cualquier &aacute;mbito y nivel de la empresa, y redundando as&iacute; en la fidelizaci&oacute;n e identificaci&oacute;n positiva de los trabajadores con &eacute;sta.   El Plan de Igualdad Asepeyo Monalisa refuerza el compromiso de responsabilidad social corporativa asumido por la Mutua y por la representaci&oacute;n legal de los trabajadores, favoreciendo la conciliaci&oacute;n de su vida personal, familiar y laboral. Por ello, recoge pol&iacute;ticas de igualdad de trato en diferentes &aacute;mbitos de la empresa, como son la selecci&oacute;n de personal, el acceso igualitario a la formaci&oacute;n o la promoci&oacute;n interna, entre otras acciones. &Eacute;stas garantizar&aacute;n la no discriminaci&oacute;n directa o indirecta por raz&oacute;n de g&eacute;nero, especialmente aquellas derivadas de la maternidad, la asunci&oacute;n de obligaciones familiares y el estado civil de los trabajadores.</p>', '4a1250749192e.jpg', '4a117b2cd2b55.doc', '2009-05-18', '2009-05-18', '2009-05-23', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-05-18 17:13:48', NULL, 0);
INSERT INTO `noticia` VALUES (36, 'Fremap y la Universidad de Extremadura imparten una jornada sobre las enfermedades profesionales y l', 'FREMAP', '<p>El pasado martes, se celebr&oacute; en el Aula Magna de la Facultad de Ciencias Econ&oacute;micas y Empresariales de la Universidad de Extremadura (UEx) una jornada sobre enfermedades profesionales y riesgos durante el embarazo y la lactancia. Uno de los objetivos era examinar las novedades legislativas introducidas en el &aacute;mbito de las enfermedades profesionales, riesgos durante el embarazo y lactancia.</p>', '<p>Los objetivos de esta jornada fueron examinar las novedades legislativas en las tres &aacute;reas de an&aacute;lisis, analizar el marco legal y su gesti&oacute;n y notificaci&oacute;n y las pautas que desde los servicios de prevenci&oacute;n de riesgos laborales de las empresas se deben tener en cuenta en estas contingencias.   El acto cont&oacute; con la presencia de m&aacute;s de 80 personas, desde directivos de empresas, m&eacute;dicos del INSS, m&eacute;dicos de medicina del trabajo, graduados sociales y profesionales de prevenci&oacute;n.</p>', '', '', '2009-05-29', '2009-05-29', '0000-00-00', 'web', 'pendiente', 0, 1, 1, 1, 0, 0, NULL, '2009-05-29 23:14:39', NULL, 0);
INSERT INTO `noticia` VALUES (37, 'UMIVALE CELEBRA EN BENIDORM UNA JORNADA DEDICADA A ANALIZAR EL ABSENTISMO LABORAL EN LA HOSTELER�A', 'UMIVALE', '', '', '', '4a23e5d496e1b.pdf', '2009-06-01', '2009-06-01', '2009-06-06', 'web', 'pendiente', 0, 1, 1, 1, 0, 0, NULL, '2009-06-01 16:29:40', NULL, 0);
INSERT INTO `noticia` VALUES (38, 'Reconocimiento para Uni�n de Mutuas', 'construarea.com', '<p>Uni&oacute;n de Mutuas recibe un premio en reconocimiento a su labor en por la implantaci&oacute;n y divulgaci&oacute;n de la seguridad laboral</p>', '', '4a250d3e8b96e.jpg', '4a250d3e8f7de.pdf', '2009-06-02', '2009-06-02', '2009-06-07', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-02 13:30:06', NULL, 0);
INSERT INTO `noticia` VALUES (39, 'Afiliaci�n a la Seguridad Social del mes de mayo', 'Ministerio de Trabajo e Inmigraci�n', '<p>El n&uacute;mero medio de afiliados a la Seguridad Social aument&oacute; en 69.304 ocupados en mayo</p>', '', '4a2515a2da526.jpg', '4a25155cde234.pdf', '2009-06-02', '2009-06-02', '2009-06-07', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-02 14:04:43', NULL, 0);
INSERT INTO `noticia` VALUES (40, 'CEOE, se pueden bajar tres puntos las cuotas sociales sin subir otros tributos', 'ABC', '<p>La CEOE cree que el goteo de medidas que el Gobierno ha ido negociando en el marco del di&aacute;logo social y poniendo en marcha en los &uacute;ltimos meses han tenido un &laquo;escaso impacto&raquo; en la creaci&oacute;n de empleo, por lo que aboga por una estrategia global de reformas que preparen a Espa&ntilde;a para el momento de la recuperaci&oacute;n.</p>', '', '4a2791cabe068.jpg', '4a2791cac2e7d.pdf', '2009-06-04', '2009-06-04', '2009-06-09', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-04 11:20:10', NULL, 0);
INSERT INTO `noticia` VALUES (41, 'Fremap celebra en C�rdoba su junta asesora empresarial de Andaluc�a', 'Diario de C�rdoba', '', '', '4a28eaab8d72b.jpg', '4a28eaab92532.pdf', '2009-06-05', '2009-06-05', '2009-06-10', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-05 11:51:39', NULL, 0);
INSERT INTO `noticia` VALUES (42, 'Sentencia a favor de Fraternidad', 'Europa press', '', '', '4a36242222e46.jpg', '4a36242227c5b.pdf', '2009-06-15', '2009-06-15', '2009-06-20', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-15 12:36:18', NULL, 0);
INSERT INTO `noticia` VALUES (43, 'MUTUALIA ya tiene consolidada la unificaci�n de las condiciones laborales de toda su plantilla', 'COMFIA CCOO', '<p>A finales de 2008 se firmaron los Pactos de Empresa de MUTUALIA, fruto de la negociaci&oacute;n desarrollada entre la direcci&oacute;n y los sindicatos durante aproximadamente un a&ntilde;o y medio, con el objetivo de unificar los respectivos Pactos de Empresa de Mutua Vizcaya Industrial, Pakea y La Previsora antes de su proceso de fusi&oacute;n. La firma de estos Pactos de Empresa afectan a un colectivo de 700 personas aproximadamente, y tienen una vigencia de de 4 a&ntilde;os (2008-2011).</p>', '', '4a3756d2a047e.jpg', '4a3756d2a42fe.pdf', '2009-06-16', '2009-06-16', '2009-06-21', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-16 10:24:50', NULL, 0);
INSERT INTO `noticia` VALUES (44, 'Las empresas podr�n hacer menos papeleo y m�s prevenci�n', 'Diario Vasco', '<p>Las Pymes tienen a su disposici&oacute;n una herramienta inform&aacute;tica gratuita que simplifica el cumplimiento formal. PCAE es una aplicaci&oacute;n inform&aacute;tica accesible a trav&eacute;s de internet www.pcae.es Los t&eacute;cnicos pueden dedicar m&aacute;s tiempo a analizar la informaci&oacute;n y proponer medidas</p>', '<p>Pedro Pablo Sanz, miembro de la Comisi&oacute;n de Riesgos Laborales de la CEOE, fue el encargado de mostrar las bondades de dicha herramienta y tom&oacute; prestada la frase. La herramienta, promovida por la patronal, los sindicatos y las administraciones, es gratuita y permite a los empresarios cumplir de una manera sencilla y organizada con las obligaciones derivadas de la coordinaci&oacute;n de actividades empresariales en prevenci&oacute;n de riesgos laborales.</p>', '4a3757dac24b4.jpg', '4a3757dadbade.pdf', '2009-06-16', '2009-06-16', '2009-06-21', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-16 10:29:14', NULL, 0);
INSERT INTO `noticia` VALUES (45, 'UMIVALE celebra en Castell�n una jornada dedicada a analizar la gesti�n del absentismo como una herr', 'UMIVALE', '', '', '4a3a141574979.jpg', '4a39e56493a8b.pdf', '2009-06-18', '2009-06-18', '2009-06-23', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-18 08:57:40', NULL, 0);
INSERT INTO `noticia` VALUES (46, 'Los empresarios proponen que las Mutuas puedan dar el alta y la baja a los trabajadores', 'El Economista', '<p>La patronal propone, en primer lugar, llegar a un acuerdo con el Gobierno y los sindicatos para habilitar a las Mutuas para dar el alta a los trabajadores; en segundo lugar, que se pongan en marcha mecanismos de verificaci&oacute;n y control de estas bajas; y, en tercer lugar, que se establezca un procedimiento sancionador por utilizaci&oacute;n fraudulenta de la situaci&oacute;n de baja</p>', '', '', '4a3a114610025.pdf', '2009-06-18', '2009-06-18', '2009-06-23', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-18 12:04:54', NULL, 0);
INSERT INTO `noticia` VALUES (47, 'ELA exige en la reuni�n de la Comisi�n Ejecutiva del INSS un cambio en la pol�tica de contrataci�n d', 'Europa press', '<p>El sindicato ELA exigi&oacute; hoy, en la reuni&oacute;n de la Comisi&oacute;n Ejecutiva del Instituto Nacional de la Seguridad Social, celebrada hoy en Madrid, un cambio en la pol&iacute;tica de contrataci&oacute;n de las Mutuas, seg&uacute;n inform&oacute; en un comunicado</p>', '', '', '4a3a11bed5ed8.pdf', '2009-06-18', '2009-06-18', '2009-06-23', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-18 12:06:42', NULL, 0);
INSERT INTO `noticia` VALUES (50, 'El Ministerio de Trabajo dispuesto a rebajar el coste empresarial de las bajas, pero a trav�s del re', 'Europa press', '<p>El Ministerio de Trabajo e Inmigraci&oacute;n se mostr&oacute; hoy dispuesto a reducir el coste empresarial que pagan las empresas por la baja laboral a trav&eacute;s de la reducci&oacute;n del fraude, aunque no descart&oacute; la posibilidad de recortar el n&uacute;mero de d&iacute;as de las bajas que costean las empresas y trasladar parte de ese gasto a la Seguridad Social.</p>', '', '', '4a3b5fbb5800d.pdf', '2009-06-19', '2009-06-19', '2009-06-24', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-19 11:51:55', NULL, 0);
INSERT INTO `noticia` VALUES (51, 'La Mutua FREMAP profundiza en los riesgos laborales en Talavera', 'dclm', '<p>La Mutua de Accidentes de Trabajo y Enfermedades Profesionales FREMAP, ha organizado una jornada sobre prevenci&oacute;n de riesgos laborales en Talavera de la Reina (Toledo).</p>', '', '4a3b6013d4458.jpg', '4a3b6013d925f.pdf', '2009-06-19', '2009-06-19', '2009-06-24', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-19 11:53:23', NULL, 0);
INSERT INTO `noticia` VALUES (52, 'Fremap celebra en Almendralejo su Junta Asesora Regional', 'FREMAP', '<p>El acto cont&oacute; con la asistencia del alcalde de la localidad, D. Jos&eacute; Mar&iacute;a Ram&iacute;rez Mor&aacute;n</p>', '<p>El pasado d&iacute;a 16 de Junio, Fremap celebr&oacute; la Junta Asesora Regional en la localidad de Almendralejo.  En su intervenci&oacute;n, el alcalde local, Sr. Ram&iacute;rez Mor&aacute;n, aplaudi&oacute; la idea de descentralizar este tipo de actos para que todas las localidades extreme&ntilde;as puedan ser anfitrionas de los mismos. Los datos nacionales de la Entidad fueron expuestos por el Presidente de la Junta Asesora de Extremadura, D. Ignacio Miguel Romero, mientras que los datos de Extremadura fueron expuestos por el Director Regional, Sr. Correa Galindo. Cabe destacar que de los datos presentados se deduce un crecimiento cercano al 10% en los ingresos de la Entidad en Extremadura, a pesar de la crisis econ&oacute;mica en 2008. El n&uacute;mero de trabajadores protegidos en la Comunidad asciende a 103.000</p>', '', '', '2009-06-22', '2009-06-22', '2009-06-27', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-22 09:06:34', NULL, 0);
INSERT INTO `noticia` VALUES (53, 'Los accidentes laborales cuestan 1.816 millones de euros anuales en Catalu�a ', 'abc', '<p>Tambi&eacute;n en t&eacute;rminos econ&oacute;micos, los trabajadores son quienes asumen la mayor parte del coste de los accidentes: 1.175 millones de euros, lo que supone un 62,6% de los 1.876 del gasto total. Hasta ahora, no se hab&iacute;a cuantificado el coste de la siniestralidad laboral, tanto para los trabajadores como para las  empresas y la sociedad en general.</p>', '', '', '4a3f4c6380077.pdf', '2009-06-22', '2009-06-22', '2009-06-27', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-22 11:18:27', NULL, 0);
INSERT INTO `noticia` VALUES (54, 'Empresarios, economistas y oposici�n claman por una reforma laboral', 'abc', '<p>La crisis econ&oacute;mica ha dado lugar a una extensa producci&oacute;n acad&eacute;mica sobre las posibles soluciones a la actual situaci&oacute;n. Economistas,empresarios, trabajadores aut&oacute;nomos, analistas y otros sectores de la sociedad civil coinciden en la necesidad de hacer reformas estructurales, y la m&aacute;s urgente: el mercado laboral, lo que no tienen tan claro los sindicatos.</p>', '', '', '4a3f4cf84253c.pdf', '2009-06-21', '2009-06-21', '2009-06-26', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-22 11:20:56', NULL, 0);
INSERT INTO `noticia` VALUES (55, 'Erradicar el absentismo laboral supone un ahorro de 365 euros por persona al a�o', 'Diariocr�tico', '<p>El director general de Trabajo, Cooperativismo y Econom&iacute;a Social, Rom&aacute;n Ceballos, ha declarado este martes que erradicar el absentismo laboral, con un gasto del 1,7 por ciento del Producto Interior Bruto Anual (PIB) en la Comunitat Valenciana \\"supondr&iacute;a a un ahorro para la sociedad de 365 euros por habitante\\".</p>', '', '', '4a421c319e265.pdf', '2009-06-24', '2009-06-24', '2009-06-29', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-24 14:29:37', NULL, 0);
INSERT INTO `noticia` VALUES (56, 'La reducci�n del Absentismo como v�a para mejorar la competitividad', 'UMIVALE', '', '', '4a4871839c1c6.jpg', '4a447368977a4.pdf', '2009-06-29', '2009-06-29', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-26 09:06:16', NULL, 0);
INSERT INTO `noticia` VALUES (57, 'Mutua Universal a la vanguardia de la ergonom�a en el sector de la construcci�n', 'MUTUA UNIVERSAL', '<p>El Manual de buenas pr&aacute;cticas ergon&oacute;micas en el sector de la Construcci&oacute;n, elaborado por el Dpto. de I+D de la Direcci&oacute;n de Prevenci&oacute;n y Productos de Mutua Universal, ha recibido el reconocimiento a su calidad y gran utilidad por parte de la Inspecci&oacute;n de Trabajo de la Seguridad Social de Madrid.</p>', '<p>Los Inspectores de la citada unidad est&aacute;n utilizando la gu&iacute;a en las auditor&iacute;as que realizan a las empresas constructoras, entre ellas, 4 de las m&aacute;s grandes del pa&iacute;s y que se hallan incluidas en la Campa&ntilde;a APS de Alta Siniestralidad de &aacute;mbito nacional.  La Jefa de la Unidad de Prevenci&oacute;n de la ITSS lo ha recomendado, a su vez, a otros inspectores de construcci&oacute;n de todo el pa&iacute;s. El manual se est&aacute; convirtiendo en una referencia obligada en materia de buenas pr&aacute;cticas ergon&oacute;micas en el sector de la construcci&oacute;n.  Este manual es el resultado de un proyecto desarrollado, durante el a&ntilde;o 2005, de forma conjunta por el Laboratorio de Ergonom&iacute;a de Mutua Universal y la Fundaci&oacute;n Laboral de la Construcci&oacute;n de Navarra y fue financiado por el Instituto Navarro de Salud Laboral.  La finalidad del mismo es poner a disposici&oacute;n de las empresas pymes y trabajadores aut&oacute;nomos del sector de la construcci&oacute;n, una colecci&oacute;n de buenas pr&aacute;cticas ergon&oacute;micas &uacute;tiles para dar una respuesta inmediata y eficaz al problema de los riesgos ergon&oacute;micos en este sector.   En opini&oacute;n de Eduard Garriga, Director Gerente de Mutua Universal: Nos satisface especialmente ver que los estudios desarrollados por nuestro Laboratorio de Ergonom&iacute;a se convierten en un referente para la Inspecci&oacute;n de Trabajo de toda Espa&ntilde;a y son de gran utilidad para preservar la salud laboral de quienes trabajan en el sector de la construcci&oacute;n, uno de los que m&aacute;s cr&iacute;ticos en este sentido.</p>', '4a4c5da4bef79.jpg', '', '2009-06-30', '2009-06-30', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-06-30 11:20:14', NULL, 0);
INSERT INTO `noticia` VALUES (58, 'Umivale presenta en la AEB su metodolog�a para evaluar el atraco como riesgo laboral', 'UMIVALE', '', '', '4a4daa07cd17b.jpg', '4a4cbfba581b6.pdf', '2009-07-02', '2009-07-02', '2009-07-07', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-02 16:10:02', NULL, 0);
INSERT INTO `noticia` VALUES (59, 'Mutua Universal convoca 15 plazas de MIR en Medicina del Trabajo', 'MUTUA UNIVERSAL', '<p>En 2009 acaban su residencia la primera promoci&oacute;n &iacute;ntegramente formada en Mutua Universal de m&eacute;dicos MIR</p>', '<p>Mutua Universal ha convocado este a&ntilde;o 15 plazas de M&eacute;dico Interno Residente (MIR) en la Especialidad de Medicina del Trabajo, iniciativa que se inici&oacute; ya en el a&ntilde;o 2005.  Este a&ntilde;o, por tanto, acaba su per&iacute;odo de residencia la primera promoci&oacute;n de residentes especializados en Medicina del Trabajo, &iacute;ntegramente formados en Mutua Universal.   El programa se lleva a cabo en las Comunidades Aut&oacute;nomas de Andaluc&iacute;a, Arag&oacute;n, Catalu&ntilde;a, Castilla-La Mancha, Galicia, La Rioja y Madrid, en colaboraci&oacute;n con la pr&aacute;ctica totalidad de las unidades docentes de Espa&ntilde;a en esta especialidad.  La especializaci&oacute;n comienza con un periodo de formaci&oacute;n te&oacute;rica en las Escuelas de Medicina del Trabajo, continuando posteriormente con las rotaciones en las diversas especialidades m&eacute;dicas que integran el programa MIR, dando m&aacute;s relevancia a la asistencia primaria y traumatolog&iacute;a que se realizan en Mutua Universal, as&iacute; como la Vigilancia de Salud que se lleva a cabo en las instalaciones de Unipresalud. Los residentes tambi&eacute;n realizan rotaciones hospitalarias en las especialidades de oftalmolog&iacute;a, dermatolog&iacute;a, otorrinolaringolog&iacute;a y salud mental.  Seg&uacute;n Eduard Garriga, Director Gerente de Mutua Universal: Esta iniciativa se enmarca dentro de nuestro programa de RSC y nos sentimos muy orgullosos de contribuir a formar a futuros especialistas en Medicina del Trabajo.</p>', '4a51f3c301b22.jpg', '', '2009-07-06', '2009-07-06', '2009-07-11', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-06 14:53:23', NULL, 0);
INSERT INTO `noticia` VALUES (60, 'Fremap premia al Colegio de Madrid', 'Mercado de dinero', 'El presidente de la Mutua hizo un llamamiento a la Administraci�n para que flexibilice la normativa que regula a las Mutuas', '', '4a533d54e543a.jpg', '4a533d54e92a4.pdf', '2009-07-07', '2009-07-07', '2009-07-12', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-07 14:19:32', NULL, 0);
INSERT INTO `noticia` VALUES (61, 'M�s de medio mill�n de aut�nomos ya tienen cubiertas las coberturas por accidente de trabajo', 'Solos', '<p>El 68% de ellos son hombres y el resto de los afiliados que han accedido voluntariamente a esta cobertura son trabajadoras por cuenta propia</p>', '', '', '4a54599bb7d8f.pdf', '2009-07-08', '2009-07-08', '2009-07-13', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-08 10:32:27', NULL, 0);
INSERT INTO `noticia` VALUES (62, 'Trabajo liberaliza los servicios de prevenci�n de las Mutuas', 'Cinco D�as', '<p>La principal novedad es que permitir&aacute; a las entidades de prevenci&oacute;n de riesgos que las Mutuas segregaron de su actividad en 2006 trabajar con todas las empresas y no s&oacute;lo con sus empresas asociadas, como ocurre ahora.</p>', '', '', '4a545a2172a10.pdf', '2009-07-08', '2009-07-08', '2009-07-13', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-08 10:34:41', NULL, 0);
INSERT INTO `noticia` VALUES (63, 'Jornadas T�cnicas  de  Prevenci�n Primer Semestre 2009', 'FREMAP', '<p>Alcanzado el ecuador del ejercicio, el balance del ciclo \\"Jornadas T&eacute;cnicas de Fremap 2009\\" es altamente satisfactorio</p>', '<p>El ciclo de &ldquo;Jornadas T&eacute;cnicas enero-junio 2009&rdquo; que, con un alto nivel de especializaci&oacute;n y un enfoque eminentemente pr&aacute;ctico, y dirigidas a facilitar la actualizaci&oacute;n t&eacute;cnica de los profesionales de la prevenci&oacute;n, directivos y mandos de las empresas asociadas, e impartido por t&eacute;cnicos de prevenci&oacute;n de FREMAP, ha concluido con un notable &eacute;xito. El ciclo correspondiente a este primer semestre comprend&iacute;a 47 t&iacute;tulos, que se han impartido por todo el territorio en un total de 147 jornadas, alcanzando una presencia media superior a los 55 asistentes. La difusi&oacute;n, tanto del calendario como de la convocatoria de cada una de las jornadas, se ha efectuado mediante el &ldquo;Servicio de Informaci&oacute;n de Prevenci&oacute;n de FREMAP&rdquo;, que en la actualidad supera los 20.000 inscritos y permite, adem&aacute;s, enviar la documentaci&oacute;n de cada jornada a los asistentes de la misma por correo electr&oacute;nico, en las fechas siguientes a su celebraci&oacute;n.  El Servicio de Informaci&oacute;n de Prevenci&oacute;n de Fremap es gratu&iacute;to y le permite estar permanentemente informado de las diferentes convocatorias para participar en estas Jornadas T&eacute;cnicas, visualizando con anterioridad el contenido de la misma, ubicaci&oacute;n, programa, etc. Ud. Puede suscribirse gratuitamente a nuestro servicio accediendo al siguiente enlace y cumplimentando los datos en &eacute;l contenidos  http://www.fremap.es/FAPB.WebBolSus.PAlta/FAlta.aspx</p>', '4a56e7cf4b4d8.jpg', '', '2009-07-09', '2009-07-09', '2009-07-14', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-09 15:58:45', NULL, 0);
INSERT INTO `noticia` VALUES (64, 'El centro asistencial de Fremap comenzar� a funcionar en 2010', 'el diario Monta�es', '<p>Se ubicar&aacute; en La Albericia, en una parcela de 1.800 metros cuadrados, y dar&aacute; cobertura a 28.000 trabajadores</p>', '', '4a5af099d5952.jpg', '4a5af099da761.pdf', '2009-07-13', '2009-07-13', '2009-07-18', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-13 10:30:17', NULL, 0);
INSERT INTO `noticia` VALUES (65, 'Compromiso con la integraci�n laboral', 'FREMAP', '<p>En 2008 Fremap realiz&oacute; 8.932 acciones formativas a accidentados de trabajo en los que se preve&iacute;an secuelas incapacitantes para el trabajo habitual.</p>', '', '4a5c286338204.jpg', '4a5b21c20de03.pdf', '2009-07-13', '2009-07-13', '2009-07-18', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-13 14:00:02', NULL, 0);
INSERT INTO `noticia` VALUES (66, 'Asepeyo y Fraternidad Muprespa firman un convenio de colaboraci�n para compartir recursos asistencia', 'ASEPEYO', '<p>M&aacute;s de 3.800.000 trabajadores afiliados se beneficiar&aacute;n de las instalaciones de ambas mutuas</p>', '<p>Asepeyo y Fraternidad Muprespa han suscrito un concierto de colaboraci&oacute;n que tiene como objetivo ofrecer una mejor cobertura sanitaria a los trabajadores de las m&aacute;s de 644.000 empresas asociadas a ambas mutuas.  Este convenio, aprobado el pasado 6 de julio por el Ministerio de Trabajo e Inmigraci&oacute;n,  permitir&aacute; priorizar la dispensaci&oacute;n sanitaria con los medios propios de los que disponen las dos entidades, optimizando la gesti&oacute;n de recursos p&uacute;blicos mediante la puesta en com&uacute;n de medios y servicios.   Los trabajadores afiliados a las dos mutuas, m&aacute;s de 3.800.000, podr&aacute;n beneficiarse de la prestaci&oacute;n sanitaria que ofrecen las dos entidades, bas&aacute;ndose fundamentalmente en razones de proximidad. Este hecho supondr&aacute; acercar la actividad asistencial al usuario final para lograr su plena recuperaci&oacute;n, ofreci&eacute;ndole un servicio m&aacute;s eficaz, as&iacute; como reducir los costes sanitarios derivados de la siniestralidad laboral.   La implantaci&oacute;n de este convenio se har&aacute; de forma paulatina, y repercutir&aacute; en toda la red asistencial de ambas mutuas, que se extiende a nivel nacional. Las dos entidades suman 276 instalaciones, entre centros asistenciales, hospitales y centros de rehabilitaci&oacute;n, y pondr&aacute;n a disposici&oacute;n de sus trabajadores afiliados todos sus medios asistenciales: la asistencia hospitalaria, ambulatoria y recuperadora para la prestaci&oacute;n m&eacute;dica por accidentes de trabajo y enfermedades profesionales.   Jorge Serra, director gerente de Asepeyo y Fernando Eguidazu, director gerente de Fraternidad Muprespa, han firmado este concierto, que sigue la voluntad del Ministerio de Trabajo e Inmigraci&oacute;n, quien propone que las mutuas prioricen la dispensaci&oacute;n de la asistencia sanitaria con medios propios o a trav&eacute;s de conciertos con otras mutuas.</p>', '4a5d7a884b359.jpg', '4a5c6d69d52fa.doc', '2009-07-14', '2009-07-14', '2009-07-19', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-14 13:35:05', NULL, 0);
INSERT INTO `noticia` VALUES (67, 'Absentismo Laboral: Causas y soluciones', 'UMIVALE', '<p>El pasado 7 de julio, en el Sal&oacute;n de Plenos del Ayuntamiento de Algete y organizada por Umivale y la Asociaci&oacute;n de Empresarios (ASPEMA), se celebro, con gran &eacute;xito una Jornada sobre el Absentismo Laboral: Causas y Soluciones. La bienvenida y apertura del acto corrieron a cargo de D. Emilio Iv&aacute;n Monasterio L&oacute;pez. Concejal de Comercio e Industria del Ilmo. Ayuntamiento de Algete, D. David S&aacute;nchez Pascual, Presidente de ASPEMA y D. Armando Lanuza Torre, Director del &Aacute;rea Corporativa de umivale.</p>', '', '4a5ed0ee01da6.jpg', '4a5ddd3b50c56.pdf', '2009-07-15', '2009-07-15', '2009-07-20', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-15 15:44:27', NULL, 0);
INSERT INTO `noticia` VALUES (68, 'Ibermutuamur aportar� 83 millones de euros a la Seguridad Social', 'Europa Press', '<p>La Mutua aportar&aacute; 83 millones al Sistema de Protecci&oacute;n Social, de forma que &eacute;ste ser&aacute; el quinto a&ntilde;o consecutivo que la Mutua colabora de forma simult&aacute;nea con el Fondo de Prevenci&oacute;n y de Reabilitaci&oacute;n, al que aportar&aacute; 82,2 millones, y con el Fondo de Reserva de la Seguridad Social, que recibir&aacute; 0,66 millones de euros</p>', '', '4a5ef2bde89e8.jpg', '4a5ef2bdec854.pdf', '2009-07-16', '2009-07-16', '2009-07-21', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-16 11:28:29', NULL, 0);
INSERT INTO `noticia` VALUES (69, 'Asepeyo aumenta un 2,9% el n�mero de empresas asociadas dando cobertura a m�s de 2,3 millones de tra', 'Expansi�n.com', '<p>Durante el 2008 la Mutua aument&oacute; un 2,9% el n&uacute;mero de empresas asociadas, que suman un total de 334.964. El n&uacute;mero de trabajadores afiliados a los que presta covertura asciende a 2,3 millones</p>', '', '4a5ef36b9e6a7.jpg', '4a5ef36ba34ae.pdf', '2009-07-16', '2009-07-16', '2009-07-21', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-16 11:31:23', NULL, 0);
INSERT INTO `noticia` VALUES (70, 'Umivale obtiene un ingreso de 437 millones de euros en 2008', 'UMIVALE', '<p>El n&uacute;mero de trabajadores protegidos por la entidad asciende a 528.329 por Accidentes de Trabajo y Enfermedades Profesionales y a 413.238 trabajadores por Contingencias Comunes. Gracias, entre otros factores, a la eficacia de las pol&iacute;ticas de prevenci&oacute;n llevadas a cabo por la Mutua, el &iacute;ndice de incidencia en siniestralidad laboral descendi&oacute; un 14,9%</p>', '', '4a6443ffe1f39.jpg', '4a6439312d268.pdf', '2009-07-20', '2009-07-20', '2009-07-25', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-20 11:30:25', NULL, 0);
INSERT INTO `noticia` VALUES (71, 'III Campa�a de recogida de pr�tesis y �rtesis', 'FREMAP', '<p>Los empleados de Fremap comprometidos con la Acci&oacute;n Social Empresarial</p>', '<p>FREMAP inicia su tercera campa&ntilde;a de recogida de pr&oacute;tesis y &oacute;rtesis. La campa&ntilde;a, que fue exitosa en sus dos primeras ediciones, pretende aprovechar este tipo de material para dotarle de un destino m&aacute;s &uacute;til ayudando a que se puedan beneficiar de &eacute;l personas menos favorecidas.  Para la ejecuci&oacute;n de esta campa&ntilde;a se cuenta con la colaboraci&oacute;n de las siguientes entidades:  1&ordm;.- Amputats de Sant Jordi; Es una fundaci&oacute;n que recicla material prot&eacute;sico y ort&eacute;sico y que lo enviar&aacute;n a distintas ONGs cuya labor se desarrolla principalmente en el continente africano. 2&ordm;.- MRW; Que se encarga de gestionar el env&iacute;o de material a sus destinos de manera solidaria y gratu&iacute;ta  Este proyecto se inicia una vez finalizada la campa&ntilde;a: \\"un empleado, un euro\\", que ha tenido un importante &eacute;xito y por el cual se ha podido dotar de utillaje de trabajo y herramientas agr&iacute;colas a la cooperativa de mujeres Thinza en Mauritania. Todo ello con el fin de que estas mujeres pudieran labrar su propia tierra y abastecer as&iacute; a sus familias y peque&ntilde;os comercios.  Todos los proyectos solidarios arrancan con una gran ilusi&oacute;n y permiten a los empleados de FREMAP vivir en primera persona el beneficio de aportar su granito de arena a la sociedad.</p>', '4a66c7cc700f1.jpg', '', '2009-07-20', '2009-07-20', '2009-07-25', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-20 13:00:40', NULL, 0);
INSERT INTO `noticia` VALUES (73, 'Asepeyo disminuye en un 10% la siniestralidad de sus empresas mutualistas', 'ASEPEYO', '<p>La Mutua ha celebrado su Junta General de Mutualistas, en la que se han aprobado los resultados del ejercicio 2008  La entidad aumenta en un 3% el n&uacute;mero de empresas asociadas en accidentes de trabajo, con un total de 2.392.687 trabajadores afiliados</p>', '<p>Asepeyo ha celebrado  en el Hospital Asepeyo Sant Cugat su Junta General de Mutualistas, donde Leopoldo Rod&eacute;s, presidente de la Mutua, y Jorge Serra, director gerente, han presentado los resultados del ejercicio 2008.   Durante el a&ntilde;o pasado, la Mutua, que cuenta con una plantilla de 3.610 profesionales, ha disminuido en un 10% los casos con baja por cada 100 trabajadores (tasa de incidencia) de sus empresas mutualistas. Esta disminuci&oacute;n ha sido posible gracias a las actividades preventivas desarrolladas con cargo a cuotas de la Seguridad Social, as&iacute; como a la aplicaci&oacute;n de medidas de seguridad y salud laboral eficientes por parte de las empresas.  En 2008, el n&uacute;mero de empresas mutualistas ha ascendido a 334.964, lo que supone un aumento  del 2,9% respecto al ejercicio anterior, y el n&uacute;mero de trabajadores afiliados ha sido de 2.392.687, un 2,1% m&aacute;s. Este incremento demuestra la eficaz gesti&oacute;n desarrollada por la Mutua, teniendo en cuenta la situaci&oacute;n econ&oacute;mica actual y el consecuente descenso de trabajadores afiliados a la Seguridad Social durante el a&ntilde;o pasado.   Los ingresos totales obtenidos por la Mutua han sido 2.016,5 millones de euros, cifra que representa un aumento del 5,3% respecto al a&ntilde;o anterior. El excedente final, despu&eacute;s de dotar las reservas obligatorias, ha sido de 202,5 millones de euros.   De la parte del excedente que corresponde a accidente de trabajo, el 80% se destina al Fondo de Prevenci&oacute;n y Rehabilitaci&oacute;n. En este ejercicio ha supuesto un importe de 140,3 millones de euros. El 10%, 17,5 millones de euros, va dirigido al Fondo de Reservas Voluntarias, y el 10% restante, otros 17,5 millones de euros, al Fondo de Asistencia Social, que ofrece ayudas econ&oacute;micas, servicios y atenci&oacute;n al trabajador accidentado o a su familia, en determinados casos de necesidad. La Comisi&oacute;n de Prestaciones Especiales de Asepeyo, &oacute;rgano que gestiona este Fondo, ha celebrado 25 a&ntilde;os de existencia, durante los cuales ha otorgado m&aacute;s de 28,3 millones de euros, con un total de 20.462 casos atendidos de trabajadores que han sufrido un accidente de trabajo o enfermedad profesional. Asimismo, se han destinado 5,4 millones de euros al Fondo de Reserva de la Seguridad Social.   Por otro lado, este a&ntilde;o Asepeyo ha firmado un convenio marco de colaboraci&oacute;n con Mutua Balear que establecer&aacute;, paulatinamente, sucesivos acuerdos en temas propios de la actividad de las mutuas. De momento, fruto de este acuerdo, las dos mutuas ponen a disposici&oacute;n de los m&aacute;s de 2,5 millones de trabajadores de sus empresas mutualistas los servicios asistenciales de ambas entidades.   Asimismo, Asepeyo y Fraternidad Muprespa han suscrito tambi&eacute;n un concierto de colaboraci&oacute;n, que tiene como objetivo ofrecer una mejor cobertura sanitaria a los trabajadores de las m&aacute;s de 635.100 empresas asociadas a ambas mutuas.   Gracias a estos convenios, los trabajadores afiliados de Asepeyo podr&aacute;n hacer uso de las instalaciones asistenciales de Mutua Balear y de Fraternidad Muprespa, por lo que tendr&aacute;n a su disposici&oacute;n 288 centros en todo el territorio nacional, con todos sus medios asistenciales: la asistencia hospitalaria, ambulatoria y recuperadora para la prestaci&oacute;n m&eacute;dica por accidentes de trabajo y enfermedades profesionales.   Ambos acuerdos han sido aprobados por el Ministerio de Trabajo e Inmigraci&oacute;n, que propone a las mutuas que prioricen la dispensaci&oacute;n de la asistencia sanitaria con medios propios o a trav&eacute;s de conciertos con otras mutuas.</p>', '4a656aaee94b4.jpg', '', '2009-07-20', '2009-07-20', '2009-07-25', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-20 13:41:07', NULL, 0);
INSERT INTO `noticia` VALUES (74, 'Mutua Universal a la vanguardia de la ergonom�a en el sector de la construcci�n', 'RRHH Digital', '<p>El manual de buenas pr&aacute;cticas ergon&oacute;micas en el sector de la construcci&oacute;n, elaborado por el departamento de I+D de la direcci&oacute;n de prevenci&oacute;n y productos de Mutua Universal, ha recibido el reconocimiento a su calidad y gran utilidad por parte de la Inspecci&oacute;n de Trabajo de la Seguridad Social de Madrid</p>', '', '4a6831da3c209.jpg', '4a6831da3f0db.pdf', '2009-07-23', '2009-07-23', '2009-07-28', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-23 11:48:10', NULL, 0);
INSERT INTO `noticia` VALUES (75, 'La prevenci�n en �poca de crisis', 'Pere Teixido- Mutua Universal', '', '<p>Este art&iacute;culo es el fruto de la observaci&oacute;n de algunas reacciones ocurridas en el &aacute;mbito empresarial, tanto espa&ntilde;ol como europeo, en las cuales se manifestaba una preocupaci&oacute;n por adecuar las actuaciones en prevenci&oacute;n de riesgos laborales a la actual crisis econ&oacute;mica o en una expresi&oacute;n m&aacute;s coloquial a la situaci&oacute;n de vacas flacas. Se trata de una preocupaci&oacute;n leg&iacute;tima que debe ser tomada en consideraci&oacute;n y resuelta por v&iacute;as algo m&aacute;s sofisticadas que las del puro recorte.  Se propone una reflexi&oacute;n sobre la forma en que se producen y se propagan las crisis, las consecuencias que acarrean y el riesgo de tomar decisiones equivocadas que conduzcan a inhabilitar precisamente los mecanismos que las empresas tienen para hacer frente a situaciones cr&iacute;ticas.   La reflexi&oacute;n se apoya en conceptos de la teor&iacute;a de la complejidad y de la teor&iacute;a de las redes aplicados a las organizaciones empresariales, de los cuales se da una informaci&oacute;n sucinta que, quien dese&eacute;, podr&aacute; ampliar con la bibliograf&iacute;a que se cita al final; pero se pasa r&aacute;pidamente a tratar los aspectos m&aacute;s pr&aacute;cticos y operativos.   Entre estos &uacute;ltimos est&aacute; el papel que la prevenci&oacute;n juega no s&oacute;lo en la reducci&oacute;n del gasto, sino tambi&eacute;n en el desarrollo de negocio, papel que para desplegarse requiere superar la etapa de la prevenci&oacute;n por obligaci&oacute;n y acceder a &ldquo;La prevenci&oacute;n seg&uacute;n necesidades&rdquo;.  Se brinda una breve rese&ntilde;a del marco propicio para lo anterior en materia de estrategia europea y espa&ntilde;ola, as&iacute; como en avances de sistemas de aseguramiento que contemplan tanto la inclusi&oacute;n de la prevenci&oacute;n entre sus prestaciones, como la repercusi&oacute;n de sus resultados en la mec&aacute;nica de cotizaci&oacute;n.  Se informa sobre las principales disposiciones de la Orden TAS/3623/2006, que facilitan la cooperaci&oacute;n de las Mutuas de Accidentes de Trabajo con sus asociados en este paso hacia la actuaci&oacute;n seg&uacute;n necesidades y se resalta como muestra de dicha cooperaci&oacute;n el Programa Prevea sobre el cual se ha dado extensa informaci&oacute;n en art&iacute;culos anteriores.  En s&iacute;ntesis se estimula a empresarios y trabajadores a hacer uso y sacar provecho en estas &eacute;pocas dif&iacute;ciles, de lo que las Mutuas est&aacute;n en condiciones de proporcionar y quieren proporcionar, por el hecho de compartir, la necesidad de reducir la siniestralidad al ser &eacute;sta una amenaza constante a la viabilidad de las empresas y a la sostenibilidad de las Mutuas.  Por &uacute;ltimo, se explica el modelo de trabajo que Mutua Universal ha elaborado al respecto de la prevenci&oacute;n seg&uacute;n necesidades y se da noticia de algunas de sus consecuencias en la forma de productos espec&iacute;ficos para la reducci&oacute;n de la siniestralidad y para la impulsi&oacute;n de una cultura, clima y pr&aacute;cticas laborales que proporcionen un ambiente capaz de promover la efectividad de la organizaci&oacute;n.</p>', '', '4a7031cb9ad8c.pdf', '2009-07-29', '2009-07-29', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-29 13:26:03', NULL, 0);
INSERT INTO `noticia` VALUES (76, 'Mutua Universal ha obtenido en el 2008 un excedente de 114,6 millones de euros', 'MUTUA UNIVERSAL', '<p>Con un total, a 31 de diciembre 2008, de 135.718 empresas asociadas y 1.339.382 personas protegidas, los ingresos por cuotas devengadas ascendieron a 1.056 millones de euros, con un excedente de 114,6 millones de euros (superior al 11% de dichas cuotas).</p>', '<p>Su solidez y autonom&iacute;a financieras quedan reflejadas en sus fondos propios, de 553,3 millones de euros, y en sus cuentas financieras, de 542,4 millones de euros.  Los excedentes generados permiten tener dotadas las reservas de Mutua Universal en los m&aacute;ximos permitidos por el Reglamento de Colaboraci&oacute;n y aportar al Sistema de la Seguridad Social m&aacute;s de 93,3 millones de euros, as&iacute; como realizar prestaciones complementarias.  Por su parte, la Comisi&oacute;n de Prestaciones Especiales de Mutua Universal concedi&oacute; cerca de 1,5 millones de euros en ayudas sociales de su Fondo de Asistencia Social, para atender 271 casos de trabajadores con enfermedad profesional o v&iacute;ctimas de accidente laboral, en circunstancias especiales que precisaban de un grado de asistencia mayor a la que ordinariamente facilita la Seguridad Social, lo que ha supuesto un incremento de la dotaci&oacute;n del mencionado Fondo en un  54% con respecto al a&ntilde;o anterior.  Mutua Universal ampli&oacute; su red de centros asistenciales en 14 nuevos centros, que alcanza en la actualidad los 142, mediante una inversi&oacute;n de 11,7 millones de euros. Su plantilla, a 31 de diciembre 2008, contaba con 1.991 profesionales.</p>', '4a7186f9c458f.jpg', '', '2009-07-30', '2009-07-30', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-07-30 13:41:14', NULL, 0);
INSERT INTO `noticia` VALUES (77, 'Un 20% de las bajas laborales son dudosas y tienen hasta un 30% de exceso en d�as de duraci�n', 'Europa Press', '<p>Hasta un 20% de las bajas laborales son dudosas y tienen hasta un 30% de exceso en d&iacute;as de duraci&oacute;n, seg&uacute;n ha afirmado hoy, citando estudios sobre el tema, el m&eacute;dico de familia Fernando Quijano, que ha impartido en los Cursos de Verano de la Universidad de Cantabria, en Laredo, la ponencia \\\'&iquest;S&eacute; lo que tengo que saber ante una incapacidad temporal?\\\', en la que abord&oacute; las bajas laborales y el papel de los m&eacute;dicos de cabecera.</p>', '', '', '4a7977de78248.pdf', '2009-08-05', '2009-08-05', '2009-08-10', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-08-05 14:15:26', NULL, 0);
INSERT INTO `noticia` VALUES (78, 'La Uni�n de Mutuas  ya protege a 342.699 trabajadores de m�s de 57.604 empresas asociadas', 'levante-emv.com', '<p>La Mutua destinar&aacute; cuatro millones de euros al fondo de reserva de las pensiones y 9 millones m&aacute;s a la Seguridad Social</p>', '', '', '4a7bd92894e9d.pdf', '2009-08-07', '2009-08-07', '2009-08-12', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-08-07 09:35:04', NULL, 0);
INSERT INTO `noticia` VALUES (79, 'Mutua Intercomarcal ha puesto en marcha un servicio de informaci�n espec�fico sobre las medidas prev', 'Europa Press', '<p>La mutua ha tomado esta decisi&oacute;n tras constatar \\"el gran desconocimiento existente\\" sobre las posibilidades de contagio, los s&iacute;ntomas y los protocolos a seguir en el entorno laboral.</p>', '', '', '4a9cd8eba3960.pdf', '2009-09-01', '2009-09-01', '2009-09-06', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-09-01 10:18:51', NULL, 0);
INSERT INTO `noticia` VALUES (80, 'Egarsat arranca un servicio de informaci�n sobre la Gripe A', 'Noticias Medicas.es', '<p>Egarsat ha puesto en funcionamiento un nuevo servicio de atenci&oacute;n destinado espec&iacute;ficamente a informar y orientar a sus empresas mutualistas y colaboradoras acerca de la Gripe A</p>', '', '', '4aa76ce7972f1.pdf', '2009-09-09', '2009-09-09', '2009-09-14', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-09-09 10:52:55', NULL, 0);
INSERT INTO `noticia` VALUES (81, 'Mutua Universal estrena web y zona privada', 'MUTUA UNIVERSAL', '<p>La nueva web prioriza la gesti&oacute;n de la relaci&oacute;n con los asociados y la informaci&oacute;n orientada a cada tipo de colectivo.</p>', '<p>Mutua Universal lanza hoy su nueva web y zona privada, dos potentes herramientas de gesti&oacute;n on line que facilitar&aacute;n a empresas asociadas, aut&oacute;nomos y profesionales laborales su relaci&oacute;n con Mutua Universal.  En los &uacute;ltimos meses, Mutua Universal ha procedido a revisar y reestructurar sus herramientas con sus asociados, al tiempo que proveerles de informaci&oacute;n segmentada acorde con sus necesidades e intereses.  De este modo seguimos situ&aacute;ndonos al lado de nuestros asociados, facilit&aacute;ndoles informaci&oacute;n y simplificando los tr&aacute;mites para apoyarles en la gesti&oacute;n administrativa de sus RRHH, ha declarado Miguel &Aacute;ngel Guzm&aacute;n, Director de Gesti&oacute;n y Desarrollo de Mutua Universal.</p>', '4ab89a80206f3.jpg', '4ab764c132aa7.jpg', '2009-09-21', '2009-09-21', '2009-09-26', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-09-21 13:34:25', NULL, 0);
INSERT INTO `noticia` VALUES (82, 'Acuerdo entre Mutua Egarsat y la Fundaci�n �logos para formar a trabajadores que hayan sufrido un ac', 'Negocios', '<p>El director general de la Mutua de Accidentes de Trabajo Egarsat, Albert Duaigues y el gerente de la Fundaci&oacute;n &eacute;logos, Aurelio Ladr&oacute;n de Guevara, han firmado un convenio en virtud del cual ambas entidades trabajar&aacute;n conjuntamente para ofrecer formaci&oacute;n a aquellos trabajadores que hayan sufrido un accidente laboral por el que no pueden volver a su puesto de trabajo, ya se trate de una situaci&oacute;n transitoria o definitiva. En el caso de no poder desempe&ntilde;ar sus anteriores funciones, los conocimientos ir&iacute;an especialmente orientados a formar al trabajador en un nuevo campo profesional, facilitando as&iacute;, en la medida de lo posible, su reincorporaci&oacute;n al mercado laboral.</p>', '', '4aba2b73ac68f.jpg', '4aba2b73b33e4.pdf', '2009-09-23', '2009-09-23', '2009-09-28', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-09-23 16:06:43', NULL, 0);
INSERT INTO `noticia` VALUES (83, 'Los empleados de FREMAP re�nen 3.000 euros para un proyecto que desarrolla C�ritas en Mauritania', 'FREMAP', '<p>Es otra iniciativa m&aacute;s de la Comisi&oacute;n de Acci&oacute;n Social de FREMAP, fieles a su compromiso con la Responsabilidad Social</p>', '<p>En el dia de ayer se hizo entrega por parte de Juan Carlos Perdomo -Director Regional de FREMAP- a D. Leonardo Ruiz -Director de CARITAS-, de un cheque por valor de 3.000 euros que fue recaudado entre todos los empleados de Fremap para donarlos a un proyecto que Caritas est&aacute; desarrollando en Mauritania. D. Leonardo Ruiz agradeci&oacute; a D. Juan Carlos Perdomo que dentro de su empresa se mantenga ese esp&iacute;ritu de Responsabilidad Social que impera entre todos los empleados de la M&uacute;tua, y espera que sirva de ejemplo para otras grandes organizaciones empresariales.   Este proyecto de &iacute;ndole social est&aacute; basado en la dotaci&oacute;n de material de utillaje y herramientas (carretillas, rastillos, palas, regaderas, alambrados, estacas etc. ) para que las mujeres Tinzah  puedan hacerse cargo de la alimentaci&oacute;n de sus familias mediante peque&ntilde;as granjas y huertos, y es financiado con aportaciones personales de los empleados de Fremap.  El proyecto se desarrolla en la regi&oacute;n de Gorgol al sur de Mauritania, a 450 km al sureste de Nouakchott. En dicha zona se est&aacute; sufriendo un aumento excesivo del coste de los productos de primera necesidad y este tipo de iniciativas permite a los colectivos m&aacute;s vulnerables como son las mujeres y ni&ntilde;os fijarse en su propia tierra.  En este tipo de sociedades matriarcales es fundamental el trabajo de la mujer para sacar adelante a sus hijos, la Cooperativa la componen 44 mujeres las cu&aacute;les son responsables de sus hogares y participan en la promoci&oacute;n de sus familias (alimentaci&oacute;n y educaci&oacute;n de sus hijas/os) trabajando a favor del desarrollo de su localidad luchando contra el &eacute;xodo rural. En total el n&uacute;mero de beneficiarios se extiende a 264 personas.  El importe que solicitaban para poder desarrollar el proyecto ascend&iacute;a la cantidad de 3.000&euro;. Por ello en FREMAP, que actualmente cuenta con una plantilla de m&aacute;s de 3.000 trabajadores se plantearon que si cada empleado don&aacute;ra un euro, podr&iacute;an conseguir que se hagan realidad los sue&ntilde;os de todas esas mujeres y poder as&iacute; ayudar al desarrollo de los pa&iacute;ses menos desarrollados que nosotros.  Esta campa&ntilde;a se desarroll&oacute; en todos los centros de FREMAP del 15 de junio al 30 de junio, ascendiendo la recaudaci&oacute;n a m&aacute;s de 3.000 euros. El proyecto fue denominado UN EMPLEADO UN EURO, y con la cantidad final recaudada se dotar&aacute; a estas 44 familias de financiaci&oacute;n suficiente para mantener a sus familias dignamente.</p>', '4abb166f8f500.jpg', '', '2009-09-24', '2009-09-24', '2009-09-29', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-09-24 08:49:19', NULL, 0);
INSERT INTO `noticia` VALUES (84, 'MAZ firma un convenio con el Gobierno de Arag�n para atender pacientes de traumatolog�a', 'MAZ', '<p>El pasado viernes d&iacute;a 5 de septiembre, Esteban Gil Bayona, Director Gerente de MAZ, firm&oacute;, junto con la Consejera de Salud y Consumo del Gobierno de Arag&oacute;n, Luisa Mar&iacute;a Noeno, el acuerdo de colaboraci&oacute;n que reconoce a la Mutua, concretamente a su Hospital de Zaragoza, y especialmente a su de Servicio de Traumatolog&iacute;a, para atender aquellas zonas de Arag&oacute;n que por circunstancias puntuales lo necesiten.</p>', '<p>El pasado viernes d&iacute;a 5 de septiembre, Esteban Gil Bayona, Director Gerente de MAZ, firm&oacute;, junto con la Consejera de Salud y Consumo del Gobierno de Arag&oacute;n, Luisa Mar&iacute;a Noeno, el acuerdo de colaboraci&oacute;n que reconoce a la Mutua, concretamente a su Hospital de Zaragoza, y especialmente a su de Servicio de Traumatolog&iacute;a, para atender aquellas zonas de Arag&oacute;n que por circunstancias puntuales lo necesiten.  Dado el car&aacute;cter de entidades colaboradoras en la gesti&oacute;n de la Seguridad Social de las mutuas de accidentes de trabajo en general, y de MAZ en particular, estos acuerdos cuentan con la ratificaci&oacute;n del Ministerio de Trabajo e Inmigraci&oacute;n, organismo del que depende la gesti&oacute;n de estas entidades.  Esto permite que la apuesta del Gobierno de Arag&oacute;n por la colaboraci&oacute;n con MAZ, complemente  la labor del Salud, con recursos de otras administraciones p&uacute;blicas.  Los acuerdos de colaboraci&oacute;n entre MAZ y el Gobierno de Arag&oacute;n no son nuevos, pues hay que recordar como ejemplo que la Mutua es miembro del Consorcio Aragon&eacute;s Sanitario de Alta Resoluci&oacute;n (CASAR) desde su constituci&oacute;n en Octubre de 2006, y en el que tambi&eacute;n participan el Gobierno de Arag&oacute;n y los ayuntamientos de Ejea de los Caballeros, Fraga, Jaca y Tarazona.   En el acto, Esteban Gil manifest&oacute; que es un honor para MAZ el inter&eacute;s del Gobierno de Arag&oacute;n por contar con nuestro hospital, cuyos medios, profesionales, capacidad de gesti&oacute;n,&hellip;, en definitiva prestigio, justificar&aacute;n -sin duda alguna- poder cumplir con los compromisos adquiridos con elevada solvencia y todo ello en beneficio de la Sociedad Aragonesa.  Igualmente, agradeci&oacute; a la Consejera del Dpto. de Salud y Consumo su confianza en MAZ, concretamente en nuestro hospital de Zaragoza.  Asimismo quiso reconocer a la Secretar&iacute;a de Estado de la Seguridad Social, de la que depende MAZ como Mutua de Accidentes de Trabajo, que haya posibilitado &ndash;junto con la mencionada Consejer&iacute;a- esta colaboraci&oacute;n que acabamos de establecer, tras el acuerdo marco de colaboraci&oacute;n que ambas firmaron el pasado 30 de abril.  Finalmente, aprovech&oacute; la oportunidad para felicitar a todos los profesionales del hospital MAZ, que realmente son los &ldquo;protagonistas&rdquo; de esta colaboraci&oacute;n, por su buen hacer d&iacute;a a d&iacute;a, dedicaci&oacute;n y en definitiva profesionalidad, agradeciendo su excelente colaboraci&oacute;n ante este nuevo reto.</p>', '4abcafd003dce.jpg', '', '2009-09-25', '2009-09-25', '2009-09-30', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-09-25 13:56:00', NULL, 0);
INSERT INTO `noticia` VALUES (85, 'Los empresarios de Guadalajara se preparan frente a la Gripe A', 'Cope.es', '<p>Los empresarios de Guadalajara, convocados por CSI-F y Mutua Universal, se han puesto al d&iacute;a sobre el plan de actuaci&oacute;n que deben llevar a cabo para afrontar la pandemia de Gripe A que podr&iacute;a afectar a sus plantillas. Los consejos preventivos y el protocolo de abordaje en caso de contagio en un centro de trabajo han sido los cap&iacute;tulos centrales de la jornada de puertas abiertas en la que no ha faltado la intervenci&oacute;n de un especialista en Medicina del Trabajo, Jes&uacute;s Serrano, con el que abr&iacute;amos nuestra particular consulta radiof&oacute;nica en La Ma&ntilde;ana en Guadalajara.</p>', '', '4aca1b0dc0ae4.jpg', '4ac47abb63fcd.pdf', '2009-10-01', '2009-10-01', '2009-10-06', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-01 11:47:39', NULL, 0);
INSERT INTO `noticia` VALUES (86, 'Los empresarios granadinos debaten sobre las novedades en riesgos laborales en un evento organizado ', 'Granadahoy.com', '<p>La Confederaci&oacute;n Granadina de Empresarios (CGE) acogi&oacute; ayer la jornada Incentivaci&oacute;n de la prevenci&oacute;n. C&oacute;mo estimular la Prevenci&oacute;n de Riesgos Laborales, organizada por MC Mutual en colaboraci&oacute;n con el Ayuntamiento de Granada, con el objetivo de difundir las &uacute;ltimas novedades y las reformas que se avecinan en la normativa estatal de Prevenci&oacute;n de Riesgos Laborales (PRL).</p>', '', '4ac47bc39c705.jpg', '4ac47b5a8c75a.pdf', '2009-10-01', '2009-10-01', '2009-10-06', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-01 11:50:18', NULL, 0);
INSERT INTO `noticia` VALUES (87, 'Uni�n de Mutuas, premiada con el sello EFQM', 'Las provincias.es', '<p>La ense&ntilde;a valenciana Uni&oacute;n de Mutuas ha conseguido el Sello de Plata de Excelencia Europea que concede el Club Excelencia en Gesti&oacute;n y la EFQM.</p>', '<p>Se trata del reconocimiento m&aacute;s prestigioso a nivel europeo que premia la eficacia de la mutua en su modelo de gesti&oacute;n de la calidad y certifica el alto nivel de los servicios sanitarios y asistenciales que la compa&ntilde;&iacute;a presta a los sectores empresariales, as&iacute; como la profesionalidad de los trabajadores.  La evaluaci&oacute;n externa se llev&oacute; a cabo por la entidad certificadora Aenor, quien concedi&oacute; a Uni&oacute;n de Mutuas una puntuaci&oacute;n de 400+ en su rango m&aacute;s elevado (el 450-500).</p>', '4acaee849dba6.jpg', '4acaee84a29bc.pdf', '2009-10-06', '2009-10-06', '2009-10-11', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-06 09:15:16', NULL, 0);
INSERT INTO `noticia` VALUES (88, 'MAZ ha publicado en su p�gina Web, www.maz.es, un espacio informativo sobre la Nueva Gripe A', 'MAZ', '<p>Sus contenidos est&aacute;n pensados para ayudar a las empresas y trabajadores en general a estar al d&iacute;a en la informaci&oacute;n y la prevenci&oacute;n de la pandemia de Gripe A.</p>', '<p>Este espacio recoge la informaci&oacute;n que semanalmente facilita el Ministerio de Sanidad y Consumo a trav&eacute;s de la Red de M&eacute;dicos Centinelas del Sistema de Vigilancia de Gripe en Espa&ntilde;a, cuyas cifras actualizadas muestran la evoluci&oacute;n de la pandemia. Igualmente se han publicado varios documentos informativos que la empresa se puede descargar, ayud&aacute;ndole a plantear diferentes acciones informativas y organizativas en sus centros de trabajo.  Tambi&eacute;n se pueden encontrar los enlaces a las p&aacute;ginas Web oficiales del Ministerio de Sanidad y Consumo y de las distintas CCAA.</p>', '4acb271441036.jpg', '4aded5c41d35f.pdf', '2009-10-21', '2009-10-21', '2009-10-26', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-06 13:16:36', NULL, 0);
INSERT INTO `noticia` VALUES (89, 'MC Mutual aprueba su Plan de Igualdad', 'MC MUTUAL', '<p>El documento, suscrito con el Comit&eacute; Intercentros de la entidad, fomenta la igualdad de trato y oportunidades entre todas las personas de la organizaci&oacute;n  La apuesta de MC MUTUAL por la conciliaci&oacute;n y la igualdad ha sido premiada en diversas ocasiones</p>', '<p>MC MUTUAL, mutua de accidentes de trabajo y enfermedades profesionales n&uacute;mero 1 de la Seguridad Social, ha suscrito un Plan de Igualdad de Oportunidades con el Comit&eacute; Intercentros de la organizaci&oacute;n.</p>', '4ace08cea04e3.jpg', '4ace08ceaa0d9.doc', '2009-10-08', '2009-10-08', '2009-10-13', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-08 17:44:14', NULL, 0);
INSERT INTO `noticia` VALUES (90, 'Mutua Universal asesora a los empresarios gallegos sobre la gripe A', 'La Opini�nCoru�a.es', '<p>Se trata de una jornada informativa desde una &oacute;ptica jur&iacute;dico-laboral, de prevenci&oacute;n, de organizaci&oacute;n y del plan de continuidad de sus negocios, a trav&eacute;s de una jornada informativa que tendr&aacute; lugar el pr&oacute;ximo 15 de octubre a las 12,30 horas en la sede en Vigo de la Mutua Universal (Plaza de Compostela, n&ordm; 26, bajo).</p>', '', '', '4acf184ad8079.pdf', '2009-10-09', '2009-10-09', '2009-10-14', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-09 13:02:34', NULL, 0);
INSERT INTO `noticia` VALUES (91, 'Asepeyo reduce un 13,14% la siniestralidad de sus empresas en Segovia', 'El Adelantado.com', '', '', '4ad48fe044673.jpg', '4ad48fe049484.pdf', '2009-10-13', '2009-10-13', '2009-10-18', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-13 16:34:08', NULL, 0);
INSERT INTO `noticia` VALUES (92, 'FREMAP firma un Acuerdo de colaboraci�n con la Fundaci�n Africa Directo', 'FREMAP', '<p>La firma del Acuerdo el pasado 2 de Octubre supone un nuevo compromiso de la mutua con la Acci&oacute;n Social Corporativa y el impulso de proyectos solidarios en favor de los m&aacute;s necesitados.</p>', '<p>El pasado d&iacute;a 2 de octubre tuvo lugar, en la Sede Central de FREMAP, la firma del acuerdo de colaboraci&oacute;n entre FREMAP, representada por su Director Gerente, Jes&uacute;s Mar&iacute;a Esarte Sola y la Fundaci&oacute;n &Aacute;frica Directo, siendo Jos&eacute; Mar&iacute;a M&aacute;rquez el firmante en calidad de Director General de la Fundaci&oacute;n.  La Fundaci&oacute;n &Aacute;frica Directo,  present&oacute; su proyecto &ldquo;Atupele&rdquo;, un Hospital rural al norte de Malawi, en cuya construcci&oacute;n tambi&eacute;n particip&oacute; FREMAP. El Concurso se resolvi&oacute; mediante la votaci&oacute;n de los empleados, que decidieron el proyecto, hacia el cual, la Acci&oacute;n Social de FREMAP, a trav&eacute;s de sus voluntarios, centrar&aacute; sus pr&oacute;ximos esfuerzos y campa&ntilde;as de sensibilizaci&oacute;n, difusi&oacute;n y financiaci&oacute;n.  Con la consecuci&oacute;n de este acuerdo, se pretende apoyar a este Hospital, que permite acercar la sanidad en un &aacute;rea de actuaci&oacute;n de 55.000 personas, sin medios econ&oacute;micos, invirtiendo adem&aacute;s, para que el proyecto, pueda desarrollar medios propios que lo haga sostenible por s&iacute; mismo en un futuro.  Al acto, acudieron adem&aacute;s, los miembros de la Comisi&oacute;n de Acci&oacute;n Social, constituida por empleados voluntarios de todas partes del pa&iacute;s, as&iacute; como el Subdirector General de Recursos Humanos, Alfonso Iglesias Pinuaga, y la Directora de Desarrollo de Personas Laura Albaizar.  Junto a ellos, el Director Gerente de FREMAP, transmiti&oacute;, su confianza en el proyecto, y su ilusi&oacute;n en dar un nuevo impulso a la Acci&oacute;n Social de FREMAP, la cual constituye un elemento esencial de la Responsabilidad Social que d&iacute;a a d&iacute;a se desarrolla en la Entidad.  Por su parte Jos&eacute; Mar&iacute;a M&aacute;rquez en nombre de &Aacute;frica Directo, la cual ya hab&iacute;a conseguido el segundo puesto en la III Convocatoria de Proyectos Solidarios, dijo sentirse, al venir a FREMAP, como en su propia casa, e hizo llegar el agradecimiento de aquellas personas de Malawi que ser&aacute;n los verdaderamente beneficiados por este acuerdo.   Con motivo de resultar segundo ganador, los empleados de FREMAP recaudaron en parte de sus campa&ntilde;as del a&ntilde;o anterior, la cantidad de tres mil seiscientos cincuenta euros, los cu&aacute;les les fueron entregados tras el acto de la firma.  Este d&iacute;a, que ser&aacute; recordado por todos, supone, una garant&iacute;a para el crecimiento del esp&iacute;ritu solidario y la implicaci&oacute;n por mejorar la sociedad, por parte de todos los implicados, y de todos aquellos que quieran adherirse a las iniciativas resultantes.</p>', '4ad59b7c3e2c5.jpg', '', '2009-10-14', '2009-10-14', '2009-10-19', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-14 11:35:56', NULL, 0);
INSERT INTO `noticia` VALUES (93, 'El Director de Prevenci�n de Mutua Universal, en el 2� Taller sobre Estrategias Nacionales de Seguri', 'MUTUA UNIVERSAL', '<p>El Director de Prevenci&oacute;n de Mutua Universal, Sr. Pere Teixido actu&oacute; como panelista, representando a Espa&ntilde;a en el 2&ordm; Taller sobre Estrategias Nacionales de Seguridad y Salud en el Trabajo, celebrado en Luxemburgo.</p>', '<p>El pasado 7 y 8 de octubre, se celebr&oacute; en Luxemburgo el 2&ordm; Taller sobre Estrategias Nacionales de Seguridad y Salud en el Trabajo, organizado por el Comit&eacute; Consultivo para la Seguridad y la Salud en el Puesto de Trabajo de la Direcci&oacute;n General de Empleo de la Comisi&oacute;n Europea. En dicho taller ha actuado como panelista, en representaci&oacute;n de Espa&ntilde;a, nuestro Director de Prevenci&oacute;n, Pere Teixid&oacute;, presentando la experiencia del dise&ntilde;o e impulsi&oacute;n del plan preVea como motor para aumentar la implicaci&oacute;n en la mejora de la siniestralidad. Expuso c&oacute;mo una iniciativa innovadora de Mutua Universal, el plan preVea, dise&ntilde;ada para incrementar la reducci&oacute;n de la siniestralidad mediante la acci&oacute;n voluntaria sustentada en la necesidad de actuar ante el reconocimiento de la existencia de un problema interno en la organizaci&oacute;n, como es la siniestralidad, que amenaza la sostenibilidad de la empresa. Ha pasado a ser una iniciativa p&uacute;blica apoyada por todos los agentes sociales e impulsada por la Inspecci&oacute;n de Trabajo, que se est&aacute; implantando en todas las comunidades aut&oacute;nomas espa&ntilde;olas.  Esta iniciativa forma parte de los objetivos de la estrategia espa&ntilde;ola de seguridad y salud en el trabajo 2007-2012, siendo su reto espec&iacute;fico la mejora efectiva de la siniestralidad mediante la aplicaci&oacute;n de la estrategia. La prioridad es la implicaci&oacute;n voluntaria de todos los actores relevantes impulsados por su necesidad de actuar. Durante la exposici&oacute;n, tambi&eacute;n se inform&oacute; de los resultados obtenidos por la actividad preventiva desarrollada por Mutua Universal durante los ejercicios 2007 y 2008. A t&iacute;tulo de resumen se explic&oacute; que, en el ejercicio 2008, se actu&oacute; en 5.530 empresas asociadas, consiguiendo una reducci&oacute;n de su &iacute;ndice de incidencia en un 19,9%, lo que supone haber evitado 3.665 casos de baja, equivalentes a un menor gasto para el sistema de Seguridad Social de m&aacute;s de 14 millones de euros, adem&aacute;s de una aportaci&oacute;n de 90.525 d&iacute;as de producci&oacute;n y una estimaci&oacute;n de m&aacute;s de 84 millones de euros de menor coste para las empresas. Considerando, adem&aacute;s, que el coste de las actividades preventivas desarrolladas ha sido de 5,4 millones de euros, podemos concluir que si se hubieran recortado, en lugar de ahorrar los 5,4 millones de euros, hubi&eacute;ramos incrementado el gasto en 8,6 millones de euros.</p>', '4ad7537501697.jpg', '', '2009-10-15', '2009-10-15', '2009-10-20', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-15 18:53:09', NULL, 0);
INSERT INTO `noticia` VALUES (94, 'Mutua Balear desarrolla e implanta un plan de actuaci�n frente a la Gripe A', 'Mutua Balear', '<p>Adem&aacute;s del plan de actuaci&oacute;n y prevenci&oacute;n desarrollado para los empleados,  Mutua Balear se ha comprometido a divulgar y promover todas las informaciones y actuaciones que los organismos oficiales soliciten.</p>', '<p>Siguiendo las recomendaciones del Ministerio de Sanidad y Pol&iacute;tica Social, Mutua Balear ha desarrollado e implantado un plan de actuaci&oacute;n y respuesta frente a la Gripe A (H1N1), con el objetivo de reforzar la protecci&oacute;n de la salud de sus empleados (algunos de ellos con alto riesgo de contagio), as&iacute; como minimizar los posibles efectos sociales y econ&oacute;micos asociados a dicha enfermedad.     Este plan de actuaci&oacute;n recoge medidas preventivas organizacionales, individuales y de comunicaci&oacute;n. Dentro del primer grupo, la empresa ha desarrollado un protocolo de actuaci&oacute;n frente a cualquier eventualidad relacionada con la Gripe A. En cuanto a las medidas individuales, todos los empleados han recibido formaci&oacute;n/informaci&oacute;n b&aacute;sica sobre la pandemia, as&iacute; como estrategias de protecci&oacute;n y respuesta tanto para individuos como para familias. La empresa ha reforzado la limpieza de las instalaciones y ha puesto a disposici&oacute;n de los trabajadores material para el control de la infecci&oacute;n (productos para la higiene de manos, desinfecci&oacute;n de superficies, pa&ntilde;uelos desechables&hellip;) en todos los lugares de trabajo. As&iacute; mismo, se han solicitado vacunas para los grupos sanitarios (considerados de alto riesgo).</p>', '4add594ae84fa.jpg', '4add594c2afbc.pdf', '2009-10-20', '2009-10-20', '2009-10-25', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-20 08:31:38', NULL, 0);
INSERT INTO `noticia` VALUES (95, 'Un alivio para las v�ctimas laborales', 'El Pa�s.com', '<p>Mutualia hace p&uacute;blico un fondo de 4,1 millones para mejorar la vida de los accidentados y sus familias</p>', '<p>Las obras de acondicionamiento de una vivienda para adaptarla a una silla de ruedas, los gastos de desplazamiento de la esposa y familiares de un accidentado, el alquiler de una vivienda para acompa&ntilde;ar al herido o enfermo, los gastos de la ayuda psicol&oacute;gica, una cama articulada, ayudas para cubrir gastos de fallecimiento.</p>', '4ae6d21741e8c.jpg', '4ae6d2174c6eb.pdf', '2009-10-27', '2009-10-27', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-27 11:57:27', NULL, 0);
INSERT INTO `noticia` VALUES (96, 'La Asociaci�n Industrial de Canarias y la Mutua Fremap firman un convenio para mejorar la seguridad ', 'Europa Press', '<p>La Asociaci&oacute;n Industrial de Canarias (Asinca) y la Mutua de Accidentes de Trabajo y Enfermedades Profesionales Fremap han suscrito un convenio de colaboraci&oacute;n para promocionar actuaciones conjuntas de informaci&oacute;n, asesoramiento, sensibilizaci&oacute;n y asistencia t&eacute;cnica en prevenci&oacute;n de riesgos laborales y mejorar, as&iacute;, la seguridad de las industrias del archipi&eacute;lago.</p>', '', '4ae6d3be2c7d3.jpg', '4ae6d3be3034d.pdf', '2009-10-27', '2009-10-27', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-27 12:04:30', NULL, 0);
INSERT INTO `noticia` VALUES (97, 'Las Mutuas invierten 77,8 millones en prevenci�n para evitar accidentes', 'Diario Critico.com', '<p>Prevenir en el trabajo ahorra m&aacute;s de 120 millones en prestaciones</p>', '<p>Siempre ha sido m&aacute;s barato prevenir que curar, ya sea en t&eacute;rminos humanos, sociales o econ&oacute;micos. Son muchos los beneficios que se derivan de la prevenci&oacute;n dirigida exclusivamente a reducir el n&uacute;mero de accidentes de trabajo. Esa es la prevenci&oacute;n que hacen las mutuas dentro de su funci&oacute;n de colaboraci&oacute;n con la Seguridad Social y de la que se derivan los suficientes beneficios humanos, sociales y econ&oacute;micos. Unas organizaciones poco conocidas para la sociedad.</p>', '', '4ae9acd395d04.pdf', '2009-10-29', '2009-10-29', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-29 15:55:15', NULL, 0);
INSERT INTO `noticia` VALUES (98, 'Veinte mil afectados por una medida considerada discrimintoria', 'Diario Critico.com', '<p>La Administraci&oacute;n quiere congelar los sueldos de los trabajadores de las Mutuas.</p>', '<p>Los trabajadores de las Mutuas de Accidentes de Trabajo se est&aacute;n viendo envueltos en un conflicto con el Ministerio de Trabajo, que trata de forzar discriminaciones salariales en relaci&oacute;n con los funcionarios de la Administraci&oacute;n P&uacute;blica . Un conflicto que podr&iacute;a llevar a m&aacute;s de veinte mil trabajadores a plantear demandas contra una desigualdad impuesta desde un Gobierno que, estiman, no ser&iacute;a competente en la materia.</p>', '', '4ae9ad3e98353.pdf', '2009-10-29', '2009-10-29', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-29 15:57:02', NULL, 0);
INSERT INTO `noticia` VALUES (99, 'El Gobierno reduce a la mitad la partida para prevenci�n de accidentes laborales', 'Diario Critico.com', '<p>Trabajo ultima el sistema de incentivos para prevenci&oacute;n de riesgos laborales</p>', '<p>Una resoluci&oacute;n del ministerio de Trabajo ha reducido a la mitad la cifra dedicada a prevenci&oacute;n de accidentes de trabajo, lo que ha causado una intensa preocupaci&oacute;n en el sector, seg&uacute;n reconocen en el Departamento que dirige Celestino Corbacho. Hasta el pasado mes de julio, se dedicaba a esta prevenci&oacute;n el 1%de la recaudaci&oacute;n de las mutuas de accidentes de trabajo, pero, desde este mes, una resoluci&oacute;n ministerial redujo este porcentaje al 0,5%.</p>', '', '4ae9ad9d5183b.pdf', '2009-10-29', '2009-10-29', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-29 15:58:37', NULL, 0);
INSERT INTO `noticia` VALUES (100, 'Las Mutuas proteger�n a 42.000 trabajadoras con prestaciones por riesgo durante el embarazo en 2009,', 'Europa Press', '<p>Las mutuas proteger&aacute;n a un total de 42.000 mujeres trabajadoras con prestaciones por riesgo durante el embarazo cuando finalice 2009, seg&uacute;n un estudio hecho p&uacute;blico hoy por la Asociaci&oacute;n de Mutuas de Accidentes de Trabajo (AMAT), del que se desprende que estos centros aumentaron un 436 por ciento el n&uacute;mero de servicios prestados, gracias a los 228 millones de euros invertidos desde marzo de 2007.</p>', '', '', '4ae9adfe75814.pdf', '2009-10-29', '2009-10-29', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-29 16:00:14', NULL, 0);
INSERT INTO `noticia` VALUES (101, 'Todos tenemos una Mutua que cuida de nosotros', 'Ejecutivos.es', '<p>Las Mutuas consolidan sus recursos asistenciales para cuidar de la salud de empresas y trabajadores</p>', '', '', '4ae9ae4fe18bd.pdf', '2009-10-29', '2009-10-29', '0000-00-00', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-10-29 16:01:35', NULL, 0);
INSERT INTO `noticia` VALUES (102, 'Mutualia incorpora en sus centros el diagn�stico radiol�gico por imagen digital', 'estrategia.net', '', '<p>Desde principios de octubre, Mutualia ha implantado una soluci&oacute;n de almacenamiento y comunicaci&oacute;n de im&aacute;genes radiol&oacute;gicas digitales que le ha permitido eliminar las tradicionales placas de rayos. El &Aacute;rea Sanitaria de la mutua l&iacute;der en el Pa&iacute;s Vasco, ha culminado con &eacute;xito el despliegue de este equipamiento avanzado de diagn&oacute;stico por imagen digital en la totalidad de sus centros, las cl&iacute;nicas Pakea (Donostia) y Ercilla (Bilbao), y en los 12 centros asistenciales repartidos por toda la geograf&iacute;a vasca. Los equipos de radiolog&iacute;a computerizada (CR) y los PACS (sistema de software para el archivo y comunicaci&oacute;n de las im&aacute;genes) han sido suministrados por la empresa Fujifilm. Las im&aacute;genes son capturadas digitalmente en el CR y a trav&eacute;s de los PACS son enviadas a un servidor central, al que cualquier facultativo desde cualquier punto de la red sanitaria de la entidad, con su perfil y contrase&ntilde;a de acceso, puede  acceder y visualizar las im&aacute;genes en su ordenador, con la consiguiente mejora de la calidad asistencial.  La apuesta de Mutualia por las nuevas tecnolog&iacute;as est&aacute; posibilitando el que m&eacute;dicos que trabajan en diferentes centros asistenciales, est&eacute;n visualizando al mismo tiempo en sus ordenadores im&aacute;genes radiol&oacute;gicas de pacientes en los que se puedan plantear dudas diagn&oacute;sticas o terap&eacute;uticas posibilitando por tanto una mayor certeza diagn&oacute;stica, evitando desplazamientos innecesarios al paciente y &ldquo;mejorando en suma tanto la calidad asistencial t&eacute;cnica, como la percibida&rdquo;, seg&uacute;n Andoni Foruria, director de Asistencia Sanitaria de Mutualia.  Los profesionales sanitarios pueden visualizar en tiempo real las pruebas realizadas en su ordenador a trav&eacute;s de una aplicaci&oacute;n especial conocida como visor, que incorpora funcionalidades como zoom, lupa, regla, variaci&oacute;n de brillos y la posibilidad de imprimir o exportar las im&aacute;genes a un CD.  Con este despliegue tecnol&oacute;gico, Mutualia ha hecho desaparecer el uso de productos qu&iacute;micos de contraste y revelado, eliminando la necesidad de reciclado de los mismos. El proceso de implantaci&oacute;n de este sistema de diagn&oacute;stico ha requerido la colaboraci&oacute;n del &aacute;rea de Sistemas de Informaci&oacute;n de Mutualia, que ha tenido que integrar los sistemas PACS en el aplicativo inform&aacute;tico de historia cl&iacute;nica existente en el &aacute;rea sanitaria y dar formaci&oacute;n en el uso del visor a todos los m&eacute;dicos. El &eacute;xito del proyecto &ldquo;ha radicado en la planificaci&oacute;n y gesti&oacute;n del cambio y en la coordinaci&oacute;n entre las &aacute;reas de inform&aacute;tica y sanitaria&rdquo;, destaca Rafael Muga.</p>', '4aeebd0084952.jpg', '4aeebd0089d5b.pdf', '2009-11-02', '2009-11-02', '2009-11-07', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-02 12:05:36', NULL, 0);
INSERT INTO `noticia` VALUES (103, 'La Universidad P�blica de Navarra gana el Premio Azul a la Promoci�n de la Salud en el Trabajo de Mu', 'Universia', '<p>La Universidad P&uacute;blica de Navarra ha ganado el I Premio Azul a la Promoci&oacute;n de la Salud en el Trabajo convocado por Mutua Navarra. Este galard&oacute;n, que la UPNA ha obtenido ex aequo con la empresa Guardian Navarra, premia las mejores pr&aacute;cticas dirigidas a la promoci&oacute;n de h&aacute;bitos y condiciones de trabajo saludables en instituciones p&uacute;blicas y empresas y est&aacute; dotado con 6.000 euros.</p>', '<p>La entrega de los premios de este certamen tendr&aacute; lugar el pr&oacute;ximo 16 de noviembre en la sede de la Confederaci&oacute;n de Empresarios de Navarra (CEN), en el marco de una jornada divulgativa en la que, adem&aacute;s de conferencias, se expondr&aacute;n los casos pr&aacute;cticos de las ganadoras del premio.   El jurado de este concurso valor&oacute; la existencia en la instituci&oacute;n de un programa de actuaci&oacute;n para la promoci&oacute;n de la salud; la implicaci&oacute;n de la direcci&oacute;n, sindicatos o trabajadores; la definici&oacute;n e implantaci&oacute;n de mejoras; la medici&oacute;n y seguimiento de las acciones; as&iacute; como la evoluci&oacute;n positiva de los &iacute;ndices de accidentabilidad y la reducci&oacute;n del absentismo, entre otros indicadores.   El jurado estuvo compuesto por Alberto Margallo, director del Instituto Navarro de Salud Laboral del Gobierno de Navarra; Javier Martinena, secretario general de la CEN; Mar&iacute;a Soledad Aranguren, directora de Salud P&uacute;blica; Mar&iacute;a Jos&eacute; Latasa, responsable del gabinete de Salud Laboral de UGT; Juan Manuel Gorostiaga, gerente de Mutua Navarra; y Javier Igea, director de Prevenci&oacute;n Navarra. As&iacute; mismo, colabor&oacute; con el jurado Mar&iacute;a Dolores Sol&eacute;, co-presidenta de la Red Europea para la Promoci&oacute;n de la Salud en el Trabajo (ENWHP), que envi&oacute; su valoraci&oacute;n al jurado.   La Universidad P&uacute;blica de Navarra es una de las instituciones pioneras en la promoci&oacute;n de la salud y, prueba de ello, es que desde 2005 cuenta con un Plan de Universidad Saludable que incluye programas dirigidos tanto a los alumnos como a profesores y a personal de administraci&oacute;n y servicios. Este plan, cuya vigencia se prolonga hasta 2010, fue confeccionado con la colaboraci&oacute;n del Gobierno de Navarra y tras realizar un diagn&oacute;stico del estado de salud de la universidad que cont&oacute; con una amplia colaboraci&oacute;n de todos los sectores.   La Universidad, a trav&eacute;s de la Unidad de Acci&oacute;n Social y la Unidad de Atenci&oacute;n Sanitaria, pone en marcha anualmente una serie de acciones de promoci&oacute;n de la salud relacionadas con temas como el autoconocimiento y desarrollo personal, la educaci&oacute;n afectivo-sexual, el consumo de sustancias adictivas y los estilos de vida saludables. Durante el curso 2008-2009 se han desarrollado 32 acciones dentro del Programa de Universidad Saludable. Fruto del trabajo desarrollado en estos a&ntilde;os, la Universidad ha logrado reducir la tasa anual de accidentes en el trabajo y el n&uacute;mero de bajas por enfermedad.</p>', '4aeebd7c6671a.gif', '4aeebd7c6933b.pdf', '2009-11-02', '2009-11-02', '2009-11-07', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-02 12:07:40', NULL, 0);
INSERT INTO `noticia` VALUES (104, 'Renovaci�n de la Junta Directiva de Mutua Universal', 'MUTUA UNIVERSAL', '', '<p>En la reuni&oacute;n celebrada el pasado 21 de Octubre, la Junta Directiva de Mutua Universal procedi&oacute; a la renovaci&oacute;n de algunos de sus cargos, cambios que se detallan a continuaci&oacute;n:</p>\r\n<p>D. Juan Pascual Mercader asumi&oacute; la Vicepresidencia 1&ordf;, D. Jorge Bofill Thomasa la Vicepresidencia 2&ordf; y D. Eduardo Ferrer Perales se ha incorporado a la Junta en calidad de vocal, como nuevo representante de Caja Rural del Mediterr&aacute;neo (Ruralcaja).</p>', '4af068ab09c45.jpg', '', '2009-11-05', '2009-11-05', '2009-11-10', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-03 18:30:19', NULL, 0);
INSERT INTO `noticia` VALUES (105, 'PRL para no caer por el precipicio de la crisis', 'Capital Humano', '<p>Hacer actividades de prevenci&oacute;n en general, y desde las Mutuas en particular, es otra forma m&aacute;s de crear empleo utilizando la reducci&oacute;n de p&eacute;rdidas producida por la disminuci&oacute;n de la siniestralidad</p>', '', '', '4af165cfa14a9.pdf', '2009-11-04', '2009-11-04', '2009-11-09', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-04 12:30:23', NULL, 0);
INSERT INTO `noticia` VALUES (106, 'Cien mil trabajadoras se han beneficiado de la baja por riesgo durante el embarzo', 'Diario Critico.com', '', '', '', '4af2aac7581cc.pdf', '2009-11-05', '2009-11-05', '2009-11-10', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-05 11:36:55', NULL, 0);
INSERT INTO `noticia` VALUES (107, 'Las Mutuas de trabajo realizaron m�s de 21 millones de atenciones m�dicas personalizadas en Espa�a e', 'Comfia CCOO', '<p>La labor asistencial de las Mutuas a los trabajadores protegidos va en aumento a&ntilde;o tras a&ntilde;o, registr&aacute;ndose durante el 2008 un total de 21.951.279 atenciones m&eacute;dicas realizadas, 1.411.657 m&aacute;s que en el 2007, seg&uacute;n los datos de la Asociaci&oacute;n de Mutuas de Accidentes de Trabajo.</p>', '', '', '4af2ab32c9bfb.pdf', '2009-11-05', '2009-11-05', '2009-11-10', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-05 11:38:42', NULL, 0);
INSERT INTO `noticia` VALUES (108, 'Las Mutuas de trabajo realizaron m�s de 21 millones de atenciones m�dicas personalizadas en Espa�a e', 'Comfia CCOO', '<p>La labor asistencial de las Mutuas a los trabajadores protegidos va en aumento a&ntilde;o tras a&ntilde;o, registr&aacute;ndose durante el 2008 un total de 21.951.279 atenciones m&eacute;dicas realizadas, 1.411.657 m&aacute;s que en el 2007, seg&uacute;n los datos de la Asociaci&oacute;n de Mutuas de Accidentes de Trabajo.</p>', '', '', '4af2abcb4de53.pdf', '2009-11-05', '2009-11-05', '2009-11-10', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-05 11:41:15', NULL, 0);
INSERT INTO `noticia` VALUES (109, 'M�s de 428.000 trabajadores fueron atendidos por las Mutuas durante 2008 en Andaluc�a', 'Europa Press', '', '', '', '4af2ac5a3937f.pdf', '2009-11-05', '2009-11-05', '2009-11-10', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-05 11:43:38', NULL, 0);
INSERT INTO `noticia` VALUES (110, 'Las Mutuas de trabajo realizaron m�s de 21 millones de atenciones m�dicas personalizadas en Espa�a e', 'Europa Press', '', '', '', '4af2acac40db5.pdf', '2009-11-05', '2009-11-05', '2009-11-10', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-05 11:45:00', NULL, 0);
INSERT INTO `noticia` VALUES (111, 'Empresaysalud.es se consolida como la plataforma online para cuidar de la salud de la empresa espa�o', 'Diario Critico.com', '<p><strong><span style=\\"font-family: Arial;\\">\r\n<p><span style=\\"font-family: helvetica;\\"><span style=\\"font-size: small;\\">Desde que las Mutuas de Accidentes de Trabajo, a trav&eacute;s de AMAT, pusieron en marcha a finales de julio de 2009 esta iniciativa pionera en Espa&ntilde;a, m&aacute;s de 2.700 grandes y medianas empresas se han suscrito a los servicios gratuitos de empresaysalud.es.</span></span></p>\r\n</span></strong></p>\r\n<p>&nbsp;</p>', '', '', '4af409a96954d.pdf', '2009-11-06', '2009-11-06', '2009-11-11', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-06 12:34:01', NULL, 0);
INSERT INTO `noticia` VALUES (112, 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 'MUTUA UNIVERSAL', '<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 0.75pt; text-align: justify; mso-outline-level: 3;\\"><span style=\\"font-size: 10pt; font-family: Arial;\\">Del 16 al 20 de Noviembre pr�ximos, se celebrar� en Alcal� de Henares, Cuenca y Madrid, el III Congreso de Actualidad Laboral, organizado por el Excmo. Colegio Oficial de Graduados Sociales de Madrid </span></p>\r\n<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 0pt; text-align: justify;\\"><span style=\\"font-size: 10pt; font-family: Arial;\\">�</span></p>\r\n<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 0pt; text-align: justify;\\"><span style=\\"font-size: 10pt; font-family: Arial;\\">En la Jornada inaugural, que se desarrollar� en el Sal�n de Grados de la Universidad de Alcal� (C/ Libreros, 27) est� prevista, a las 17.30h la conferencia de D. Carlos Serradilla, letrado Coordinador Territorial de los Servicios Jur�dicos de Mutua Universal en Madrid, acerca de \\"El Real Decreto 1430/09 respecto de los sistemas de control en la IT, asistencia sanitaria de la Mutua y Fondo Social\\".</span></p>', '<p class="\\&quot;MsoNormal\\&quot;">&nbsp;</p><p class="\\&quot;MsoNormal\\&quot;"><span>&nbsp;</span></p><p><span>&nbsp;</span></p><p>&nbsp;</p><p class="\\&quot;MsoNormal\\&quot;"><span>Las inscripciones son gratuitas, tanto para asistir a todo el congreso como a las ponencias que sean de inter&eacute;s. No obstante para todos aquellos que no puedan asistir, ser&aacute; retransmitido &iacute;ntegramente en directo a trav&eacute;s de la pagina web del colegio.</span></p><p class="\\&quot;MsoNormal\\&quot;"><span>&nbsp;</span></p><p><span new=""><a href="/uploads/file/Modeloparacabeceraypie.pdf">Adjuntamos folleto del congreso en PDF para m&aacute;s informaci&oacute;n</a>.</span></p>', '4af42112b217f.jpg', '4af42112c4fa5.pdf', '2009-11-19', '2009-11-20', '2009-11-24', 'web', 'publicado', 0, 1, 1, 1, 7, 7, '2010-01-28 08:54:59', '2009-11-06 14:13:54', '2010-01-28 08:54:59', 0);
INSERT INTO `noticia` VALUES (113, 'Egarsat firma un acuerdo con el programa Incorpora de la Obra Social \\"la Caixa\\"', 'Noticias M�dicas.es', '<p><span style=\\"font-size: x-small;\\">- El acuerdo entre la mutua de accidentes y la entidad financiera permitir&aacute; promover la b&uacute;squeda de un puesto de trabajo de aquellos colectivos con dificultades.&nbsp;<br /><br />- La colaboraci&oacute;n entre &ldquo;la Caixa&rdquo; y Egarsat persigue crear una s&oacute;lida alianza con el sector empresarial para potenciar la integraci&oacute;n laboral.</span></p>', '<p><span style=\\"font-size: x-small;\\"><strong>Sant Cugat del Vall&egrave;s, noviembre de 2009.-</strong> El presidente de Egarsat, Josep Casas, y el director del &aacute;rea de integraci&oacute;n social de la Fundaci&oacute;n &ldquo;la Caixa&rdquo;, Marc Sim&oacute;n, han firmado un convenio por el que ambas entidades colaborar&aacute;n en sus respectivos proyectos de Responsabilidad Social Corporativa, creados con el fin de ofrecer todo el apoyo y contribuir a la integraci&oacute;n laboral de aquellos colectivos con m&aacute;s dificultades. El acuerdo responde a una clara apuesta por la Responsabilidad Social Corporativa. <br /><br />En este sentido, dentro de su Obra Social &ldquo;la Caixa&rdquo; promueve el programa Incorpora y Egarsat el proyecto Re-ilusi&oacute;nate, ambos orientados entre otros a favorecer, a trav&eacute;s de pol&iacute;ticas y acciones concretas, una mayor incorporaci&oacute;n al mundo laboral de personas con riesgo de exclusi&oacute;n, como es el caso especialmente de aquellos trabajadores que han sufrido un accidente de trabajo que les impide incorporarse a su puesto de trabajo anterior, as&iacute; como a j&oacute;venes parados durante largo tiempo, mujeres v&iacute;ctimas de la violencia de g&eacute;nero, inmigrantes y personas con discapacidad f&iacute;sica, ps&iacute;quica o sensorial. <br /><br />Gracias al nuevo convenio de colaboraci&oacute;n, estas entidades se encargar&aacute;n de la incorporaci&oacute;n de los beneficiarios de los dos programas a sus procesos de selecci&oacute;n, del seguimiento de su formaci&oacute;n y del acompa&ntilde;amiento en la adaptaci&oacute;n al lugar de trabajo, as&iacute; como de la soluci&oacute;n de los posibles conflictos que puedan surgir en el marco de la relaci&oacute;n laboral. <br /><br /><strong>Programa Re-ilusi&oacute;nate</strong> <br /><br />El programa Re-ilusi&oacute;nate de Egarsat ofrece a los trabajadores afiliados que han sufrido un accidente de trabajo la oportunidad de ampliar sus conocimientos profesionales durante el per&iacute;odo de recuperaci&oacute;n, as&iacute; como todo el apoyo administrativo, humano y econ&oacute;mico para ayudar al trabajador a reincorporarse a su vida diaria y, si es posible, a la laboral con la finalidad de potenciar su autonom&iacute;a y su integraci&oacute;n social en el caso de que el accidente sufrido le produjera alguna incapacidad. Se trata, pues, de un proyecto que va m&aacute;s all&aacute; de la actividad profesional propia de la entidad, y que pretende promover la sensibilizaci&oacute;n e incentivar, de forma voluntaria, comportamientos sociales. <br /><br />Desde este momento, el colectivo de trabajadores asociados al programa Re-ilusi&oacute;nate dispone de m&aacute;s beneficios: asesoramiento personalizado para la reorientaci&oacute;n profesional y acceso a las ofertas de empleo del programa Incopora de la Fundaci&oacute;n &ldquo;la Caixa&rdquo; gestionadas por una red de 318 t&eacute;cnicos de inserci&oacute;n laboral, as&iacute; como a los servicios de los que disponen las 230 entidades sociales que participan en el programa Incorpora. <br /><br /><strong>Obra Social &ldquo;la Caixa&rdquo;</strong> <br /><br />Desde el a&ntilde;o 2006, la Obra Social &ldquo;la Caixa&rdquo; fomenta, con el programa Incorpora, el acceso al mundo laboral de colectivos en riesgo o situaci&oacute;n de exclusi&oacute;n social. La iniciativa ha facilitado 20.543 inserciones de personas en riesgo o situaci&oacute;n de exclusi&oacute;n social en todo el Estado y 8.706 empresas, como es el caso de Egarsat, ya se han vinculado activamente. En la provincia de Barcelona, la cifra de inserciones se eleva a 2.600 en un total de 758 empresas, gracias a la red formada por 37 entidades sociales. <br /><br />El fomento del trabajo entre colectivos desfavorecidos, la atenci&oacute;n a las personas con enfermedades avanzadas y a sus familiares, la promoci&oacute;n de la vacunaci&oacute;n infantil en los pa&iacute;ses con rentas bajas y la concesi&oacute;n de microcr&eacute;ditos sociales o financieros a trav&eacute;s de MicroBank son, junto con el programa de superaci&oacute;n de la pobreza infantil, CaixaProinf&agrave;ncia, algunas de las prioridades estrat&eacute;gicas de la Obra Social para el a&ntilde;o 2009. El objetivo fundamental: dar oportunidades a las personas. <br /><br /><strong>Sobre Egarsat</strong> <br /><br /></span><a href=\\"http://www.egarsat.es \\" target=\\"_blank\\"><span style=\\"font-size: x-small;\\">Egarsat</span></a><span style=\\"font-size: x-small;\\"> naci&oacute; el 1 de enero de 2007 fruto de la fusi&oacute;n de las entidades Mutua Egara i SAT Mutua. Tiene &aacute;mbito de actuaci&oacute;n nacional, con una red de 40 delegaciones, algunas de ellas con instalaciones m&eacute;dicas asistenciales propias, y multitud de centros m&eacute;dicos concertados. En julio de 2008, la entidad se integr&oacute; a la corporaci&oacute;n Suma Intermutual, una alianza estrat&eacute;gica formada por Mutua Monta&ntilde;esa, Maz, UMIVALE, Mutua Navarra y Egarsat y cuarto operador del sector por volumen de cuotas. Egarsat cerr&oacute; el ejercicio 2008 con una facturaci&oacute;n de 241 millones de euros, 32.000 empresas asociadas, 271.000 trabajadores protegidos y 51.000 aut&oacute;nomos adheridos. El n&uacute;mero de trabajadores en plantilla es de 430 personas. </span><br /><br /><br /></p>', '4afa8576db041.jpg', '4afa8576e20c5.pdf', '2009-11-11', '2009-11-11', '2009-11-16', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-11 10:35:50', NULL, 0);
INSERT INTO `noticia` VALUES (114, 'Mutua Intercomarcal organiza una conferencia para analizar las prestaciones de la Seguridad Social', 'Diario digital de Menorca', '<p>Mutua Intercomarcal organiza el jueves, 12 de noviembre, en el Colegio de Graduados Sociales de las Islas Baleares, una conferencia informativa enfocada a la prestaci&oacute;n de cese de actividad para los aut&oacute;nomos.<br /><br />Este acto, podr&aacute; ser seguido por videoconferencia desde la sede del Colegio de Graduados Sociales en Menorca.<br /><br />Los ponentes ser&aacute;n Vicen&ccedil; Ferrer y Gonzalo M&aacute;rquez, responsable y coordinador del Departamento de Asesor&iacute;a Jur&iacute;dica interna de Mutua Intercomarcal, respectivamente. Ambos trataran aspectos como:<br /><br />- An&aacute;lisis del Real Decreto 1430/2009, por el que se desarrolla la Ley de Medidas varias en materia de Seguridad Social y en materia de Incapacidad Temporal<br /><br />- Repaso al proyecto de prestaci&oacute;n por cese de actividad de los trabajadores aut&oacute;nomos, seg&uacute;n el informe presentado por el Ministerio de Trabajo e Inmigraci&oacute;n el pasado 19 de agosto.<br /><br />ACTO: Conferencia informativa sobre las prestaciones de la Seguridad Social.<br /><br />FECHA: Jueves, 12 de noviembre de 2009.<br /><br />HORA: 16:30h.<br /><br />LUGAR: Colegio Oficia de Graduados Sociales, Parellades 12-A, Mallorca.</p>', '', '', '4afbd98ea2cbf.pdf', '2009-11-12', '2009-11-12', '2009-11-17', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-12 10:46:54', NULL, 0);
INSERT INTO `noticia` VALUES (115, 'MC MUTUAL premia a las organizaciones comprometidas con la Prevenci�n de Riesgos Laborales ', 'Mc Mutual', '<p class=\\"Default\\" style=\\"text-indent: 0cm; margin: 0cm 0cm 7.35pt; mso-list: l0 level1 lfo1;\\"><span style=\\"font-size: x-small;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\"><strong>Los premiados de esta 8&ordf; edici&oacute;n fueron Aceros Inoxidables Olarra (Loiu, Vizcaya), Alesa Proyectos y Contratas (Valencia), Castelnou Energ&iacute;a (Castelnou, Teruel), GE Wind Energy (Noblejas, Toledo) y Masats (Sant Salvador de Guardiola, Barcelona). </strong></span></span></p>\r\n<p class=\\"Default\\" style=\\"text-indent: 0cm; margin: 0cm 0cm 7.35pt; mso-list: l0 level1 lfo1;\\"><span style=\\"font-size: x-small;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\"><strong>A su vez, Volkswagen-Audi Espa&ntilde;a recibi&oacute; un Premio Especial. </strong></span></span></p>\r\n<p class=\\"Default\\" style=\\"text-indent: 0cm; margin: 0cm 0cm 0pt; mso-list: l0 level1 lfo1;\\"><span style=\\"font-size: x-small;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\"><strong>El evento fue presidido por el <em>Director General de Relacions Laborals </em>de la <em>Generalitat de Catalunya</em>, Salvador &Aacute;lvarez Vega; y por el Director General de Ordenaci&oacute;n de la Seguridad Social, Miguel &Aacute;ngel D&iacute;az Pe&ntilde;a</strong> </span></span></p>', '<p class=\\"CM5\\" style=\\"text-align: justify; line-height: 19pt; margin: 0cm 0cm 19pt;\\"><span style=\\"color: black; mso-bidi-font-family: Arial;\\"><span style=\\"font-size: x-small;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\">MC MUTUAL, la Mutua de Accidentes de Trabajo y Enfermedades Profesionales n&uacute;mero 1 de Espa&ntilde;a, celebr&oacute; ayer la <strong>VIII Edici&oacute;n de los Premios MC MUTUAL <em>&ldquo;Antonio Bar&oacute;&rdquo; </em>a la Prevenci&oacute;n de Riesgos Laborales</strong>. Unos galardones que cumplen con un doble objetivo: fomentar la prevenci&oacute;n en clave positiva y reconocer la labor de las empresas, personas e instituciones que llevan a cabo una pol&iacute;tica eficaz de protecci&oacute;n de la salud de sus trabajadores. </span></span></span></p>\r\n<p class=\\"CM5\\" style=\\"text-align: justify; line-height: 19pt; margin: 0cm 0cm 19pt;\\"><span style=\\"color: black; mso-bidi-font-family: Arial;\\"><span style=\\"font-size: x-small;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\">En esta octava edici&oacute;n, las organizaciones premiadas por la Comisi&oacute;n de Control y Seguimiento de MC MUTUAL, que ejerce de jurado, fueron Aceros Inoxidables Olarra, S.A., Alesa Proyectos y Contratas, S.A., Castelnou Energ&iacute;a, S.L., GE Wind Energy, S.L., y Masats, S.A. Adem&aacute;s, la Direcci&oacute;n de la mutua concedi&oacute; un Premio Especial a Volkswagen-Audi Espa&ntilde;a, S.A. </span></span></span></p>\r\n<p class=\\"CM2\\" style=\\"text-align: justify; margin: 0cm 0cm 0pt;\\"><span style=\\"color: black; mso-bidi-font-family: Arial;\\"><span style=\\"font-size: x-small;\\"><span style=\\"font-family: arial,helvetica,sans-serif;\\">La ceremonia tuvo lugar en la <em>Torre dels Lleons</em>, ubicada en Esplugues de Llobregat, Barcelona, y fue presidida por el <em>Director General de Relacions Laborals </em>de la <em>Generalitat de Catalunya</em>, Salvador &Aacute;lvarez Vega; y por el Director General de Ordenaci&oacute;n de la Seguridad Social, Miguel &Aacute;ngel D&iacute;az Pe&ntilde;a. </span></span></span></p>', '4b0117a5c6c16.jpg', '4afd499030ac6.pdf', '2009-11-13', '2009-11-13', '2009-11-18', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-13 12:57:03', NULL, 0);
INSERT INTO `noticia` VALUES (117, 'MAZ culmina la innovaci�n t�cnologica en sus hospitales.', 'MAZ', '<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 10pt; line-height: normal; mso-margin-top-alt: auto; mso-margin-bottom-alt: auto; mso-outline-level: 2;\\"><strong><span style=\\"font-size: 10pt; color: #244061; font-family: &amp;amp;amp; mso-fareast-font-family: \\\'Times New Roman\\\'; mso-fareast-language: ES-TRAD;\\">MAZ INTEGRA EL CONTROL DE MEDICAMENTOS EN SU GESTI&Oacute;N HOSPITALARIA CON MICROSOFT&nbsp;&nbsp; </span></strong></p>\r\n<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 0pt; line-height: normal;\\"><span style=\\"font-size: 1pt; color: black; font-family: &amp;amp;amp; mso-fareast-font-family: \\\'Times New Roman\\\'; mso-fareast-language: ES-TRAD;\\"><br /><br /></span><span style=\\"font-size: x-small;\\"><strong><span style=\\"font-family: &amp;amp;amp; mso-fareast-font-family: \\\'Times New Roman\\\'; mso-fareast-language: ES-TRAD; mso-bidi-font-size: 11.0pt;\\">MAZ, Mutua de accidentes de trabajo y enfermedades profesionales de la Seguridad Social n&ordm; 11, ha comenzado un proceso de integraci&oacute;n funcional y consolidaci&oacute;n interna, ayudada por las tecnolog&iacute;as de Microsoft.</span></strong><span style=\\"font-family: &amp;amp;amp; mso-fareast-font-family: \\\'Times New Roman\\\'; mso-fareast-language: ES-TRAD;\\"> </span></span></p>', '<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 6pt; text-align: justify;\\"><strong style=\\"mso-bidi-font-weight: normal;\\"><span style=\\"font-size: 10pt; line-height: 115%; font-family: &amp;amp;amp;\\">Tecnolog&iacute;a en los hospitales MAZ</span></strong></p>\r\n<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 6pt; text-align: justify;\\"><span style=\\"font-size: 10pt; line-height: 115%; font-family: &amp;amp;amp;\\">El Hospital-MAZ de Zaragoza ha modernizado su <strong style=\\"mso-bidi-font-weight: normal;\\">sistema de almacenamiento de medicamentos</strong>, cubriendo al 100% las necesidades de control del flujo de los medicamentos que circulaban por el hospital: desde la prescripci&oacute;n hasta el paciente. Para solucionar la integraci&oacute;n de los datos y el control necesario, se implant&oacute; una herramienta<span style=\\"mso-spacerun: yes;\\">&nbsp; </span>que incluye un motor HL/7 que integra el aplicativo del hospital, con los sistemas robotizados dispensadores de medicamentos PYXIS, (UCI y quir&oacute;fanos) y Kardex (armario de Farmacia).</span></p>\r\n<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 0pt; line-height: normal; text-align: justify;\\"><span style=\\"font-size: 10pt; font-family: &amp;amp;amp;\\">La soluci&oacute;n final se puso en producci&oacute;n despu&eacute;s del verano de 2008 y actualmente funciona a plena satisfacci&oacute;n. El resultado obtenido es un sistema de control de medicamentos totalmente automatizado. Puesto que se dispon&iacute;a de un entorno desconectado de los sistemas en producci&oacute;n, el trabajo se hizo de manera r&aacute;pida, controlada y exenta de riesgos. Microsoft BizTalk Server, dentro de MAZ Matepss n&ordm; 11, no solamente es un conversor de protocolos de comunicaci&oacute;n para robots de almac&eacute;n, sino una pieza central a medio plazo en el proyecto de integraci&oacute;n global de todos los sistemas de informaci&oacute;n de la Mutua. </span></p>\r\n<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 0pt; line-height: normal; text-align: justify;\\"><span style=\\"font-size: 10pt; font-family: &amp;amp;amp;\\"><br />Una vez instalado el sistema en los servidores de pre-producci&oacute;n, tambi&eacute;n se ha encargado de impartir formaci&oacute;n de la herramienta y de la arquitectura de la aplicaci&oacute;n a un grupo de personas de MAZ , el cual gestiona completamente el sistema. </span></p>\r\n<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 0pt; line-height: normal; text-align: justify;\\"><span style=\\"font-size: 10pt; font-family: &amp;amp;amp;\\">&nbsp;</span></p>\r\n<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 6pt; text-align: justify;\\"><span style=\\"font-size: 10pt; line-height: 115%; font-family: &amp;amp;amp;\\">La mejora de los servicios apoy&aacute;ndose en los &uacute;ltimos adelantos tecnol&oacute;gicos es una constante en MAZ, que ya en el a&ntilde;o 2007, inici&oacute; la transformaci&oacute;n de la entidad implantando, tanto en la Cl&iacute;nica MAZ de Barcelona (San Honorat) como en el Hospital MAZ de Zaragoza, de un revolucionario sistema de <strong style=\\"mso-bidi-font-weight: normal;\\">Radiolog&iacute;a Digital</strong> <strong style=\\"mso-bidi-font-weight: normal;\\">(PACS)</strong> que -ya desde el verano de 2008- ha permitido ofrecer un mejor servicio en el Diagn&oacute;stico por Imagen.</span></p>\r\n<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 6pt; text-align: justify;\\"><span style=\\"font-size: 10pt; line-height: 115%; font-family: &amp;amp;amp;\\">La Radiolog&iacute;a Digital ofrece m&uacute;ltiples ventajas para los pacientes, al facilitar la interconsulta entre profesionales m&eacute;dicos - mejorando el diagn&oacute;stico - y evitar desplazamiento innecesarios. Pero, adem&aacute;s, al evitar el revelado de im&aacute;genes, contribuye a la conservaci&oacute;n del medio ambiente.</span></p>\r\n<p class=\\"MsoNormal\\" style=\\"margin: 0cm 0cm 6pt; text-align: justify;\\"><span style=\\"font-size: 10pt; line-height: 115%; font-family: &amp;amp;amp;\\"><a href=\\"http://www.maz.es/ES/Paginas/Pagina_Principal.aspx\\"></a></span></p>', '4b0148b223d93.jpg', '', '2009-11-17', '2009-11-17', '2009-11-22', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-16 13:42:26', NULL, 0);
INSERT INTO `noticia` VALUES (118, 'FREMAP participa en la XV Semana Europea de la calidad', 'FREMAP', '<p style=\\"text-align: justify;\\"><span style=\\"font-family: &amp;quot; COLOR;\\"><span style=\\"font-size: x-small;\\">Jes&uacute;s Mar&iacute;a Esarte, Director Gerente de la mutua Fremap, particip&oacute; como ponente en la Mesa \\"La calidad marca la diferencia\\"</span></span></p>', '<p style=\\"text-align: justify;\\"><span style=\\"font-family: &amp;quot; COLOR;\\"><span style=\\"font-size: x-small;\\">La XV Semana Europea de la Calidad tuvo su acto central el pasado d&iacute;a 12 de Noviembre en la Universidad Pontificia de Comillas, en Madrid.</span></span></p>\r\n<p style=\\"text-align: justify;\\"><span style=\\"font-family: &amp;quot; COLOR;\\"><span style=\\"font-size: x-small;\\">El evento, que obtuvo una amplia repercusi&oacute;n y un aforo completo, cont&oacute; con la presencia de personalidades importantes del mundo empresarial espa&ntilde;ol, entre los que figuraban Teresa santero (Secretaria General de Industria), Adolfo Ram&iacute;rez (Director General de Banesto), Diego Pav&iacute;a (Director General de Atos Origin), C&eacute;sar Molins (Director General de Ames), y otros numerosos representantes de la Administraci&oacute;n y de empresas espa&ntilde;olas.</span></span></p>\r\n<p style=\\"text-align: justify;\\"><span style=\\"font-family: &amp;quot; COLOR;\\"><span style=\\"font-size: x-small;\\">Josu Esarte, Director Gerente de Fremap, ejerci&oacute; como ponente en dicho acto, bajo el t&iacute;tulo \\"La calidad marca la diferencia\\"</span></span></p>\r\n<p style=\\"text-align: justify;\\"><span style=\\"font-family: &amp;quot; COLOR;\\"><span style=\\"font-size: x-small;\\">La XV Semana Europea de la calidad tiene como Presidentes de Honor a SS.AA.RR. Los Pr&iacute;ncipes de Asturias</span></span></p>', '4b026a297a291.pdf', '', '2009-11-17', '2009-11-17', '2009-11-22', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-17 10:17:29', NULL, 0);
INSERT INTO `noticia` VALUES (119, 'La MAC convoca para este mi�rcoles unas jornadas para reducir la siniestralidad en la industria de C', 'Europa Press', '<p><span style=\\"font-size: x-small;\\">La Mutua de Accidentes de Canarias (MAC) celebrar&aacute; este mi&eacute;rcoles unas jornadas destinadas a reducir la siniestralidad en el sector industrial. Las jornadas tituladas \\\'Riesgo F&iacute;sicos emergentes en el &aacute;mbito laboral\\\' se han organizado en colaboraci&oacute;n con la Asociaci&oacute;n Industrial de Canarias (Asinca), seg&uacute;n ha informado la mutua en un comunicado.</span></p>', '<p style=\\"text-align: justify;\\"><span style=\\"font-size: x-small;\\">El director gerente de la MAC, Manuel Rodr&iacute;guez, inaugurar&aacute; en el sal&oacute;n de actos de la Mutua Canaria --ubicado en su sede central de la calle Robayna de Santa Cruz de Tenerife--&nbsp;&nbsp;este encuentro que contar&aacute;n con la presencia deespecialistas que ofrecer&aacute;n varias conferencias sobre la materia que estar&aacute;n dirigidas, principalmente, a profesionales de la prevenci&oacute;n laboral, directores t&eacute;cnicos, empresarios, trabajadores y p&uacute;blico interesado en general.</span></p>\r\n<p style=\\"text-align: justify;\\"><span style=\\"font-size: x-small;\\">&nbsp;&nbsp; El evento, que cuenta con la colaboraci&oacute;n del Gobierno de Canarias a trav&eacute;s de su Consejer&iacute;a de Empleo, Industria y Comercio y la Direcci&oacute;n General de Trabajo, se celebrar&aacute; el 18 de noviembre, a partir de las 10.00 horas. La asistencia a estas jornadas es gratuita, aunque es necesaria una inscripci&oacute;n previa que puede formalizarse llamando al tel&eacute;fono del &Aacute;rea de Seguridad e Higiene de la Mutua de Canarias o a Asinca. Con esta acreditaci&oacute;n, el p&uacute;blico podr&aacute; escuchar los consejos y an&aacute;lisis de especialistas como Jorge P&eacute;rez Lutzardo y Manuel Fern&aacute;ndez Estrada, t&eacute;cnicos de prevenci&oacute;n de Riesgos Laborales de la Mutua de Canarias.</span></p>\r\n<p>&nbsp;&nbsp; En el transcurso de estas jornadas, se abordar&aacute;n muchos de los nuevos riesgos f&iacute;sicos en el &aacute;mbito laboral, como el estr&eacute;s t&eacute;rmico, ruido y vibraciones, la iluminaci&oacute;n o la exposici&oacute;n a radiaciones. Asimismo, habr&aacute; una informaci&oacute;n especialmente dedicada a los trastornos m&uacute;sculo-esquel&eacute;ticos.</p>\r\n<p>&nbsp;&nbsp; En este sentido, el director gerente de MAC indic&oacute; que estas jornadas \\"son formativas e informativas porque en muchos casos la inexistente o deficiente informaci&oacute;n sobre los nuevos riesgos f&iacute;sicos en el &aacute;mbito laboral es lo que hace olvidar la necesaria aplicaci&oacute;n de las medidas preventivas\\", apunt&oacute; Manuel Rodr&iacute;guez. Para el director de MAC, sobre todo en tiempos de crisis econ&oacute;mica, \\"hay que redoblar los esfuerzos para mejorar las condiciones de seguridad de los trabajadores\\".</p>', '', '4b026a3228651.pdf', '2009-11-17', '2009-11-17', '2009-11-22', 'web', 'publicado', 0, 1, 1, 1, 0, 0, NULL, '2009-11-17 10:17:38', NULL, 0);
INSERT INTO `noticia` VALUES (120, 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 'Diario Cr�tico', '<p style=\\"text-align: justify;\\"><strong><span style=\\"font-family: arial,helvetica,sans-serif;\\"><span style=\\"font-size: x-small;\\">Las prestaciones otorgadas por la Seguridad Social y las Mutuas de Accidentes de Trabajo por bajas ocasionadas por enfermedades comunes� o accidentes no laborales ascendieron a 6.730 millones de euros durante 2008.� </span></span></strong></p>', '<p style="\\&quot;text-align:"><span style="\\&quot;font-family:"><span style="\\&quot;font-size:">Esta cifra, aunque significativa, no refleja el verdadero lastre que este tipo de bajas laborales ocasiona a la econom&iacute;a espa&ntilde;ola. Para hacernos idea de dicho coste, deber&iacute;amos sumarle, entre otras, la cantidad que los empresarios pagan en concepto de salario y seguros sociales durante los d&iacute;as de baja, los costes en los que incurre la empresa por la falta de producci&oacute;n, sustituci&oacute;n de personal y formaci&oacute;n del mismo, retrasos en la entrega de pedidos, gastos administrativos, adem&aacute;s de la perdida de competitividad que la empresa sufre.<br />', '4b03c0720b1b3.jpg', '4b03c07218a95.pdf', '2009-11-18', '2009-11-18', '2009-11-23', 'web', 'publicado', 0, 1, 1, 1, 7, 0, NULL, '2009-11-18 10:37:54', '2010-01-08 15:47:20', 0);
INSERT INTO `noticia` VALUES (121, 'Mutua Universal participa en el programa europeo Globaltech', 'MUTUA UNIVERSAL', '', '<p><span style=\\"font-size: x-small;\\">En el marco de la Semana Europea de Seguridad y Salud en el Trabajo, el 14 de octubre se celebr&oacute; en la Comunidad de La Rioja, el acto de presentaci&oacute;n del proyecto \\"<strong>Aplicaci&oacute;n de la innovaci&oacute;n tecnol&oacute;gica en los &aacute;mbitos de protecci&oacute;n de la vida y la seguridad de las personas\\"</strong>.<br /><br />El estudio se encuadra en el programa europeo Globaltech. Ha sido desarrollado por la Agencia de Desarrollo Econ&oacute;mico de la Rioja (ADER), el Gobierno de la Rioja a trav&eacute;s de la Direcci&oacute;n General de Empleo, el Instituto Riojano de Salud Laboral (IRSAL) y el &aacute;rea de Innovaci&oacute;n en Prevenci&oacute;n de Mutua Universal.<br /><br />El proyecto ha consistido en el estudio de las necesidadesde las empresas riojanas en materia de prevenci&oacute;n, a nivel de proveedores que pueden poner en pr&aacute;ctica mejoras en las instalaciones, proveedores de equipos y herramientas seguras, asesoramiento t&eacute;cnico en la implantaci&oacute;n de estas soluciones, reingenier&iacute;a de los procesos y puestos de trabajo y en I+D. <br /><br />Como resultado se han identificado nuevas oportunidades de mercado para empresas riojanas y se ha elaborado un cat&aacute;logo de proveedores de prevenci&oacute;n y tecnolog&iacute;as seguras.<br /><br />Present&oacute; el proyecto el Sr. Javier Erro, Consejero de Industria, Innovaci&oacute;n y Empleo, quien agradeci&oacute; p&uacute;blicamente a Mutua Universal su participaci&oacute;n en el mismo. Agradeci&oacute; asimismo a Mutua Universal el papel que ha desempe&ntilde;ado en el desarrollo de las pruebas piloto del programa preVea en La Rioja.<br /><br />El acto, al que asistieron 130 personas, se realiz&oacute; en el Centro Tecnol&oacute;gico de la Rioja y cont&oacute; con la presentaci&oacute;n del Sr. Jukka Takala, Director de la Agencia Europea para la Seguridad y la Salud .<br /><br />Asistieron representando a Mutua Universal, Isabel Maya, Jefe del Dpto. de Innovaci&oacute;n en Prevenci&oacute;n, y el Director de la representaci&oacute;n de Logro&ntilde;o, Diego Rodr&iacute;guez.</span></p>', '4b04315db4e1a.jpg', '', '2009-11-17', '2009-11-17', '2009-11-22', 'web', 'pendiente', 0, 1, 1, 1, 0, 0, NULL, '2009-11-18 18:39:41', NULL, 0);
INSERT INTO `noticia` VALUES (122, 'Todos tenemos una Mutua que cuida de nosotros, los trabajadores', 'AMAT', '<p>La edici&oacute;n de este folleto tiene como objetivo poner en conocimiento de los trabajadores de cual es la labor de las Mutuas de Accidentes de Trabajo y Enfermendades Profesionales de la Seguridad Social. Adem&aacute;s de destacar cual es el el cometido de las Mutuas, se ofrecen unas recomendaciones a tener en cuenta en el caso de accidente laboral. De igual forma, se indican los datos de contacto de las 20 Mutuas que actumente protengen a m&aacute;s de 14 millones de trabajodores en toda Espa&ntilde;a.</p>', '<p>La edici&oacute;n de este folleto tiene como objetivo poner en conocimiento de los trabajadores de cual es la labor de las Mutuas de Accidentes de Trabajo y Enfermendades Profesionales de la Seguridad Social. Adem&aacute;s de destacar cual es el el cometido de las Mutuas, se ofrecen unas recomendaciones a tener en cuenta en el caso de accidente laboral. De igual forma, se indican los datos de contacto de las 20 Mutuas que actumente protengen a m&aacute;s de 14 millones de trabajodores en toda Espa&ntilde;a.</p>', '4b03d8cd74741.jpg', '4a72aea2794b5.pdf', '2009-05-08', '2009-05-08', '2009-05-18', 'web', 'publicado', 1, 1, 1, 1, 1, 1, '0000-00-00 00:00:00', '2009-05-08 12:05:27', '0000-00-00 00:00:00', 0);
INSERT INTO `noticia` VALUES (123, 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 'AMAT', '<p>La edici�n de este folleto tiene como objetivo poner en conocimiento de los empresarios de cual es la labor de las Mutuas de Accidentes de Trabajo y Enfermendades Profesionales de la Seguridad Social. Adem�s de destacar cual es el el cometido de las Mutuas, se ofrecen unas recomendaciones a tener en cuenta en el caso de accidente laboral. De igual forma, se indican los datos de contacto de las 20 Mutuas que actumente ofrecen sus servicio a m�s de un mill�n y medio de empresas afiliadas</p>', '<p>La edici&oacute;n de este folleto tiene como objetivo poner en conocimiento de los empresarios de cual es la labor de las Mutuas de Accidentes de Trabajo y Enfermendades Profesionales de la Seguridad Social. Adem&aacute;s de destacar cual es el el cometido de las Mutuas, se ofrecen unas recomendaciones a tener en cuenta en el caso de accidente laboral. De igual forma, se indican los datos de contacto de las 20 Mutuas que actumente ofrecen sus servicio a m&aacute;s de un mill&oacute;n y medio de empresas afiliadas</p>', '4a0404c5083f3.jpg', '4a72af1220c79.pdf', '2009-05-08', '2009-05-08', '2009-05-18', 'web', 'publicado', 1, 1, 1, 1, 1, 1, '0000-00-00 00:00:00', '2009-05-08 12:09:09', '2009-12-24 15:09:53', 0);
INSERT INTO `noticia` VALUES (124, 'Tu Mutua te escucha', '', '<p>Procedimientos para la realizaci&oacute;n de una reclamaci&oacute;n ante una Mutua de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social.</p>', '<p>La edici&oacute;n de este folleto tiene que objetivo poner en conocimiento de trabajadores y empresarios los canales para poder realizar una reclamaci&oacute;n ante una Mutua de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social</p>', '4a04062dab5c7.jpg', '4a72aef429918.pdf', '2009-05-08', '2009-05-08', '2009-05-18', 'web', 'publicado', 1, 1, 1, 1, 1, 1, '0000-00-00 00:00:00', '2009-05-08 12:15:09', '0000-00-00 00:00:00', 0);
INSERT INTO `noticia` VALUES (125, 'Empresa y salud, la herramienta para cuidar de la salud de tu empresa', '', '<p>Te presentamos empresaysalud.es, un servicio gratuito de las Mutuas de Accidentes de Trabajo y Enfermedades Profesionales de la Seguridad Social, que pone a disposici&oacute;n de tu empresa las herramientas para mantener y mejorar la salud de las personas que trabajan en tu empresa y reducir as&iacute; el absentismo laboral.</p>', '<p>Una empresa sana, es una empresa rentable. Cuidar, mantener y mejorar la salud de las personas que trabajan en tu empresa para aumentar su competitividad est&aacute; ahora a tu alcance, date de alta en www.empresaysalud.es y cada semana, recibir&aacute;s piezas de comunicaci&oacute;n disponibles en varios idiomas y personalizadas con el logotipo de tu empresa para hacer campa&ntilde;as informativas dirigidas a promover la salud en tu centro de trabajo. Adem&aacute;s, quincenalmente recibir&aacute;s un newsletter con temas ampliados, que te ayudar&aacute;n a estar al d&iacute;a y mejorar la salud de tu empresa haci&eacute;ndola m&aacute;s competitiva.</p>', '4a49e6e038647.jpg', '4a4b139b1f1f5.pdf', '2009-06-30', '2009-06-30', '2009-07-10', 'web', 'publicado', 1, 1, 1, 1, 1, 1, '0000-00-00 00:00:00', '2009-06-30 12:13:54', '0000-00-00 00:00:00', 0);
INSERT INTO `noticia` VALUES (126, 'Curso on-line \\"Doctor vengo a por la baja\\" aspectos legales en incapacidad temporal', 'semFYC', '<p>Objetivos: Conocer la normativa actual sobre el manejo de la IT y los principios &eacute;ticos que la rigen. El objetivo del curso es dar respuesta a todos los aspectos legales de la gesti&oacute;n de la incapacidad temporal, adquiriendo conocimientos para una adecuada gesti&oacute;n de la documentaci&oacute;n de cada caso en concreto: Conocer las funciones del m&eacute;dico de familia en la gesti&oacute;n de la IT. Conocer las competencias de las mutuas, Inspecci&oacute;n M&eacute;dica, Instituto Nacional de la Seguridad Social, Servicio Regional de Salud. Resolver situaciones especiales conflictivas: aut&oacute;nomos, trabajadoras del hogar, contingencias profesionales, incapacidad permanente. Conocer las peculiaridades de la prestaci&oacute;n por maternidad y el riesgo del embarazo. Caracteristicas del curso: Curso online gratuito de 50 horas. Inscripci&oacute;n: desde el enlace www.semfyc.es/cursos Creditos: solicitada acreditaci&oacute;n por el Sistema de Acreditaci&oacute;n en Antenci&oacute;n Primaria (SaAP) y la Comisi&oacute;n de Formaci&oacute;n Continuada (CFC) del Sistema Nacional de Salud (SNS) Fecha de inscripci&oacute;n: del 7 de septiembre al 9 de octubre Fecha de realizaci&oacute;n: del 15 de octubre de 2009 al 30 de abril de 2010</p>', '<p>Objetivos: Conocer la normativa actual sobre el manejo de la IT y los principios &eacute;ticos que la rigen. El objetivo del curso es dar respuesta a todos los aspectos legales de la gesti&oacute;n de la incapacidad temporal, adquiriendo conocimientos para una adecuada gesti&oacute;n de la documentaci&oacute;n de cada caso en concreto: Conocer las funciones del m&eacute;dico de familia en la gesti&oacute;n de la IT. Conocer las competencias de las mutuas, Inspecci&oacute;n M&eacute;dica, Instituto Nacional de la Seguridad Social, Servicio Regional de Salud. Resolver situaciones especiales conflictivas: aut&oacute;nomos, trabajadoras del hogar, contingencias profesionales, incapacidad permanente. Conocer las peculiaridades de la prestaci&oacute;n por maternidad y el riesgo del embarazo. Caracteristicas del curso: Curso online gratuito de 50 horas. Inscripci&oacute;n: desde el enlace www.semfyc.es/cursos Creditos: solicitada acreditaci&oacute;n por el Sistema de Acreditaci&oacute;n en Antenci&oacute;n Primaria (SaAP) y la Comisi&oacute;n de Formaci&oacute;n Continuada (CFC) del Sistema Nacional de Salud (SNS) Fecha de inscripci&oacute;n: del 7 de septiembre al 9 de octubre Fecha de realizaci&oacute;n: del 15 de octubre de 2009 al 30 de abril de 2010</p>', '4a66bc33c67a7.jpg', '4a66bc33d138c.pdf', '2009-07-22', '2009-07-22', '2009-08-01', 'web', 'publicado', 1, 1, 1, 1, 1, 1, '0000-00-00 00:00:00', '2009-07-22 09:13:55', '0000-00-00 00:00:00', 0);
INSERT INTO `noticia` VALUES (127, 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 'AMAT', '<p>La edici�n de este folleto tiene como objetivo poner en conocimiento de los trabajadores aut�nomos de cual es la labor de las Mutuas de Accidentes de Trabajo y Enfermendades Profesionales de la Seguridad Social. Adem�s de destacar cual es el el cometido de las Mutuas, se ofrecen unas recomendaciones a tener en cuenta en el caso de accidente laboral. De igual forma, se indican los datos de contacto de las 20 Mutuas que actumente protengen a m�s de 14 millones de trabajodores en toda Espa�a.</p>', '<p>La edici&oacute;n de este folleto tiene como objetivo poner en conocimiento de los trabajadores aut&oacute;nomos de cual es la labor de las Mutuas de Accidentes de Trabajo y Enfermendades Profesionales de la Seguridad Social. Adem&aacute;s de destacar cual es el el cometido de las Mutuas, se ofrecen unas recomendaciones a tener en cuenta en el caso de accidente laboral. De igual forma, se indican los datos de contacto de las 20 Mutuas que actumente protengen a m&aacute;s de 14 millones de trabajodores en toda Espa&ntilde;a.</p><p>Escarza</p>', '4ac48136a5bb6.gif', '4ac47f4621877.pdf', '2009-10-01', '2009-10-01', '2009-10-11', 'web', 'publicado', 1, 1, 1, 1, 1, 1, '0000-00-00 00:00:00', '2009-10-01 12:07:02', '2010-01-18 09:36:15', 0);
INSERT INTO `noticia` VALUES (128, 'Moto', 'Diego', 'Probando subida de ', '<div style="padding-top: 20px;" class="noticias nuevodetalle"><a href="/uploads/file/ktm_duke_690-1280x800.jpg">uploads/file/ktm_duke_690-1280x800.jpg</a><img align="left" nottit="" style="margin-right: 10px; width: 255px; height: 159px;" src="/uploads/image/ktm_duke_690-1280x800.jpg" alt="" />Titulo<br />\r\n<p style="font-weight: bold;" class="notentrada">Entradilla</p>\r\n<p style="border-bottom: 1px dotted; margin: 10px 0px; color: rgb(204, 204, 204);">&nbsp;</p>\r\n<p>Desccripcion</p>\r\n<div class="clear">&nbsp;</div>\r\n</div>', NULL, 'a541cd47f1e5aae5212ff646bdf3f238df25d680.pdf', '2010-02-02', '2010-02-02', '2010-02-04', 'intranet', 'pendiente', 0, 25, 7, 7, 1, NULL, NULL, '2010-02-02 18:16:55', '2010-02-02 18:33:24', 1);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `notificacion`
#

CREATE TABLE `notificacion` (
  `id` bigint(20) NOT NULL auto_increment,
  `estado` varchar(255) default NULL,
  `url` varchar(255) default NULL,
  `nombre` varchar(255) default NULL,
  `contenido_notificacion_id` bigint(20) default NULL,
  `usuario_id` bigint(20) default NULL,
  `entidad_id` bigint(20) default NULL,
  `visto` bigint(20) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `contenido_notificacion_id_idx` (`contenido_notificacion_id`),
  KEY `usuario_id_idx` (`usuario_id`),
  CONSTRAINT `notificacion_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notificacion_ibfk_2` FOREIGN KEY (`contenido_notificacion_id`) REFERENCES `contenido_notificacion` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=906 DEFAULT CHARSET=latin1 AUTO_INCREMENT=906 ;

#
# Volcar la base de datos para la tabla `notificacion`
#

INSERT INTO `notificacion` VALUES (476, 'noleido', 'asambleas/ver?id=7&GrupodeTrabajo=2', 'tertertertertt', 4, 3, 7, 0, '2009-11-12 19:15:22', '2009-11-12 20:12:05', 1);
INSERT INTO `notificacion` VALUES (477, 'noleido', 'asambleas/ver?id=7&GrupodeTrabajo=2', 'tertertertertt', 4, 4, 7, 0, '2009-11-12 19:15:22', '2009-11-12 20:12:05', 1);
INSERT INTO `notificacion` VALUES (478, 'noleido', 'asambleas/ver?id=7&GrupodeTrabajo=2', 'tertertertertt', 4, 7, 7, 0, '2009-11-12 19:15:22', '2009-11-12 20:12:05', 1);
INSERT INTO `notificacion` VALUES (479, 'noleido', 'asambleas/ver?id=7&GrupodeTrabajo=2', 'tertertertertt', 4, 8, 7, 0, '2009-11-12 19:15:22', '2009-11-12 20:12:05', 1);
INSERT INTO `notificacion` VALUES (480, 'noleido', 'asambleas/ver?id=7&GrupodeTrabajo=2', 'tertertertertt', 4, 9, 7, 0, '2009-11-12 19:15:22', '2009-11-12 20:12:05', 1);
INSERT INTO `notificacion` VALUES (481, 'noleido', 'asambleas/ver?id=7&GrupodeTrabajo=2', 'tertertertertt', 4, 11, 7, 0, '2009-11-12 19:15:22', '2009-11-12 20:12:05', 1);
INSERT INTO `notificacion` VALUES (482, 'noleido', 'asambleas/ver?id=7&GrupodeTrabajo=2', 'tertertertertt', 4, 13, 7, 0, '2009-11-12 19:15:22', '2009-11-12 20:12:05', 1);
INSERT INTO `notificacion` VALUES (483, 'noleido', 'asambleas/ver?id=7&GrupodeTrabajo=2', 'tertertertertt', 4, 14, 7, 0, '2009-11-12 19:15:22', '2009-11-12 20:12:05', 1);
INSERT INTO `notificacion` VALUES (484, 'noleido', 'asambleas/ver?id=7&GrupodeTrabajo=2', 'tertertertertt', 4, 16, 7, 0, '2009-11-12 19:15:22', '2009-11-12 20:12:05', 1);
INSERT INTO `notificacion` VALUES (613, 'noleido', 'asambleas/ver?id=9&GrupodeTrabajo=2', 'Una', 4, 4, 9, 0, '2009-11-21 11:12:35', '2009-11-21 11:12:35', 0);
INSERT INTO `notificacion` VALUES (614, 'noleido', 'asambleas/ver?id=9&GrupodeTrabajo=2', 'Una', 4, 7, 9, 0, '2009-11-21 11:12:35', '2009-11-21 11:12:35', 0);
INSERT INTO `notificacion` VALUES (615, 'noleido', 'asambleas/ver?id=9&GrupodeTrabajo=2', 'Una', 4, 8, 9, 0, '2009-11-21 11:12:35', '2009-11-21 11:12:35', 0);
INSERT INTO `notificacion` VALUES (616, 'noleido', 'asambleas/ver?id=9&GrupodeTrabajo=2', 'Una', 4, 9, 9, 0, '2009-11-21 11:12:35', '2009-11-21 11:12:35', 0);
INSERT INTO `notificacion` VALUES (617, 'noleido', 'asambleas/ver?id=9&GrupodeTrabajo=2', 'Una', 4, 13, 9, 0, '2009-11-21 11:12:35', '2009-11-21 11:12:35', 0);
INSERT INTO `notificacion` VALUES (618, 'noleido', 'asambleas/ver?id=9&GrupodeTrabajo=2', 'Una', 4, 14, 9, 0, '2009-11-21 11:12:35', '2009-11-21 11:12:35', 0);
INSERT INTO `notificacion` VALUES (619, 'noleido', 'asambleas/ver?id=9&GrupodeTrabajo=2', 'Una', 4, 16, 9, 0, '2009-11-21 11:12:35', '2009-11-21 11:12:35', 0);
INSERT INTO `notificacion` VALUES (620, 'noleido', 'documentacion_grupos/show?id=4', 'edici�n', 5, 13, 4, 0, '2009-12-18 11:43:57', '2009-12-18 11:43:57', 0);
INSERT INTO `notificacion` VALUES (621, 'noleido', 'documentacion_grupos/show?id=4', 'edici�n', 5, 9, 4, 0, '2009-12-18 11:43:57', '2009-12-18 11:43:57', 0);
INSERT INTO `notificacion` VALUES (622, 'noleido', 'documentacion_grupos/show?id=4', 'edici�n', 5, 7, 4, 0, '2009-12-18 11:43:57', '2009-12-18 11:43:57', 0);
INSERT INTO `notificacion` VALUES (623, 'noleido', 'documentacion_grupos/show?id=4', 'edici�n', 5, 3, 4, 0, '2009-12-18 11:43:57', '2009-12-18 11:43:57', 0);
INSERT INTO `notificacion` VALUES (624, 'noleido', 'documentacion_grupos/show?id=4', 'edici�n', 5, 11, 4, 0, '2009-12-18 11:43:57', '2009-12-18 11:43:57', 0);
INSERT INTO `notificacion` VALUES (625, 'noleido', 'documentacion_grupos/show?id=4', 'edici�n', 5, 8, 4, 0, '2009-12-18 11:43:57', '2009-12-18 11:43:57', 0);
INSERT INTO `notificacion` VALUES (626, 'noleido', 'documentacion_grupos/show?id=4', 'edici�n', 5, 12, 4, 0, '2009-12-18 11:43:57', '2009-12-18 11:43:57', 0);
INSERT INTO `notificacion` VALUES (627, 'noleido', 'documentacion_grupos/show?id=4', 'edici�n', 5, 14, 4, 0, '2009-12-18 11:43:57', '2009-12-18 11:43:57', 0);
INSERT INTO `notificacion` VALUES (628, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 1, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (629, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 2, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (630, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 3, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (631, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 4, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (632, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 5, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (633, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 6, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (634, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 7, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (635, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 8, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (636, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 9, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (637, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 10, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (638, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 11, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (639, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 12, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (640, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 13, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (641, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 14, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (642, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 15, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (643, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 16, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (644, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 17, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (645, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 18, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (646, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios hola SOY MAURO ', 3, 19, 123, 0, '2009-12-24 15:09:01', '2009-12-24 15:09:01', 0);
INSERT INTO `notificacion` VALUES (647, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 1, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (648, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 2, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (649, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 3, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (650, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 4, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (651, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 5, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (652, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 6, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (653, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 7, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (654, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 8, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (655, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 9, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (656, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 10, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (657, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 11, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (658, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 12, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (659, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 13, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (660, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 14, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (661, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 15, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (662, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 16, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (663, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 17, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (664, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 18, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (665, 'noleido', 'noticias/show?id=123', 'Todos tenemos una Mutua que cuida de nosotros, los empresarios ', 3, 19, 123, 0, '2009-12-24 15:09:53', '2009-12-24 15:09:53', 0);
INSERT INTO `notificacion` VALUES (666, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 1, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (667, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 2, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (668, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 3, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (669, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 4, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (670, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 5, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (671, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 6, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (672, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 7, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (673, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 8, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (674, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 9, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (675, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 10, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (676, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 11, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (677, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 12, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (678, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 13, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (679, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 14, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (680, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 15, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (681, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 16, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (682, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 17, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (683, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 18, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (684, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 19, 112, 0, '2009-12-28 17:46:34', '2009-12-28 17:46:34', 0);
INSERT INTO `notificacion` VALUES (685, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 1, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (686, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 2, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (687, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 3, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (688, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 4, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (689, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 5, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (690, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 6, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (691, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 7, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (692, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 8, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (693, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 9, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (694, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 10, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (695, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 11, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (696, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 12, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (697, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 13, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (698, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 14, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (699, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 15, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (700, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 16, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (701, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 17, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (702, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 18, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (703, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 19, 112, 0, '2009-12-28 17:48:20', '2009-12-28 17:48:20', 0);
INSERT INTO `notificacion` VALUES (704, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 1, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (705, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 2, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (706, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 3, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (707, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 4, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (708, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 5, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (709, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 6, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (710, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 7, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (711, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 8, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (712, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 9, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (713, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 10, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (714, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 11, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (715, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 12, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (716, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 13, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (717, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 14, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (718, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 15, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (719, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 16, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (720, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 17, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (721, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 18, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (722, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 19, 112, 0, '2009-12-28 18:05:41', '2009-12-28 18:05:41', 0);
INSERT INTO `notificacion` VALUES (723, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 1, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (724, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 2, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (725, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 3, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (726, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 4, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (727, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 5, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (728, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 6, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (729, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 7, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (730, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 8, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (731, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 9, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (732, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 10, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (733, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 11, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (734, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 12, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (735, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 13, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (736, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 14, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (737, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 15, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (738, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 16, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (739, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 17, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (740, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 18, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (741, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 19, 112, 0, '2009-12-28 18:07:54', '2009-12-28 18:07:54', 0);
INSERT INTO `notificacion` VALUES (742, 'noleido', 'asambleas/ver?id=10&DirectoresGerente=1', 'aaa', 4, 3, 10, 0, '2009-12-29 10:10:39', '2009-12-29 10:10:39', 0);
INSERT INTO `notificacion` VALUES (743, 'noleido', 'asambleas/ver?id=10&DirectoresGerente=1', 'aaa', 4, 6, 10, 0, '2009-12-29 10:10:39', '2009-12-29 10:10:39', 0);
INSERT INTO `notificacion` VALUES (744, 'noleido', 'asambleas/ver?id=10&DirectoresGerente=1', 'aaa', 4, 7, 10, 0, '2009-12-29 10:10:39', '2009-12-29 10:10:39', 0);
INSERT INTO `notificacion` VALUES (745, 'noleido', 'asambleas/ver?id=10&DirectoresGerente=1', 'aaa', 4, 9, 10, 0, '2009-12-29 10:10:39', '2009-12-29 10:10:39', 0);
INSERT INTO `notificacion` VALUES (746, 'noleido', 'asambleas/ver?id=10&DirectoresGerente=1', 'aaa', 4, 12, 10, 0, '2009-12-29 10:10:39', '2009-12-29 10:10:39', 0);
INSERT INTO `notificacion` VALUES (747, 'noleido', 'asambleas/ver?id=10&DirectoresGerente=1', 'aaa', 4, 15, 10, 0, '2009-12-29 10:10:39', '2009-12-29 10:10:39', 0);
INSERT INTO `notificacion` VALUES (748, 'noleido', 'asambleas/ver?id=10&DirectoresGerente=1', 'aaa', 4, 16, 10, 0, '2009-12-29 10:10:39', '2009-12-29 10:10:39', 0);
INSERT INTO `notificacion` VALUES (749, 'noleido', 'asambleas/ver?id=11&DirectoresGerente=1', 'Asamblea 1', 4, 3, 11, 0, '2009-12-29 10:13:02', '2009-12-29 10:13:02', 0);
INSERT INTO `notificacion` VALUES (750, 'noleido', 'asambleas/ver?id=11&DirectoresGerente=1', 'Asamblea 1', 4, 6, 11, 0, '2009-12-29 10:13:02', '2009-12-29 10:13:02', 0);
INSERT INTO `notificacion` VALUES (751, 'noleido', 'asambleas/ver?id=11&DirectoresGerente=1', 'Asamblea 1', 4, 7, 11, 0, '2009-12-29 10:13:02', '2009-12-29 10:13:02', 0);
INSERT INTO `notificacion` VALUES (752, 'noleido', 'asambleas/ver?id=11&DirectoresGerente=1', 'Asamblea 1', 4, 9, 11, 0, '2009-12-29 10:13:03', '2009-12-29 10:13:03', 0);
INSERT INTO `notificacion` VALUES (753, 'noleido', 'asambleas/ver?id=11&DirectoresGerente=1', 'Asamblea 1', 4, 12, 11, 0, '2009-12-29 10:13:03', '2009-12-29 10:13:03', 0);
INSERT INTO `notificacion` VALUES (754, 'noleido', 'asambleas/ver?id=11&DirectoresGerente=1', 'Asamblea 1', 4, 15, 11, 0, '2009-12-29 10:13:03', '2009-12-29 10:13:03', 0);
INSERT INTO `notificacion` VALUES (755, 'noleido', 'asambleas/ver?id=11&DirectoresGerente=1', 'Asamblea 1', 4, 16, 11, 0, '2009-12-29 10:13:03', '2009-12-29 10:13:03', 0);
INSERT INTO `notificacion` VALUES (756, 'noleido', 'asambleas/ver?id=12&Junta_directiva=5', 'Prueba 3 - J-Dir', 4, 3, 12, 0, '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `notificacion` VALUES (757, 'noleido', 'asambleas/ver?id=12&Junta_directiva=5', 'Prueba 3 - J-Dir', 4, 6, 12, 0, '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `notificacion` VALUES (758, 'noleido', 'asambleas/ver?id=12&Junta_directiva=5', 'Prueba 3 - J-Dir', 4, 7, 12, 0, '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `notificacion` VALUES (759, 'noleido', 'asambleas/ver?id=12&Junta_directiva=5', 'Prueba 3 - J-Dir', 4, 9, 12, 0, '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `notificacion` VALUES (760, 'noleido', 'asambleas/ver?id=12&Junta_directiva=5', 'Prueba 3 - J-Dir', 4, 12, 12, 0, '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `notificacion` VALUES (761, 'noleido', 'asambleas/ver?id=12&Junta_directiva=5', 'Prueba 3 - J-Dir', 4, 15, 12, 0, '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `notificacion` VALUES (762, 'noleido', 'asambleas/ver?id=12&Junta_directiva=5', 'Prueba 3 - J-Dir', 4, 16, 12, 0, '2009-12-29 10:36:39', '2009-12-29 10:36:39', 0);
INSERT INTO `notificacion` VALUES (763, 'noleido', 'asambleas/ver?id=13&DirectoresGerente=1', 'Prueba 4', 4, 3, 13, 0, '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `notificacion` VALUES (764, 'noleido', 'asambleas/ver?id=13&DirectoresGerente=1', 'Prueba 4', 4, 6, 13, 0, '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `notificacion` VALUES (765, 'noleido', 'asambleas/ver?id=13&DirectoresGerente=1', 'Prueba 4', 4, 7, 13, 0, '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `notificacion` VALUES (766, 'noleido', 'asambleas/ver?id=13&DirectoresGerente=1', 'Prueba 4', 4, 9, 13, 0, '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `notificacion` VALUES (767, 'noleido', 'asambleas/ver?id=13&DirectoresGerente=1', 'Prueba 4', 4, 12, 13, 0, '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `notificacion` VALUES (768, 'noleido', 'asambleas/ver?id=13&DirectoresGerente=1', 'Prueba 4', 4, 15, 13, 0, '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `notificacion` VALUES (769, 'noleido', 'asambleas/ver?id=13&DirectoresGerente=1', 'Prueba 4', 4, 16, 13, 0, '2009-12-29 10:43:42', '2009-12-29 10:43:42', 0);
INSERT INTO `notificacion` VALUES (770, 'noleido', 'asambleas/ver?id=14&DirectoresGerente=1', 'prueba de icox', 4, 3, 14, 0, '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `notificacion` VALUES (771, 'noleido', 'asambleas/ver?id=14&DirectoresGerente=1', 'prueba de icox', 4, 6, 14, 0, '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `notificacion` VALUES (772, 'noleido', 'asambleas/ver?id=14&DirectoresGerente=1', 'prueba de icox', 4, 7, 14, 0, '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `notificacion` VALUES (773, 'noleido', 'asambleas/ver?id=14&DirectoresGerente=1', 'prueba de icox', 4, 9, 14, 0, '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `notificacion` VALUES (774, 'noleido', 'asambleas/ver?id=14&DirectoresGerente=1', 'prueba de icox', 4, 12, 14, 0, '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `notificacion` VALUES (775, 'noleido', 'asambleas/ver?id=14&DirectoresGerente=1', 'prueba de icox', 4, 14, 14, 0, '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `notificacion` VALUES (776, 'noleido', 'asambleas/ver?id=14&DirectoresGerente=1', 'prueba de icox', 4, 15, 14, 0, '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `notificacion` VALUES (777, 'noleido', 'asambleas/ver?id=14&DirectoresGerente=1', 'prueba de icox', 4, 16, 14, 0, '2009-12-29 18:11:12', '2009-12-29 18:11:12', 0);
INSERT INTO `notificacion` VALUES (778, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 1, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (779, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 2, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (780, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 3, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (781, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 4, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (782, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 5, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (783, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 6, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (784, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 7, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (785, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 8, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (786, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 9, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (787, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 10, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (788, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 11, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (789, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 12, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (790, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 13, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (791, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 14, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (792, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 15, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (793, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 16, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (794, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 17, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (795, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 18, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (796, 'noleido', 'eventos/show?id=39', 'esta es otra m�s', 1, 19, 39, 0, '2010-01-06 17:49:16', '2010-01-06 17:49:16', 0);
INSERT INTO `notificacion` VALUES (797, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 1, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (798, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 2, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (799, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 3, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (800, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 4, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (801, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 5, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (802, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 6, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (803, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 7, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (804, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 8, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (805, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 9, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (806, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 10, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (807, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 11, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (808, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 12, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (809, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 13, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (810, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 14, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (811, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 15, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (812, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 16, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (813, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 17, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (814, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 18, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (815, 'noleido', 'noticias/show?id=120', 'Las bajas laborales por enfermedad com�n lastran la recuperaci�n de las empresas', 3, 19, 120, 0, '2010-01-08 15:47:20', '2010-01-08 15:47:20', 0);
INSERT INTO `notificacion` VALUES (816, 'noleido', 'asambleas/ver?id=15&DirectoresGerente=1', 'Prueba Enero', 4, 3, 15, 0, '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `notificacion` VALUES (817, 'noleido', 'asambleas/ver?id=15&DirectoresGerente=1', 'Prueba Enero', 4, 6, 15, 0, '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `notificacion` VALUES (818, 'noleido', 'asambleas/ver?id=15&DirectoresGerente=1', 'Prueba Enero', 4, 9, 15, 0, '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `notificacion` VALUES (819, 'noleido', 'asambleas/ver?id=15&DirectoresGerente=1', 'Prueba Enero', 4, 12, 15, 0, '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `notificacion` VALUES (820, 'noleido', 'asambleas/ver?id=15&DirectoresGerente=1', 'Prueba Enero', 4, 14, 15, 0, '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `notificacion` VALUES (821, 'noleido', 'asambleas/ver?id=15&DirectoresGerente=1', 'Prueba Enero', 4, 15, 15, 0, '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `notificacion` VALUES (822, 'noleido', 'asambleas/ver?id=15&DirectoresGerente=1', 'Prueba Enero', 4, 16, 15, 0, '2010-01-12 09:06:59', '2010-01-12 09:06:59', 0);
INSERT INTO `notificacion` VALUES (823, 'noleido', 'documentacion_consejos/show?id=2', 'Actas de Reuni�n', 6, 16, 2, 0, '2010-01-12 10:52:31', '2010-01-12 10:52:31', 0);
INSERT INTO `notificacion` VALUES (824, 'noleido', 'documentacion_consejos/show?id=2', 'Actas de Reuni�n', 6, 9, 2, 0, '2010-01-12 10:52:31', '2010-01-12 10:52:31', 0);
INSERT INTO `notificacion` VALUES (825, 'noleido', 'documentacion_consejos/show?id=2', 'Actas de Reuni�n', 6, 7, 2, 0, '2010-01-12 10:52:31', '2010-01-12 10:52:31', 0);
INSERT INTO `notificacion` VALUES (826, 'noleido', 'documentacion_consejos/show?id=2', 'Actas de Reuni�n', 6, 11, 2, 0, '2010-01-12 10:52:31', '2010-01-12 10:52:31', 0);
INSERT INTO `notificacion` VALUES (827, 'noleido', 'documentacion_consejos/show?id=2', 'Actas de Reuni�n', 6, 12, 2, 0, '2010-01-12 10:52:31', '2010-01-12 10:52:31', 0);
INSERT INTO `notificacion` VALUES (828, 'noleido', 'documentacion_consejos/show?id=2', 'Actas de Reuni�n', 6, 14, 2, 0, '2010-01-12 10:52:31', '2010-01-12 10:52:31', 0);
INSERT INTO `notificacion` VALUES (829, 'noleido', 'documentacion_consejos/show?id=2', 'Actas de Reuni�n', 6, 7, 2, 0, '2010-01-12 10:53:40', '2010-01-12 10:53:40', 0);
INSERT INTO `notificacion` VALUES (830, 'noleido', 'documentacion_consejos/show?id=2', 'Actas de Reuni�n', 6, 14, 2, 0, '2010-01-12 10:53:40', '2010-01-12 10:53:40', 0);
INSERT INTO `notificacion` VALUES (831, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 1, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (832, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 2, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (833, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 3, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (834, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 4, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (835, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 5, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (836, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 6, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (837, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 7, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (838, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 8, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (839, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 9, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (840, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 10, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (841, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 11, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (842, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 12, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (843, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 13, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (844, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 14, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (845, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 15, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (846, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 16, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (847, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 17, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (848, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 18, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (849, 'noleido', 'noticias/show?id=127', 'Todos tenemos una Mutua que cuida de nosotros, los aut�nomos', 3, 19, 127, 0, '2010-01-18 09:36:15', '2010-01-18 09:36:15', 0);
INSERT INTO `notificacion` VALUES (850, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 1, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (851, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 2, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (852, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 3, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (853, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 4, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (854, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 5, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (855, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 6, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (856, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 7, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (857, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 8, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (858, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 9, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (859, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 10, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (860, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 11, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (861, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 12, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (862, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 13, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (863, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 14, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (864, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 15, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (865, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 16, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (866, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 17, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (867, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 18, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (868, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 19, 112, 0, '2010-01-18 11:53:40', '2010-01-18 11:53:40', 0);
INSERT INTO `notificacion` VALUES (869, 'noleido', 'asambleas/ver?id=16&GrupodeTrabajo=2', 'Mikel Prueba', 4, 3, 16, 0, '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `notificacion` VALUES (870, 'noleido', 'asambleas/ver?id=16&GrupodeTrabajo=2', 'Mikel Prueba', 4, 4, 16, 0, '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `notificacion` VALUES (871, 'noleido', 'asambleas/ver?id=16&GrupodeTrabajo=2', 'Mikel Prueba', 4, 7, 16, 0, '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `notificacion` VALUES (872, 'noleido', 'asambleas/ver?id=16&GrupodeTrabajo=2', 'Mikel Prueba', 4, 9, 16, 0, '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `notificacion` VALUES (873, 'noleido', 'asambleas/ver?id=16&GrupodeTrabajo=2', 'Mikel Prueba', 4, 14, 16, 0, '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `notificacion` VALUES (874, 'noleido', 'asambleas/ver?id=16&GrupodeTrabajo=2', 'Mikel Prueba', 4, 16, 16, 0, '2010-01-18 12:32:25', '2010-01-18 12:32:25', 0);
INSERT INTO `notificacion` VALUES (875, 'noleido', 'documentacion_grupos/show?id=7', 'Carpeta 1 (Mikel)', 5, 7, 7, 0, '2010-01-18 12:39:46', '2010-01-18 12:39:46', 0);
INSERT INTO `notificacion` VALUES (876, 'noleido', 'documentacion_grupos/show?id=7', 'Carpeta 1 (Mikel)', 5, 3, 7, 0, '2010-01-18 12:39:46', '2010-01-18 12:39:46', 0);
INSERT INTO `notificacion` VALUES (877, 'noleido', 'documentacion_grupos/show?id=7', 'Carpeta 1 (Mikel)', 5, 14, 7, 0, '2010-01-18 12:39:46', '2010-01-18 12:39:46', 0);
INSERT INTO `notificacion` VALUES (878, 'noleido', 'asambleas/ver?id=17&DirectoresGerente=1', 'prueba de icox ', 4, 11, 17, 0, '2010-01-18 16:27:52', '2010-01-18 16:27:52', 0);
INSERT INTO `notificacion` VALUES (879, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 1, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (880, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 2, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (881, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 3, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (882, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 4, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (883, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 5, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (884, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 6, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (885, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 7, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (886, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 8, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (887, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 9, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (888, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 10, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (889, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 11, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (890, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 12, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (891, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 13, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (892, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 14, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (893, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 15, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (894, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 16, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (895, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 17, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (896, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 18, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (897, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 19, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (898, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 20, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (899, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 21, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (900, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 22, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (901, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 23, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (902, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 24, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (903, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 25, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (904, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 26, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);
INSERT INTO `notificacion` VALUES (905, 'noleido', 'noticias/show?id=112', 'Mutua Universal participar� en el III Congreso de Actualidad Laboral', 3, 27, 112, 0, '2010-01-28 08:54:59', '2010-01-28 08:54:59', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `novedad`
#

CREATE TABLE `novedad` (
  `id` bigint(20) NOT NULL auto_increment,
  `titulo` varchar(100) NOT NULL,
  `autor` varchar(100) NOT NULL,
  `entradilla` longtext NOT NULL,
  `contenido` longtext,
  `imagen` varchar(255) default NULL,
  `documento` varchar(255) default NULL,
  `fecha` date NOT NULL,
  `fecha_publicacion` date NOT NULL,
  `fecha_caducidad` date NOT NULL,
  `ambito` varchar(255) default NULL,
  `estado` varchar(255) default NULL,
  `destacada` tinyint(1) default NULL,
  `mutua_id` bigint(20) default NULL,
  `owner_id` bigint(20) default NULL,
  `user_id_creador` bigint(20) default NULL,
  `user_id_modificado` bigint(20) default NULL,
  `user_id_publicado` bigint(20) default NULL,
  `fecha_publicado` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `mutua_id_idx` (`mutua_id`),
  KEY `owner_id_idx` (`owner_id`),
  CONSTRAINT `novedad_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `novedad_ibfk_2` FOREIGN KEY (`mutua_id`) REFERENCES `mutua` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

#
# Volcar la base de datos para la tabla `novedad`
#


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `organismo`
#

CREATE TABLE `organismo` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `detalle` longtext,
  `grupo_trabajo_id` bigint(20) NOT NULL,
  `categoria_organismo_id` bigint(20) default NULL,
  `subcategoria_organismo_id` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `grupo_trabajo_id_idx` (`grupo_trabajo_id`),
  KEY `categoria_organismo_id_idx` (`categoria_organismo_id`),
  KEY `subcategoria_organismo_id_idx` (`subcategoria_organismo_id`),
  CONSTRAINT `organismo_ibfk_1` FOREIGN KEY (`subcategoria_organismo_id`) REFERENCES `sub_categoria_organismo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `organismo_ibfk_2` FOREIGN KEY (`grupo_trabajo_id`) REFERENCES `grupo_trabajo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `organismo_ibfk_3` FOREIGN KEY (`categoria_organismo_id`) REFERENCES `categoria_organismo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

#
# Volcar la base de datos para la tabla `organismo`
#

INSERT INTO `organismo` VALUES (1, 'prueba de icox', '<p><img alt="" align="left" nottit="" style="width: 69px; margin-right: 10px; height: 65px" src="/uploads/image/noimage.jpg" /></p><p><a href="#"><strong>T&iacute;tulo documentaci&oacute;n 1</strong></a></p><p>Descripci&oacute;n 1 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>', 1, 1, 1, '2009-11-19 17:55:57', '2009-12-24 13:39:40', 0);
INSERT INTO `organismo` VALUES (2, 'Recursos Sanitarios II', '<p>&nbsp;</p><p>&nbsp;</p>', 1, NULL, NULL, '2009-12-22 08:58:06', '2009-12-22 08:58:06', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `publicacion`
#

CREATE TABLE `publicacion` (
  `id` bigint(20) NOT NULL auto_increment,
  `titulo` varchar(100) default NULL,
  `autor` varchar(100) NOT NULL,
  `contenido` longtext,
  `imagen` varchar(255) default NULL,
  `documento` varchar(255) default NULL,
  `fecha` date NOT NULL,
  `fecha_publicacion` date NOT NULL,
  `fecha_caducidad` date NOT NULL,
  `ambito` varchar(255) default NULL,
  `estado` varchar(255) default NULL,
  `destacada` tinyint(1) default NULL,
  `mutua_id` bigint(20) default NULL,
  `owner_id` bigint(20) default NULL,
  `user_id_creador` bigint(20) default NULL,
  `user_id_modificado` bigint(20) default NULL,
  `user_id_publicado` bigint(20) default NULL,
  `fecha_publicado` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `mutua_id_idx` (`mutua_id`),
  KEY `owner_id_idx` (`owner_id`),
  CONSTRAINT `publicacion_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `publicacion_ibfk_2` FOREIGN KEY (`mutua_id`) REFERENCES `mutua` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

#
# Volcar la base de datos para la tabla `publicacion`
#

INSERT INTO `publicacion` VALUES (3, 'Lo que el empresario debe saber sobre Prevenci�n de Riesgos Laborales', 'AMAT', 'Publicaci�n que pone a disposici�n del empresario un elemento informativo y operativo que le ayudase a conocer y asumir su papel en la Cultura Preventiva, mediante el conocimiento de lo que debe saber y lo que debe hacer en su empresa en ese campo.', '49ae9be441d79.jpg', '49ae9be452eeb.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 10:45:54', NULL, 0);
INSERT INTO `publicacion` VALUES (4, 'La Auditoria de Prevenci�n de Riesgos Laborales en la PYME', 'AMAT', 'Este documento contiene una serie de preguntas que contestadas francamente y valoradas a trav�s de una sencilla f�rmula, nos da una visi�n de la situaci�n real de la empresa, poniendo de relieve aquellos aspectos de la prevenci�n de riesgos laborales sobre los que se deber�a incidir para pasar una Auditor�a de Prevenci�n de manera satisfactoria.', '49ae9c4729a47.jpg', '49ae9c473abb7.pdf', '1999-01-01', '1999-01-01', '1999-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 10:48:42', NULL, 0);
INSERT INTO `publicacion` VALUES (10, 'Revista: Estamos de Acuerdo, Prevenir los riesgos laborales es rentable para todos', 'AMAT', 'Los contenidos de esta revista son reflexiones sobre la prevenci�n de riesgos laborales en cuanto a las causas, costes, evaluaci�n, investigaci�n y prevenci�n de accidentes.', '49ae72484800a.jpg', '', '1998-01-01', '1998-01-01', '1998-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 10:53:07', NULL, 0);
INSERT INTO `publicacion` VALUES (13, 'Manual de Gesti�n de la Actividad Preventiva', 'AMAT', 'El presente Manual muestra los distintos aspectos que tiene que tratar un sistema de gesti�n en prevenci�n de riesgos laborales. A dicha explicaci�n se adjuntan modelos de registros.', '49ae9cc022951.jpg', '49ae9cc02ec9b.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 10:55:29', NULL, 0);
INSERT INTO `publicacion` VALUES (14, 'Recomendaciones b�sicas de seguridad y salud. Versi�n en Castellano', 'AMAT', 'El variado contenido de esta gu�a trata los factores y riesgos presentes en diversos tipos de trabajos dentro de diferentes actividades. Se establecen recomendaciones de seguridad y salud para eliminar situaciones de riesgo, m�todos de trabajo seguro y medidas de emergencia.', '49ae7a916023f.jpg', '49ae7a9169e8e.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 10:55:56', NULL, 0);
INSERT INTO `publicacion` VALUES (15, 'Recomendaciones b�sicas de seguridad y salud. Versi�n en Ingl�s', 'AMAT', 'El variado contenido de esta gu�a trata los factores y riesgos presentes en diversos tipos de trabajos dentro de diferentes actividades. Se establecen recomendaciones de seguridad y salud para eliminar situaciones de riesgo, m�todos de trabajo seguro y medidas de emergencia.', '49ae7b0cae887.jpg', '49ae7b0cbfa06.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 10:57:08', NULL, 0);
INSERT INTO `publicacion` VALUES (16, 'Recomendaciones b�sicas de seguridad y salud. Versi�n en �rabe', 'AMAT', 'El variado contenido de esta gu�a trata los factores y riesgos presentes en diversos tipos de trabajos dentro de diferentes actividades. Se establecen recomendaciones de seguridad y salud para eliminar situaciones de riesgo, m�todos de trabajo seguro y medidas de emergencia.', '49ae96fee2b1d.jpg', '49ae96fef3c98.pdf', '2004-01-01', '2004-01-01', '2004-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 10:57:44', NULL, 0);
INSERT INTO `publicacion` VALUES (17, 'Recomendaciones b�sicas de seguridad y salud. Versi�n en Chino Com�n', 'AMAT', 'El variado contenido de esta gu�a trata los factores y riesgos presentes en diversos tipos de trabajos dentro de diferentes actividades. Se establecen recomendaciones de seguridad y salud para eliminar situaciones de riesgo, m�todos de trabajo seguro y medidas de emergencia.', '49ae7beac76e3.jpg', '49ae7bead8850.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 10:59:37', NULL, 0);
INSERT INTO `publicacion` VALUES (18, 'Recomendaciones b�sicas de seguridad y salud. Versi�n en Polaco', 'AMAT', 'El variado contenido de esta gu�a trata los factores y riesgos presentes en diversos tipos de trabajos dentro de diferentes actividades. Se establecen recomendaciones de seguridad y salud para eliminar situaciones de riesgo, m�todos de trabajo seguro y medidas de emergencia.', '49ae7c49bddf6.jpg', '49ae7c49cef5d.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 11:00:05', NULL, 0);
INSERT INTO `publicacion` VALUES (19, 'Recomendaciones b�sicas de seguridad y salud. Versi�n en Rumano', 'AMAT', 'El variado contenido de esta gu�a trata los factores y riesgos presentes en diversos tipos de trabajos dentro de diferentes actividades. Se establecen recomendaciones de seguridad y salud para eliminar situaciones de riesgo, m�todos de trabajo seguro y medidas de emergencia.', '49aeaace405e7.jpg', '49aeaace5175d.pdf', '2004-01-01', '2004-01-01', '2004-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 11:00:31', NULL, 0);
INSERT INTO `publicacion` VALUES (20, 'Gu�a de coordinaci�n de actividades empresariales', 'AMAT', '<p>En esta publicaci&oacute;n se desarrollan los distintos supuestos en los que es necesaria la coordinaci&oacute;n que surge de la concurrencia de trabajadores de varias empresas en un mismo centro de trabajo (con empresario titular, con empresario principal o ausencia de los ambos).</p><p>Escarza</p>', '49ae78948d6c1.jpg', '49ae789499a0b.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, 1, NULL, NULL, '2008-10-22 11:00:59', '2010-01-18 09:37:05', 0);
INSERT INTO `publicacion` VALUES (21, 'Manual de Buenas Pr�cticas en Prevenci�n de Riesgos Laborales. General.', 'AMAT', 'El presente manual recoge todos los aspectos a tener en cuenta para realizar un manual de Buenas Pr�cticas en cualquier empresa.', '49ae99d82f9d9.jpg', '49ae99d840b3f.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 11:15:21', NULL, 0);
INSERT INTO `publicacion` VALUES (22, 'Manual de Buenas Pr�cticas en Prevenci�n de Riesgos Laborales. Construcci�n.', 'AMAT', 'El presente manual recoge todos los aspectos a tener en cuenta para realizar un manual de Buenas Pr�cticas en cualquier empresa.', '49ae9a9ae242a.jpg', '49ae9a9af0e84.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 11:15:47', NULL, 0);
INSERT INTO `publicacion` VALUES (23, 'Manual de Buenas Pr�cticas en Prevenci�n de Riesgos Laborales. Talleres Mec�nicos.', 'AMAT', 'El presente manual recoge todos los aspectos a tener en cuenta para realizar un manual de Buenas Pr�cticas en cualquier empresa.', '49ae98ab36491.jpg', '49ae98ab400cb.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 11:16:19', NULL, 0);
INSERT INTO `publicacion` VALUES (24, 'Manual de Buenas Pr�cticas en Prevenci�n (Mikel II) de Riesgos Laborales. Hosteler�a.', 'AMAT', '<p>El presente manual recoge todos los aspectos a tener en cuenta para realizar un manual de Buenas Pr&aacute;cticas en cualquier empresa.</p>', '49ae97e30505b.jpg', '49ae97e30ec97.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, 7, NULL, NULL, '2008-10-22 11:16:42', '2009-12-28 09:54:31', 0);
INSERT INTO `publicacion` VALUES (25, 'Nuevo Cuadro de Enfermedades Profesionales', 'AMAT', 'Tras la modificaci�n del cuadro de enfermedades profesionales, era imprescindible una nueva publicaci�n que recoja las novedades legislativas en este importante campo.', '49ae77be1f17b.jpg', '49ae77be2b4c8.pdf', '2007-01-01', '2007-01-01', '2007-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2008-10-22 11:17:25', NULL, 0);
INSERT INTO `publicacion` VALUES (28, 'Incapacidad Temporal, Manual para el manejo en atenci�n primaria', 'AMAT', 'La edici�n de este manual va dirigido a todos aquellos m�dicos que en el desarrollo de su actividad profesional se ocupan, al menos durante parte de ella, de la atenci�n a los trabajadores en situaci�n de incapacidad temporal. Pero tambi�n a todos aquellos profesionales, sanitarios o no, que quieran aproximarse al conocimiento de la gesti�n de la incapacidad temporal desde una amplia y actualizada perspectiva.', '49ae752053596.jpg', '49ae752062000.pdf', '2009-01-28', '2009-01-28', '0000-00-00', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2009-03-04 13:33:36', NULL, 0);
INSERT INTO `publicacion` VALUES (29, 'Gu�a M�dica para la Valoraci�n de los Riesgos Profesionales a efectos de la Prestaci�n de Riesgo dur', 'AMAT', '', '49aead7f5a482.jpg', '49aead7f6b603.pdf', '2009-01-01', '2009-01-01', '2009-01-11', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2009-03-04 17:34:07', NULL, 0);
INSERT INTO `publicacion` VALUES (32, 'Prevea, una alianza con voluntad de mejora', 'Mutua Universal, Pere Teixid� i Camp�s', 'La voluntariedad es la palanca que implementa una actividad preventiva sostenida y sostenible capaz de alcanzar una reducci�n efectiva de la siniestralidad.', '4a014d181a263.jpg', '4a014d184de5e.pdf', '2008-12-22', '2008-12-22', '0000-00-00', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2009-05-06 10:40:56', NULL, 0);
INSERT INTO `publicacion` VALUES (33, 'La prevenci�n en �poca de crisis', 'Pere Teixido- Mutua Universal', 'Este art�culo es el fruto de la observaci�n de algunas reacciones ocurridas en el �mbito empresarial, tanto espa�ol como europeo, en las cuales se manifestaba una preocupaci�n por adecuar las actuaciones en prevenci�n de riesgos laborales a la actual crisis econ�mica o en una expresi�n m�s coloquial a la situaci�n de vacas flacas. Se trata de una preocupaci�n leg�tima que debe ser tomada en consideraci�n y resuelta por v�as algo m�s sofisticadas que las del puro recorte.\r\n\r\nSe propone una reflexi�n sobre la forma en que se producen y se propagan las crisis, las consecuencias que acarrean y el riesgo de tomar decisiones equivocadas que conduzcan a inhabilitar precisamente los mecanismos que las empresas tienen para hacer frente a situaciones cr�ticas. \r\n\r\nLa reflexi�n se apoya en conceptos de la teor�a de la complejidad y de la teor�a de las redes aplicados a las organizaciones empresariales, de los cuales se da una informaci�n sucinta que, quien dese�, podr� ampliar con la bibliograf�a que se cita al final; pero se pasa r�pidamente a tratar los aspectos m�s pr�cticos y operativos. \r\n\r\nEntre estos �ltimos est� el papel que la prevenci�n juega no s�lo en la reducci�n del gasto, sino tambi�n en el desarrollo de negocio, papel que para desplegarse requiere superar la etapa de la prevenci�n\r\npor obligaci�n y acceder a �La prevenci�n seg�n necesidades�.\r\n\r\nSe brinda una breve rese�a del marco propicio para lo anterior en materia de estrategia europea y espa�ola, as� como en avances de sistemas de aseguramiento que contemplan tanto la inclusi�n de la prevenci�n entre sus prestaciones, como la repercusi�n de sus resultados en la mec�nica de cotizaci�n.\r\n\r\nSe informa sobre las principales disposiciones de la Orden TAS/3623/2006, que facilitan la cooperaci�n de las Mutuas de Accidentes de Trabajo con sus asociados en este paso hacia la actuaci�n seg�n necesidades y se resalta como muestra de dicha cooperaci�n el Programa Prevea sobre el cual se ha dado extensa informaci�n en art�culos anteriores.\r\n\r\nEn s�ntesis se estimula a empresarios y trabajadores a hacer uso y sacar provecho en estas �pocas dif�ciles, de lo que las Mutuas est�n en condiciones de proporcionar y quieren proporcionar, por el hecho de compartir, la necesidad de reducir la siniestralidad al ser �sta una amenaza constante a la viabilidad de las empresas y a la sostenibilidad de las Mutuas.\r\n\r\nPor �ltimo, se explica el modelo de trabajo que Mutua Universal ha elaborado al respecto de la prevenci�n seg�n necesidades y se da noticia de algunas de sus consecuencias en la forma de productos espec�ficos para la reducci�n de la siniestralidad y para la impulsi�n de una cultura, clima y pr�cticas laborales que proporcionen un ambiente capaz de promover la efectividad de la organizaci�n.\r\n', '', '4a70321c5f328.pdf', '2009-07-29', '2009-07-29', '0000-00-00', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2009-07-29 13:27:24', NULL, 0);
INSERT INTO `publicacion` VALUES (34, 'Gu�a para la elaboraci�n del plan de actuaci�n de las empresas o centros de trabajo frente a emergen', 'Ministerio de Sanidad, UGT, CCOO, CEOE, CEPYME', '', '4aa7533f5371d.jpg', '4aa7533f5a475.pdf', '2009-09-09', '2009-09-09', '2009-09-19', 'web', 'publicado', 0, 1, 1, NULL, NULL, NULL, NULL, '2009-09-09 09:03:27', NULL, 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `rol`
#

CREATE TABLE `rol` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(150) default NULL,
  `detalle` longtext,
  `codigo` varchar(32) NOT NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

#
# Volcar la base de datos para la tabla `rol`
#

INSERT INTO `rol` VALUES (1, 'S�per - administrador', '', 'superadmin', '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `rol` VALUES (2, 'Administrador', '', 'admin', '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `rol` VALUES (3, 'Director Gerente', '', 'director', '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `rol` VALUES (4, 'Miembro GT', '', 'miembrogt', '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `rol` VALUES (5, 'Miembro CT', '', 'miembroct', '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `rol` VALUES (6, 'Responsable Grupo de Trabajo', '', 'grupotrabajo', '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `rol` VALUES (7, 'Responsable Centro Territorial', '', 'centroterritorial', '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `rol` VALUES (8, 'DGOSS', '', 'dgoss', '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `rol` VALUES (9, 'Usuario B�sico', NULL, 'Usuario_B�sico', '2009-12-21 15:32:58', '2009-12-21 15:32:58', 0);
INSERT INTO `rol` VALUES (10, 'Prueba de icox ', '', 'Prueba_de_icox', '2010-01-18 18:25:05', '2010-01-18 18:35:24', 1);
INSERT INTO `rol` VALUES (11, 'Prueba de icox ', '', 'Prueba_de_icox', NULL, '2010-01-18 18:39:20', 1);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `solicitud_clave`
#

CREATE TABLE `solicitud_clave` (
  `id` bigint(20) NOT NULL auto_increment,
  `usuario_id` bigint(20) NOT NULL,
  `codigo` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `usuario_id_idx` (`usuario_id`),
  CONSTRAINT `solicitud_clave_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

#
# Volcar la base de datos para la tabla `solicitud_clave`
#

INSERT INTO `solicitud_clave` VALUES (3, 7, '4b55884e68e2b', '2010-01-19 11:24:14', '2010-01-19 11:24:14');

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `sub_categoria_organismo`
#

CREATE TABLE `sub_categoria_organismo` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `categoria_organismo_id` bigint(20) NOT NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `categoria_organismo_id_idx` (`categoria_organismo_id`),
  CONSTRAINT `sub_categoria_organismo_ibfk_1` FOREIGN KEY (`categoria_organismo_id`) REFERENCES `categoria_organismo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

#
# Volcar la base de datos para la tabla `sub_categoria_organismo`
#

INSERT INTO `sub_categoria_organismo` VALUES (1, 'prueba de icox para las sub categorias ', 1, '2009-11-19 16:24:50', '2009-11-19 16:24:50', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `tipo_comunicado`
#

CREATE TABLE `tipo_comunicado` (
  `id` bigint(20) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `imagen` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

#
# Volcar la base de datos para la tabla `tipo_comunicado`
#

INSERT INTO `tipo_comunicado` VALUES (1, 'Noticia', NULL, '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `tipo_comunicado` VALUES (2, 'Circular', NULL, '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `tipo_comunicado` VALUES (3, 'Comunicacion interna', NULL, '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `usuario`
#

CREATE TABLE `usuario` (
  `id` bigint(20) NOT NULL auto_increment,
  `login` varchar(150) default NULL,
  `crypted_password` varchar(150) default NULL,
  `salt` varchar(255) default NULL,
  `nombre` varchar(150) NOT NULL,
  `apellido` varchar(150) NOT NULL,
  `email` varchar(150) default NULL,
  `activo` tinyint(1) default '0',
  `telefono` varchar(150) default NULL,
  `remember_token` varchar(150) default NULL,
  `remember_token_expires` varchar(150) default NULL,
  `mutua_id` bigint(20) NOT NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `mutua_id_idx` (`mutua_id`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`mutua_id`) REFERENCES `mutua` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

#
# Volcar la base de datos para la tabla `usuario`
#

INSERT INTO `usuario` VALUES (1, 'admin', '6107e0d3e6ba1af3efecb2c54941ec199c7a6f29', 'ccf3d6098d11f3de070a95dff1e434eb08de17a8', 'Admin', 'Admin', NULL, 1, NULL, NULL, NULL, 1, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario` VALUES (2, 'carolinadomec', '6107e0d3e6ba1af3efecb2c54941ec199c7a6f29', 'ccf3d6098d11f3de070a95dff1e434eb08de17a8', 'Carolina', 'Domec', NULL, 1, NULL, NULL, NULL, 1, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario` VALUES (3, 'mauro', 'a5906ca325f493829052f5b5ffaa7545a89a8822', '79496bad43a5d723b2d05f1a9d19b3e161783bfc', 'Mauro', 'garcia', 'mauro@icox.com', 1, '', NULL, NULL, 1, '2009-10-20 17:49:34', '2010-01-21 16:55:25', 0);
INSERT INTO `usuario` VALUES (4, 'pablo', 'f59ac4c457dd40d3ac90d05951ce7e5ad6069ee5', 'baa3e7e4cb9c09a41298b83daaad3b91009e6873', 'Pablo', 'peralta', NULL, 1, NULL, NULL, NULL, 1, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario` VALUES (5, 'user', 'f0a920de5189ef0d30dc2d5d8911695c79a234f2', 'de26c603cb8de640f906d5d668f1e9d39ef55b7b', 'user', 'user', NULL, 1, NULL, NULL, NULL, 1, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario` VALUES (6, 'leandro', '546e6acf7fdb8c126df9c6d56d7f4edec9b29d6e', 'be9dcf9dd08bcab9e3faab70ecff7e8ed50f1a60', 'Leandro', 'icox', NULL, 1, NULL, NULL, NULL, 1, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario` VALUES (7, 'mikel', '9e91a74fe3060af4b4ea4a925931661ad1a02fba', '7f290e41c4917a5a86e66f1825f2fc2d8ac89082', 'Mikel', 'Escarza', 'mikel.escarza@amat.es', 1, '', NULL, NULL, 25, '2009-10-21 20:44:18', '2009-12-29 19:35:53', 0);
INSERT INTO `usuario` VALUES (8, 'nieves', '83a5c79431eddbf07a13cc010c1586f22027bd83', '24bc2d40bb5f1588a854b889f65813706d0547d3', 'Nieves', 'L�pez', 'nieves.lopez@amat.es', 1, '', NULL, NULL, 1, '2009-10-29 12:00:02', '2009-12-29 09:48:03', 0);
INSERT INTO `usuario` VALUES (9, 'mikelMGT', 'b3aaa49637fb4e015b25429113f84bb912b8a731', 'c74a869156f1376109d7e048e2f550f9fee739fc', 'Miguel Angel', 'Escarza', 'mescarza@terra.es', 1, '', NULL, NULL, 25, '2009-10-29 12:01:19', '2009-12-29 09:16:45', 0);
INSERT INTO `usuario` VALUES (10, 'dgodoy', '02fc0729ca43ea25daa86073d69d01985d91a58b', 'a704bdae76cb04e9e23652aac36443bd4a2f1e74', 'Diego', 'Godoy', 'dgodoy@icox.com', 1, '4884425', NULL, NULL, 2, '2009-10-29 22:25:52', '2009-10-29 22:26:05', 1);
INSERT INTO `usuario` VALUES (11, 'ddgodoy', '1b88a9c4d6a7db40f6f386706772ca550d8382cb', '3d95b5cf5055dec1c5805a282d8c344db2df6ee5', 'Diego', 'Godoy', 'dgodoy@icox.com', 1, '4884425', NULL, NULL, 1, '2009-10-29 22:28:33', '2010-01-21 16:44:26', 0);
INSERT INTO `usuario` VALUES (12, 'plopez', '12711ff61e28e4071c0cd4c5f8f8dcbb56daecba', 'fc6f4a1f33c46a035b9e61532a3913235f01bba9', 'Pedro', 'Lopez', 'dgodoy@gmail.com', 1, '4884425', NULL, NULL, 1, '2009-10-29 22:42:16', '2009-12-18 09:55:38', 0);
INSERT INTO `usuario` VALUES (13, 'elena', 'b95ce4f84c78c74b8124d6ed316cc998be58cea9', '6672bc6e5c9557a78a31650db833386742e93832', 'Elena', 'Escarpa', 'elena.escarpa@amat.es', 1, '', NULL, NULL, 25, '2009-10-30 10:17:00', '2009-12-22 09:56:45', 0);
INSERT INTO `usuario` VALUES (14, 'felix', '72099c01f465b688b93987be85ad37878bfc1d7c', '89d273c76a2807f28a903924ec05c3637e23d971', 'Felix', 'Mu�oz', 'felix.munoz@amat.es', 1, '', NULL, NULL, 25, '2009-10-30 10:18:41', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario` VALUES (15, 'piruleta', '60742437967fbca8a605587f1a9045dca8ac9ebc', '0eb57c60c7e346395f32b196432bd6acc3de4a7a', 'Ra�l ', 'Mata', 'raulmatajimenez@gmail.com', 1, '+34600578612', NULL, NULL, 1, '2009-11-07 11:37:27', '2009-11-07 11:37:28', 0);
INSERT INTO `usuario` VALUES (16, 'mikelRS', 'eaf8f9f20c8279853d1ffca5e8ca61a7d54e39ad', '998a8a598e723c993403ea2d4d3efd9659195246', 'Miguel Angel ', 'Escarza', 'mikelescarza@terra.es', 1, '', NULL, NULL, 1, '2009-11-07 18:58:11', '2009-11-07 18:58:11', 0);
INSERT INTO `usuario` VALUES (17, 'mikelb', '4bed78c1ccd13c7f90f9f5443cbfadc2a219e550', '12ba82bc33a37b4464935e01823647c44ff79498', 'Usuario ', 'B�sico', 'mescarza@terra.es', 1, '', NULL, NULL, 25, '2009-12-18 12:02:09', '2009-12-21 19:12:12', 1);
INSERT INTO `usuario` VALUES (18, 'Miguel.Blanch ', '9c9f40d130a7b02a189414ed34fb9e9a694cca04', '4b932fe274ca483f587bc56f6738074241e34162', 'Miguel', 'Blanch Ferrarons', 'mblanch@mutua-intercomarcal.com', 1, '93 486 74 00', NULL, NULL, 12, '2009-12-18 13:43:14', '2009-12-22 09:12:23', 1);
INSERT INTO `usuario` VALUES (19, 'mikelbasico', '22d8eb010948027075cd9879549dfe5dda6271cd', 'd431ad10aa1c303cc85537d9b60bc4ea45847230', 'Usuario', 'B�sico', 'mescarza@terra.es', 1, '', NULL, NULL, 25, '2009-12-21 19:13:10', '2009-12-21 19:13:10', 0);
INSERT INTO `usuario` VALUES (20, 'jchaquet', '80bf33ecb00add7fa9b887a85672062cfbd2c308', 'fd19bad7dceb9372397f89b8735254c28e727958', 'jacobo', 'chaquet', 'jchaquet@ingenieria-web.es', 1, '', NULL, NULL, 1, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario` VALUES (21, 'test', '4ee5e7113f586600ea460dd4a6f1d205ee57bbc7', '86941661f3032f0ec4a7eebb93a4a32a7a354d74', 'test', 'test', 'jchaquet@icoxsamarco.com', 1, 'test', NULL, NULL, 1, '2010-01-20 14:22:59', '2010-01-21 11:59:51', 1);
INSERT INTO `usuario` VALUES (22, 'test', NULL, NULL, 'test', 'test', 'jacobo@icoxsamarco.com', 1, '123123', NULL, NULL, 1, '2010-01-20 14:24:48', '2010-01-20 14:30:00', 1);
INSERT INTO `usuario` VALUES (23, 'test', NULL, NULL, 'test', 'test', 'jacobo@icoxsamarco.com', 1, '6512345632', NULL, NULL, 1, '2010-01-21 11:29:07', '2010-01-21 11:43:10', 1);
INSERT INTO `usuario` VALUES (24, 'test2', 'ef0e36309c52d855b946ea3620f8ad6896564cf2', 'd07a9f901af7b319de32062ea8aa9a5c4b529cea', 'test2', 'test', 'jacobo@icoxsamarco.com', 1, '12321321', NULL, NULL, 1, '2010-01-21 11:47:59', '2010-01-21 11:50:23', 1);
INSERT INTO `usuario` VALUES (25, 'test', NULL, NULL, 'test', 'test', 'jacobo@icoxsamarco.com', 1, '999999', NULL, NULL, 1, '2010-01-21 11:54:34', '2010-01-21 12:02:08', 0);
INSERT INTO `usuario` VALUES (26, 'test', NULL, NULL, 'test', 'test', 'jacobo@icoxsamarco.com', 1, '23123123', NULL, NULL, 1, '2010-01-21 11:59:51', '2010-01-21 12:00:46', 1);
INSERT INTO `usuario` VALUES (27, 'test3', 'a1ae45ccc71ffdb5dab6a570cd255d2d91c65f10', '9217f5d2945e0442f86e185d17d4e418c681457e', 'test 2', 'test', 'test@test1.es', 1, '123123213213', NULL, NULL, 1, '2010-01-21 18:15:16', '2010-01-21 18:18:58', 1);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `usuario_aplicacion_externa`
#

CREATE TABLE `usuario_aplicacion_externa` (
  `usuario_id` bigint(20) NOT NULL default '0',
  `aplicacion_externa_id` bigint(20) NOT NULL default '0',
  `login` varchar(255) default NULL,
  `salt` varchar(255) default NULL,
  `number_access` bigint(20) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`usuario_id`,`aplicacion_externa_id`),
  KEY `aplicacion_externa_id` (`aplicacion_externa_id`),
  CONSTRAINT `usuario_aplicacion_externa_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `usuario_aplicacion_externa_ibfk_2` FOREIGN KEY (`aplicacion_externa_id`) REFERENCES `aplicacion_externa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Volcar la base de datos para la tabla `usuario_aplicacion_externa`
#

INSERT INTO `usuario_aplicacion_externa` VALUES (7, 1, NULL, NULL, NULL, '2009-10-21 20:44:18', '2009-10-21 20:44:18', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (7, 2, NULL, NULL, NULL, '2009-10-21 20:44:18', '2009-10-21 20:44:18', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (7, 6, NULL, NULL, NULL, '2009-11-07 10:01:54', '2009-11-07 10:01:54', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (7, 7, NULL, NULL, NULL, '2009-11-07 10:01:54', '2009-11-07 10:01:54', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (7, 8, NULL, NULL, NULL, '2010-02-01 11:40:58', '2010-02-01 11:40:58', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (8, 1, NULL, NULL, NULL, '2009-10-29 12:00:02', '2009-10-29 12:00:02', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (9, 1, NULL, NULL, NULL, '2009-10-29 12:01:19', '2009-10-29 12:01:19', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (9, 2, NULL, NULL, NULL, '2009-10-29 12:01:19', '2009-10-29 12:01:19', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (11, 2, NULL, NULL, NULL, '2009-10-29 22:31:16', '2009-10-29 22:31:16', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (14, 1, NULL, NULL, NULL, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (14, 2, NULL, NULL, NULL, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (14, 6, NULL, NULL, NULL, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (14, 7, NULL, NULL, NULL, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (14, 8, NULL, NULL, NULL, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (15, 1, NULL, NULL, NULL, '2009-11-07 11:37:27', '2009-11-07 11:37:27', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (15, 6, NULL, NULL, NULL, '2009-11-07 11:37:27', '2009-11-07 11:37:27', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (16, 7, NULL, NULL, NULL, '2009-11-07 18:58:11', '2009-11-07 18:58:11', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (17, 1, NULL, NULL, NULL, '2009-12-18 12:05:32', '2009-12-18 12:05:32', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (17, 7, NULL, NULL, NULL, '2009-12-18 12:05:32', '2009-12-18 12:05:32', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (19, 1, NULL, NULL, NULL, '2009-12-21 19:13:10', '2009-12-21 19:13:10', 0);
INSERT INTO `usuario_aplicacion_externa` VALUES (19, 7, NULL, NULL, NULL, '2009-12-21 19:17:07', '2009-12-21 19:17:07', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `usuario_asamblea`
#

CREATE TABLE `usuario_asamblea` (
  `id` bigint(20) NOT NULL auto_increment,
  `usuario_id` bigint(20) NOT NULL,
  `asamblea_id` bigint(20) NOT NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `usuario_id_idx` (`usuario_id`),
  KEY `asamblea_id_idx` (`asamblea_id`),
  CONSTRAINT `usuario_asamblea_ibfk_2` FOREIGN KEY (`asamblea_id`) REFERENCES `asamblea` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usuario_asamblea_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

#
# Volcar la base de datos para la tabla `usuario_asamblea`
#

INSERT INTO `usuario_asamblea` VALUES (2, 11, 17, '2010-01-18 16:27:41', '2010-01-18 16:27:41');

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `usuario_consejo_territorial`
#

CREATE TABLE `usuario_consejo_territorial` (
  `usuario_id` bigint(20) NOT NULL default '0',
  `consejo_territorial_id` bigint(20) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`usuario_id`,`consejo_territorial_id`),
  KEY `consejo_territorial_id` (`consejo_territorial_id`),
  CONSTRAINT `usuario_consejo_territorial_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `usuario_consejo_territorial_ibfk_2` FOREIGN KEY (`consejo_territorial_id`) REFERENCES `consejo_territorial` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Volcar la base de datos para la tabla `usuario_consejo_territorial`
#

INSERT INTO `usuario_consejo_territorial` VALUES (7, 1, '2009-10-21 20:44:18', '2009-10-21 20:44:18', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 2, '2009-10-21 20:44:18', '2009-10-21 20:44:18', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 3, '2009-10-21 20:44:18', '2009-10-21 20:44:18', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 4, '2009-10-21 20:44:18', '2009-10-21 20:44:18', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 5, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 6, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 7, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 8, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 9, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 10, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 11, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 12, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 13, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 14, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 15, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (7, 16, '2010-01-12 10:49:02', '2010-01-12 10:49:02', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (9, 1, '2009-10-29 12:01:19', '2009-10-29 12:01:19', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (9, 3, '2009-10-29 12:01:19', '2009-10-29 12:01:19', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (9, 4, '2009-10-29 12:01:19', '2009-10-29 12:01:19', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (11, 1, '2009-10-29 22:31:16', '2009-10-29 22:31:16', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (11, 2, '2009-10-29 22:31:16', '2009-10-29 22:31:16', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (12, 1, '2009-10-29 22:42:16', '2009-10-29 22:42:16', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (12, 2, '2009-10-29 22:42:16', '2009-10-29 22:42:16', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 1, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 2, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 3, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 4, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 5, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 6, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 7, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 8, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 9, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 10, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 11, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 12, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 13, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 14, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 15, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (14, 16, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (16, 1, '2009-11-07 18:58:11', '2009-11-07 18:58:11', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 1, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 2, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 3, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 4, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 5, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 6, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 7, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 8, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 9, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 10, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 11, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 12, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 13, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 14, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 15, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (20, 16, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (23, 14, '2010-01-21 11:29:07', '2010-01-21 11:29:07', 0);
INSERT INTO `usuario_consejo_territorial` VALUES (25, 1, '2010-01-21 11:58:15', '2010-01-21 11:58:15', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `usuario_evento`
#

CREATE TABLE `usuario_evento` (
  `id` bigint(20) NOT NULL auto_increment,
  `usuario_id` bigint(20) NOT NULL,
  `evento_id` bigint(20) NOT NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `usuario_id_idx` (`usuario_id`),
  KEY `evento_id_idx` (`evento_id`),
  CONSTRAINT `usuario_evento_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `usuario_evento_ibfk_2` FOREIGN KEY (`evento_id`) REFERENCES `evento` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=latin1 AUTO_INCREMENT=106 ;

#
# Volcar la base de datos para la tabla `usuario_evento`
#


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `usuario_grupo_trabajo`
#

CREATE TABLE `usuario_grupo_trabajo` (
  `usuario_id` bigint(20) NOT NULL default '0',
  `grupo_trabajo_id` bigint(20) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`usuario_id`,`grupo_trabajo_id`),
  KEY `grupo_trabajo_id` (`grupo_trabajo_id`),
  CONSTRAINT `usuario_grupo_trabajo_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `usuario_grupo_trabajo_ibfk_2` FOREIGN KEY (`grupo_trabajo_id`) REFERENCES `grupo_trabajo` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Volcar la base de datos para la tabla `usuario_grupo_trabajo`
#

INSERT INTO `usuario_grupo_trabajo` VALUES (3, 1, '2009-12-28 15:55:00', '2009-12-28 15:55:00', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (3, 2, '2009-12-28 15:55:00', '2009-12-28 15:55:00', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (3, 3, '2009-12-28 15:55:00', '2009-12-28 15:55:00', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (3, 4, '2009-12-28 15:55:00', '2009-12-28 15:55:00', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (3, 7, '2009-12-28 15:55:00', '2009-12-28 15:55:00', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (3, 9, '2009-12-28 15:55:00', '2009-12-28 15:55:00', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (4, 1, '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (5, 2, '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (6, 2, '2009-10-20 17:49:37', '2009-10-20 17:49:37', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (7, 1, '2009-10-21 20:44:18', '2009-10-21 20:44:18', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (7, 2, '2009-10-21 20:44:18', '2009-10-21 20:44:18', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (7, 3, '2010-01-12 10:49:19', '2010-01-12 10:49:19', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (7, 4, '2009-10-21 20:44:18', '2009-10-21 20:44:18', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (7, 7, '2010-01-12 10:49:19', '2010-01-12 10:49:19', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (7, 9, '2009-12-28 18:33:45', '2009-12-28 18:33:45', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (7, 10, '2009-12-28 18:33:45', '2009-12-28 18:33:45', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (7, 11, '2010-01-12 10:49:19', '2010-01-12 10:49:19', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (7, 14, '2009-12-28 18:33:45', '2009-12-28 18:33:45', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (7, 16, '2010-01-18 12:14:13', '2010-01-18 12:14:13', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (9, 1, '2009-10-29 12:01:19', '2009-10-29 12:01:19', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (9, 2, '2009-10-29 12:01:19', '2009-10-29 12:01:19', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (9, 3, '2009-10-29 12:01:19', '2009-10-29 12:01:19', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (11, 3, '2009-10-29 22:31:16', '2009-10-29 22:31:16', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (12, 3, '2009-10-29 22:42:16', '2009-10-29 22:42:16', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (14, 1, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (14, 2, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (14, 3, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (14, 4, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (14, 7, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (14, 9, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (14, 10, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (14, 11, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (14, 14, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (16, 1, '2009-11-07 18:58:11', '2009-11-07 18:58:11', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (20, 1, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (20, 2, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (20, 3, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (20, 4, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (20, 7, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (20, 9, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (20, 10, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (20, 11, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (20, 14, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (20, 16, '2010-01-19 11:12:56', '2010-01-19 11:12:56', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (23, 11, '2010-01-21 11:29:07', '2010-01-21 11:29:07', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (24, 2, '2010-01-21 11:47:59', '2010-01-21 11:47:59', 0);
INSERT INTO `usuario_grupo_trabajo` VALUES (25, 1, '2010-01-21 11:58:57', '2010-01-21 11:58:57', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `usuario_lista_comunicado`
#

CREATE TABLE `usuario_lista_comunicado` (
  `usuario_id` bigint(20) NOT NULL default '0',
  `lista_comunicado_id` bigint(20) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`usuario_id`,`lista_comunicado_id`),
  KEY `lista_comunicado_id` (`lista_comunicado_id`),
  CONSTRAINT `usuario_lista_comunicado_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `usuario_lista_comunicado_ibfk_2` FOREIGN KEY (`lista_comunicado_id`) REFERENCES `lista_comunicado` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Volcar la base de datos para la tabla `usuario_lista_comunicado`
#

INSERT INTO `usuario_lista_comunicado` VALUES (3, 2, '2009-12-14 20:02:06', '2009-12-14 20:02:06', 0);
INSERT INTO `usuario_lista_comunicado` VALUES (3, 3, '2009-12-14 20:08:46', '2009-12-14 20:08:46', 0);
INSERT INTO `usuario_lista_comunicado` VALUES (3, 4, '2009-12-18 09:10:28', '2009-12-18 09:10:28', 0);
INSERT INTO `usuario_lista_comunicado` VALUES (7, 1, '2009-10-29 11:58:51', '2009-10-29 11:58:51', 0);
INSERT INTO `usuario_lista_comunicado` VALUES (8, 1, '2009-10-29 12:02:05', '2009-10-29 12:02:05', 0);
INSERT INTO `usuario_lista_comunicado` VALUES (9, 1, '2009-10-29 12:02:05', '2009-10-29 12:02:05', 0);
INSERT INTO `usuario_lista_comunicado` VALUES (9, 4, '2009-12-18 09:10:28', '2009-12-18 09:10:28', 0);
INSERT INTO `usuario_lista_comunicado` VALUES (13, 1, '2009-10-30 10:19:39', '2009-10-30 10:19:39', 0);
INSERT INTO `usuario_lista_comunicado` VALUES (14, 1, '2009-10-30 10:19:39', '2009-10-30 10:19:39', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `usuario_organismo`
#

CREATE TABLE `usuario_organismo` (
  `usuario_id` bigint(20) NOT NULL default '0',
  `organismo_id` bigint(20) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`usuario_id`,`organismo_id`),
  KEY `organismo_id` (`organismo_id`),
  CONSTRAINT `usuario_organismo_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `usuario_organismo_ibfk_2` FOREIGN KEY (`organismo_id`) REFERENCES `organismo` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Volcar la base de datos para la tabla `usuario_organismo`
#

INSERT INTO `usuario_organismo` VALUES (4, 1, '2009-11-19 17:56:11', '2009-11-19 17:56:11', 0);
INSERT INTO `usuario_organismo` VALUES (7, 2, '2009-12-22 08:58:18', '2009-12-22 08:58:18', 0);
INSERT INTO `usuario_organismo` VALUES (9, 2, '2009-12-22 08:58:18', '2009-12-22 08:58:18', 0);

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `usuario_rol`
#

CREATE TABLE `usuario_rol` (
  `usuario_id` bigint(20) NOT NULL default '0',
  `rol_id` bigint(20) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`usuario_id`,`rol_id`),
  KEY `rol_id` (`rol_id`),
  CONSTRAINT `usuario_rol_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `usuario_rol_ibfk_2` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Volcar la base de datos para la tabla `usuario_rol`
#

INSERT INTO `usuario_rol` VALUES (1, 1, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario_rol` VALUES (1, 2, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario_rol` VALUES (2, 1, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario_rol` VALUES (2, 2, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario_rol` VALUES (3, 9, '2010-01-22 17:45:36', '2010-01-22 17:45:36', 0);
INSERT INTO `usuario_rol` VALUES (4, 6, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario_rol` VALUES (5, 7, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario_rol` VALUES (6, 4, '2009-10-20 17:49:34', '2009-10-20 17:49:34', 0);
INSERT INTO `usuario_rol` VALUES (7, 1, '2009-11-07 09:53:20', '2009-11-07 09:53:20', 0);
INSERT INTO `usuario_rol` VALUES (8, 3, '2009-12-29 09:47:01', '2009-12-29 09:47:01', 0);
INSERT INTO `usuario_rol` VALUES (9, 4, '2009-12-29 09:16:44', '2009-12-29 09:16:44', 0);
INSERT INTO `usuario_rol` VALUES (9, 5, '2009-12-29 09:16:44', '2009-12-29 09:16:44', 0);
INSERT INTO `usuario_rol` VALUES (11, 3, '2009-10-29 22:31:16', '2009-10-29 22:31:16', 0);
INSERT INTO `usuario_rol` VALUES (11, 6, '2009-10-29 22:31:16', '2009-10-29 22:31:16', 0);
INSERT INTO `usuario_rol` VALUES (11, 7, '2009-10-29 22:31:16', '2009-10-29 22:31:16', 0);
INSERT INTO `usuario_rol` VALUES (12, 3, '2009-10-29 22:42:16', '2009-10-29 22:42:16', 0);
INSERT INTO `usuario_rol` VALUES (12, 4, '2009-10-29 22:42:16', '2009-10-29 22:42:16', 0);
INSERT INTO `usuario_rol` VALUES (12, 5, '2009-10-29 22:42:16', '2009-10-29 22:42:16', 0);
INSERT INTO `usuario_rol` VALUES (13, 1, '2010-02-02 17:14:14', '2010-02-02 17:14:14', 0);
INSERT INTO `usuario_rol` VALUES (13, 2, '2009-10-30 10:17:00', '2009-10-30 10:17:00', 0);
INSERT INTO `usuario_rol` VALUES (14, 1, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_rol` VALUES (14, 2, '2009-10-30 10:18:41', '2009-10-30 10:18:41', 0);
INSERT INTO `usuario_rol` VALUES (14, 3, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_rol` VALUES (14, 4, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_rol` VALUES (14, 5, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_rol` VALUES (14, 6, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_rol` VALUES (14, 7, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_rol` VALUES (14, 8, '2009-12-29 13:58:05', '2009-12-29 13:58:05', 0);
INSERT INTO `usuario_rol` VALUES (15, 3, '2009-11-07 11:37:27', '2009-11-07 11:37:27', 0);
INSERT INTO `usuario_rol` VALUES (15, 4, '2009-11-07 11:37:27', '2009-11-07 11:37:27', 0);
INSERT INTO `usuario_rol` VALUES (15, 6, '2009-11-07 11:37:27', '2009-11-07 11:37:27', 0);
INSERT INTO `usuario_rol` VALUES (15, 8, '2009-11-07 11:37:27', '2009-11-07 11:37:27', 0);
INSERT INTO `usuario_rol` VALUES (16, 4, '2009-11-07 18:58:11', '2009-11-07 18:58:11', 0);
INSERT INTO `usuario_rol` VALUES (17, 9, '2009-12-21 19:10:30', '2009-12-21 19:10:30', 0);
INSERT INTO `usuario_rol` VALUES (18, 3, '2009-12-18 13:43:14', '2009-12-18 13:43:14', 0);
INSERT INTO `usuario_rol` VALUES (19, 9, '2009-12-21 19:13:10', '2009-12-21 19:13:10', 0);
INSERT INTO `usuario_rol` VALUES (20, 9, '2010-01-25 10:56:11', '2010-01-25 10:56:11', 0);
INSERT INTO `usuario_rol` VALUES (23, 4, '2010-01-21 11:29:07', '2010-01-21 11:29:07', 0);
INSERT INTO `usuario_rol` VALUES (23, 8, '2010-01-21 11:41:09', '2010-01-21 11:41:09', 0);
INSERT INTO `usuario_rol` VALUES (24, 9, '2010-01-21 11:47:59', '2010-01-21 11:47:59', 0);
INSERT INTO `usuario_rol` VALUES (25, 9, '2010-01-21 12:02:08', '2010-01-21 12:02:08', 0);
